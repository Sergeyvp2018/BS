/*
 * main.h
 *
 *  Created on: Sep 22, 2020
 *      Author: sergeyvp@gmail.com
 */

#ifndef BS_H_
#define BS_H_

#include "stm32f0bs.h"
#include <stdint.h>
#include "BSH/PWR.h"
#include "BSH/OB.h"
#include "BSH/RCC.h"
#include "BSH/CRS.h"
#include "BSH/GPIO.h"
#include "BSH/SYSCFG.h"
#include "BSH/SYSTICK.h"
#include "BSH/SCB.h"
#include "BSH/DMA.h"
#include "BSH/EXTI.h"
#include "BSH/NVIC.h"
#include "BSH/CRC.h"
#include "BSH/ADC.h"
#include "BSH/DAC.h"
#include "BSH/TIM.h"
#include "BSH/WDG.h"
#include "BSH/RTC.h"
#include "BSH/I2C.h"
#include "BSH/USART.h"
#include "BSH/CAN.h"
#include "BSH/FLASH.h"
#include "BSH/USB.h"
#include "BSH/HDMI_CEC.h"

#define ON				1
#define OFF				0
#define HIGH			1
#define LOW				0
#define TRUE			1
#define FALSE			0
#define DROP			1
#define CLEAR			1
#define	MOVE_TO_END		(0b01)
#define	MOVE_TO_START	(0b10)
#define	MOVE_STOP		0

#endif /* BS_H_ */







