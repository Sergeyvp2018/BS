/*
 * COMP.h
 *
 *  Created on: 29 нояб. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_COMP_H_
#define BSH_COMP_H_

#include "BS.h"

/*******************************COMP control and status register (COMP_CSR)********************************/

#define	COMP_MOD_00	(0b00)		//	высокая скорость / полная мощность
#define	COMP_MOD_01	(0b01)		//	средняя скорость / средняя мощность
#define	COMP_MOD_10	(0b10)		//	низкая скорость / низкая мощность
#define	COMP_MOD_11	(0b11)		//	очень низкая скорость / сверхнизкая мощность

#define	COMP_INSEL_000	(0b000)		//	1/4 of V REFINT
#define	COMP_INSEL_001	(0b001)		//	1/2 of V REFINT
#define	COMP_INSEL_010	(0b010)		//	3/4 of V REFINT
#define	COMP_INSEL_011	(0b011)		//	V REFINT
#define	COMP_INSEL_100	(0b100)		//	COMP1_INM4 (PA4 with DAC_OUT1 if enabled)
#define	COMP_INSEL_101	(0b101)		//	COMP1_INM5 (PA5 with DAC_OUT2 if present and enabled)
#define	COMP_INSEL_110	(0b110)		//	COMP1_INM6 (PA0)

#define	COMP_OUTSEL_000	(0b000)		//	no selection
#define	COMP_OUTSEL_001	(0b001)		//	Timer 1 break input
#define	COMP_OUTSEL_010	(0b010)		//	Timer 1 Input capture 1
#define	COMP_OUTSEL_011	(0b011)		//	Timer 1 OCrefclear input
#define	COMP_OUTSEL_100	(0b100)		//	Timer 2 input capture 4
#define	COMP_OUTSEL_101	(0b101)		//	Timer 2 OCrefclear input
#define	COMP_OUTSEL_110	(0b110)		//	Timer 3 input capture 1
#define	COMP_OUTSEL_111	(0b111)		//	Timer 3 OCrefclear input

#define	COMP_HYST_00	(0b00)		//	No hysteresis
#define	COMP_HYST_01	(0b01)		//	Low hysteresis
#define	COMP_HYST_10	(0b10)		//	Medium hysteresis
#define	COMP_HYST_11	(0b11)		//	High hysteresis

typedef struct _StructCOMP_CSR		//	регистр управления и статуса (COMP_CSR)
{
	uint32_t COMP1EN	:1;			//	включить компаратор 1
	uint32_t COMP1SW1	:1;			//	переключает неинвертируемый	вход DAC
	uint32_t COMP1MODE	:2;			//	режим компаратора 1
	uint32_t COMP1INSEL	:3;			//	выбор инвертируемого входа компоратора 1
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t COMP1OUTSEL:3;			//	выбор вывода компоратора 1
	uint32_t COMP1POL	:1;			//	полярность вывода компоратора 1
	uint32_t COMP1HYST	:2;			//	гистерезис компаратора 1
	uint32_t COMP1OUT	:1;			//	флаг состояния вывода компоратора 1
	uint32_t COMP1LOCK	:1;			//	блокировка компоратора 1
	uint32_t COMP2EN	:1;			//	включить компаратор 2
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t COMP2MODE	:2;			//	режим компаратора 2
	uint32_t COMP2INSEL	:3;			//	выбор инвертируемого входа компоратора 2
	uint32_t WNDWEN		:1;			//	включить оконный режим
	uint32_t COMP2OUTSEL:3;			//	выбор вывода компоратора 2
	uint32_t COMP2POL	:1;			//	полярность вывода компоратора 2
	uint32_t COMP2HYST	:2;			//	гистерезис компаратора 2
	uint32_t COMP2OUT	:1;			//	флаг состояния вывода компоратора 2
	uint32_t COMP2LOCK	:1;			//	блокировка компоратора 2
} StructCOMP_CSR;

/**********************************************************************************************************/

/**********************************************************************************************************/

typedef struct _StructCOMP
{
	volatile StructCOMP_CSR		CSR;		//	регистр управления и статуса (COMP_CSR)
}StructCOMP;

#define	_COMP	((StructCOMP  *) 0x4001001c)

/**********************************************************************************************************/


#endif /* BSH_COMP_H_ */
















