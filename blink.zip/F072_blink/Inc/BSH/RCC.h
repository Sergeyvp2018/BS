/*
 * RCC.h
 *
 *  Created on: 21 окт. 2020 г.
 *      Author: sergeyvp@gmail.com
 */

#ifndef BSH_RCC_H_
#define BSH_RCC_H_

#include "BS.h"

/*******************************************************************************************************
Сброс и контроль тактирования (RCC)
Есть три типа сброса - системный, сброс питания и сброс области часов реального времени RTC.

Системный сброс генерируется при одном из событий:
1. низкий уровень на пине NRST (внешний сброс)
2. событие оконного сторожевого таймера (WWDG reset)
3. событие независимого сторожевого таймера (IWDG reset)
4. програмный сброс (SW reset)
5. сброс из-за низкого питания
6. загрузка опциональных байт
7. сброс питания
Системный сброс выставляет все регистры в значение по умолчанию, кроме флагов сброса в регистре
контроллера тактирования CSR и регистров области часов реального времени.
Источник перезагрузки может быть идентифицирован по флагам в регистре управления и статуса RCC_CSR.

Сброс питания генерируется при одном из событий:
1. Вкл./выкл. питания (POR/PDR reset)
2. выход из режима ожидания
Сброс питания возвращает все регистры в значение по умолчанию, кроме области часов реального времени.
Сброс при низком питании возможен в двух случаях:
1. При входе в режим ожидания:
Этот тип сброса включается установкой бита nRST_STDBY в пользовательских опциональных байтах.
В этом случае вместо режима ожидания устройство перезагружается.
2. При входе в режим Stop:
Этот тип сброса включается установкой бита nRST_STOP в пользовательских опциональных байтах.
В этом случае вместо режима Stop устройство перезагружается.
Сброс загрузчика опциональных байт генерируется, когда бит OBL_LAUNCH (бит 13) установлен в регистре FLASH_CR.
Этот бит используется для запуска загрузчика опциональных байт программным обеспечением.

Сброс области часов реального времени (RTC domain) действует только на генератор LSE,
часы реального времени RTC, резервные регистры хранения и регистр контроля области RTC (RCC_BDCR).
Сброс происходит при следующих событиях:
1. програмный сброс, переключение бита BDRST в области RTC контрольного регистра (RCC_BDCR)
2. батарейка разряжена, или отключена
Регистры резервного хранения так же могут быть сброшены в следующих случаях:
1. событие обнаружения искажения/порчи RTC
2. изменение защиты чтения с уровня 1 на уровень 0

Варианты тактирования:
• тактирование генератором HSI 8 MHz RC
• тактирование генератором HSE
• тактирование PLL (ФАПЧ фазовая автоподстройка частоты)
• тактирование генератором HSI48 48 MHz RC (доступно только на STM32F04x, STM32F07x и STM32F09x)
Устройства имеют дополнительные источники тактирования:
• 40 kHz низкочастотная внутренняя RC цепь (LSI RC) управляет независимым сторожевым таймером и
опционально используется для пробуждения RTC из режима ожидания или остановки (Stop/Standby mode).
• 32.768 kHz внешний низкочастотный кварц (LSE crystal) используется для часов реального времени (RTCCLK)
• 14 MHz высокочастотная внутренняя RC цепь (HSI14) предназначена для АЦП (ADC).
Каждый источник тактирования может быть выключен для оптимизации потребления энергии.
Несколько предделителей могут использоваться для конфигурирования частоты области AHB и APB.
Для AHB и APB максимальная частота 48 MHz.
Вся переферия тактируется частотой шины на которой находится (HCLK для AHB или PCLK для APB)
Кроме:
• интерфейс програмирования Flash памяти тактируется всегда генератором HSI (FLITFCLK)
• загрузчик опциональных байт всегда тактируется генератором HSI
• Тактирование ADC (выбирается програмно) возможно двумя источниками:
– выделенный генератор HSI14, для максимальной частоты дискретизации
– APB тактирование (PCLK) делённое на 2 или 4
Тактирование USART1, USART2 (в STM32F07x и STM32F09x) и USART3 (в STM32F09x)
может выполнятся из четырёх источников (выбирается програмно):
– системное тактирование
– тактирование HSI
– тактирование LSE
– APB тактирование (PCLK)
Тактирование I2C1 может выполнятся (выбирается програмно) одним из двух источников:
– системное тактирование
– тактирование HSI
Тактирование USB может выполнятся (выбирается програмно) одним из двух источников:
– тактирование PLL
– тактирование HSI48
• тактирование CEC выполняется HSI делёным на 244 или генератором LSE
• тактирование I2S1 и I2S2 всегда системное
• тактирование RTC выполняется генератором LSE, LSI или HSE с делителем 32.
• Частота тактирования таймера автоматически исправляется аппаратно. Это происходит в двух ситуациях:
– если предделитель APB равен 1, частота тактирования таймера устанавливается такой же как область APB
– иначе, частота умножается вдвое по отношению к области APB
Тактирование независимого сторожевого таймера IWDG всегда осуществляется генератором LSI.
RCC тактирует Cortex System Timer (SysTick) внешним генератором AHB (HCLK) делёным на 8.
SysTick может работать как с этим тактированием, так и напрямую с Cortex clock (HCLK), конфигурируется
в SysTick Control and Status Register.
********************************************************************************************************/

void _RCC_ini( void);

/*********************************Clock control register (RCC_CR)***************************************/

typedef struct _StructRCC_CR
{
	uint32_t HSION		:1;		//	включить тактирование HSI clock enable
	uint32_t HSIRDY		:1;		//	флаг готовности HSI clock ready flag
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t HSITRIM	:5;		//	подстройка тактирования HSI clock trimming
	uint32_t HSICAL		:8;		//	калибровка тактирования HSI clock calibration
	uint32_t HSEON		:1;		//	включить тактирование HSE clock enable
	uint32_t HSERDY		:1;		//	флаг готовности HSE clock ready flag
	uint32_t HSEBYP		:1;		//	обход кварцевого генератора HSE crystal oscillator bypass
	uint32_t CSSON		:1;		//	включить систему безопасности тактирования Clock security system enable
	uint32_t reserv2	:4;		//	неиспользуется
	uint32_t PLLON		:1;		//	включить фазовую автоподстройку частоты ФАПЧ PLL enable
	uint32_t PLLRDY		:1;		//	флаг готовности ФАПЧ PLL clock ready flag
	uint32_t reserv3	:6;		//	неиспользуется
} StructRCC_CR;

/*****************************Clock configuration register (RCC_CFGR)***********************************/

#define PLLMUL2		(0b0000)	//	PLL input clock x 2
#define PLLMUL3		(0b0001)	//	PLL input clock x 3
#define PLLMUL4		(0b0010)	//	PLL input clock x 4
#define PLLMUL5		(0b0011)	//	PLL input clock x 5
#define PLLMUL6		(0b0100)	//	PLL input clock x 6
#define PLLMUL7		(0b0101)	//	PLL input clock x 7
#define PLLMUL8		(0b0110)	//	PLL input clock x 8
#define PLLMUL9		(0b0111)	//	PLL input clock x 9
#define PLLMUL10		(0b1000)	//	PLL input clock x 10
#define PLLMUL11		(0b1001)	//	PLL input clock x 11
#define PLLMUL12		(0b1010)	//	PLL input clock x 12
#define PLLMUL13		(0b1011)	//	PLL input clock x 13
#define PLLMUL14		(0b1100)	//	PLL input clock x 14
#define PLLMUL15		(0b1101)	//	PLL input clock x 15
#define PLLMUL16		(0b1110)	//	PLL input clock x 16

#define SYS_CLOCK_HSI		(0b00)
#define SYS_CLOCK_HSE		(0b01)
#define SYS_CLOCK_PLL		(0b10)
#define SYS_CLOCK_HSI48	(0b11)

#define MCO_0000		(0b0000)	//	MCO вывод отключен
#define MCO_HSI14		(0b0001)	//	внутренняя цепь RC 14 MHz (HSI14)
#define MCO_LSI		(0b0010)	//	внутренний низкочастотный генератор (LSI)
#define MCO_LSE		(0b0011)	//	внешний низкочастотный генератор (LSE)
#define MCO_SYS		(0b0100)	//	системное тактирование
#define MCO_HSI		(0b0101)	//	внутренняя цепь 8 MHz (HSI)
#define MCO_HSE		(0b0110)	//	внешний генератор 4-32 MHz (HSE)
#define MCO_PLL		(0b0111)	//	PLL (делитель зависит от PLLNODIV)
#define MCO_HSI48		(0b1000)	//	внутренняя цепь RC 48 MHz (HSI48)

#define PLLSRC_HSID2	(0b00)		//	HSI/2 selected as PLL input clock (PREDIV forced to divide by 2 on STM32F04x, STM32F07x and STM32F09x devices)
#define PLLSRC_HSIPD	(0b01)		//	HSI/PREDIV selected as PLL input clock
#define PLLSRC_HSEPD	(0b10)		//	HSE/PREDIV selected as PLL input clock
#define PLLSRC_HSI48PD	(0b11)		//	HSI48/PREDIV selected as PLL input clock

typedef struct _StructRCC_CFGR
{
	uint32_t SYS_CLOCK	:2;		//	переключение системы тактирования System clock switch
	uint32_t SWS		:2;		//	статус переключения системы тактирования System clock switch status
	uint32_t HPRE		:4;		//	предделитель HCLK prescaler
	uint32_t PPRE		:3;		//	предделитель PCLK prescaler
	uint32_t reserv1	:3;		//	неиспользуется
	uint32_t ADCPRE		:1;		//	предделитель ADC prescaler
	uint32_t PLLSRC		:2;		//	источник тактирования ФАПЧ PLL input clock source
	uint32_t PLLXTPRE	:1;		//	делитель тактирования ФАПЧ HSE divider for PLL input clock
	uint32_t PLLMUL		:4;		//	множитель ФАПЧ PLL multiplication factor
	uint32_t reserv2	:2;		//	неиспользуется
	uint32_t MCO		:4;		//	вывод тактирования Microcontroller clock output
	uint32_t MCOPRE		:3;		//	предделитель вывода тактирования Microcontroller Clock Output Prescaler
	uint32_t PLLNODIV	:1;		//	ФАПЧ без делителя для вывода PLL clock not divided for MCO
} StructRCC_CFGR;

/*****************************Clock interrupt register (RCC_CIR)****************************************/

typedef struct _StructRCC_CIR
{
	uint32_t LSIRDYF	:1;		//	флаг готовности прерывания LSI
	uint32_t LSERDYF	:1;		//	флаг готовности прерывания LSE
	uint32_t HSIRDYF	:1;		//	флаг готовности прерывания HSI
	uint32_t HSERDYF	:1;		//	флаг готовности прерывания HSE
	uint32_t PLLRDYF	:1;		//	флаг готовности прерывания PLL
	uint32_t HSI14RDYF	:1;		//	флаг готовности прерывания HSI14
	uint32_t HSI48RDYF	:1;		//	флаг готовности прерывания HSI48
	uint32_t CSSF		:1;		//	флаг готовности прерывания CSS (Clock Security System)
	uint32_t LSIRDYIE	:1;		//	включить готовность прерывания LSI
	uint32_t LSERDYIE	:1;		//	включить готовность прерывания LSE
	uint32_t HSIRDYIE	:1;		//	включить готовность прерывания HSI
	uint32_t HSERDYIE	:1;		//	включить готовность прерывания HSE
	uint32_t PLLRDYIE	:1;		//	включить готовность прерывания PLL
	uint32_t HSI14RDYIE	:1;		//	включить готовность прерывания HSI14
	uint32_t HSI48RDYIE	:1;		//	включить готовность прерывания HSI48
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t LSIRDYC	:1;		//	очистить флаг готовности LSI
	uint32_t LSERDYC	:1;		//	очистить флаг готовности LSE
	uint32_t HSIRDYC	:1;		//	очистить флаг готовности HSI
	uint32_t HSERDYC	:1;		//	очистить флаг готовности HSE
	uint32_t PLLRDYC	:1;		//	очистить флаг готовности PLL
	uint32_t HSI14RDYC	:1;		//	очистить флаг готовности HSI14
	uint32_t HSI48RDYC	:1;		//	очистить флаг готовности HSI48RDYC
	uint32_t CSSC		:1;		//	очистить флаг готовности CSS (Clock Security System)
	uint32_t reserv2	:8;		//	неиспользуется
} StructRCC_CIR;

/***********************APB peripheral reset register 2 (RCC_APB2RSTR)**********************************/

typedef struct _StructRCC_APB2RSTR	//	APB peripheral reset register 2 (RCC_APB2RSTR)
{
	uint32_t SYSCFGRST	:1;		//	сброс настроек SYSCFGRST
	uint32_t reserv1	:4;		//	неиспользуется
	uint32_t USART6RST	:1;		//	сброс настроек USART6
	uint32_t USART7RST	:1;		//	сброс настроек USART7
	uint32_t USART8RST	:1;		//	сброс настроек USART8
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t ADCRST		:1;		//	сброс настроек ADC
	uint32_t reserv3	:1;		//	неиспользуется
	uint32_t TIM1RST	:1;		//	сброс настроек TIM1
	uint32_t SPI1RST	:1;		//	сброс настроек SPI1
	uint32_t reserv4	:1;		//	неиспользуется
	uint32_t USART1RST	:1;		//	сброс настроек USART1
	uint32_t reserv5	:1;		//	неиспользуется
	uint32_t TIM15RST	:1;		//	сброс настроек TIM15
	uint32_t TIM16RST	:1;		//	сброс настроек TIM16
	uint32_t TIM17RST	:1;		//	сброс настроек TIM17
	uint32_t reserv6	:3;		//	неиспользуется
	uint32_t DBGMCURST	:1;		//	сброс настроек DBGMCU
	uint32_t reserv7	:9;		//	неиспользуется
} StructRCC_APB2RSTR;

/***********************APB peripheral reset register 1 (RCC_APB1RSTR)**********************************/

typedef struct _StructRCC_APB1RSTR	//	APB peripheral reset register 1 (RCC_APB1RSTR)
{
	uint32_t TIM2RST	:1;		//	сброс настроек TIM2
	uint32_t TIM3RST	:1;		//	сброс настроек TIM3
	uint32_t reserv1	:2;		//	неиспользуется
	uint32_t TIM6RST	:1;		//	сброс настроек TIM6
	uint32_t TIM7RST	:1;		//	сброс настроек TIM7
	uint32_t reserv2	:2;		//	неиспользуется
	uint32_t TIM14RST	:1;		//	сброс настроек TIM14
	uint32_t reserv3	:2;		//	неиспользуется
	uint32_t WWDGRST	:1;		//	неиспользуется WWDGRST
	uint32_t reserv4	:2;		//	неиспользуется
	uint32_t SPI2RST	:1;		//	неиспользуется SPI2
	uint32_t reserv5	:2;		//	неиспользуется
	uint32_t USART2RST	:1;		//	неиспользуется USART2
	uint32_t USART3RST	:1;		//	неиспользуется USART3
	uint32_t USART4RST	:1;		//	неиспользуется USART4
	uint32_t USART5RST	:1;		//	неиспользуется USART5
	uint32_t I2C1RST	:1;		//	неиспользуется I2C1
	uint32_t I2C2RST	:1;		//	неиспользуется I2C2
	uint32_t USBRST		:1;		//	неиспользуется USB
	uint32_t reserv6	:1;		//	неиспользуется
	uint32_t CANRST		:1;		//	неиспользуется CAN
	uint32_t reserv7	:1;		//	неиспользуется
	uint32_t CRSRST		:1;		//	неиспользуется CRS
	uint32_t PWRRST		:1;		//	неиспользуется PWR
	uint32_t DACRST		:1;		//	неиспользуется DAC
	uint32_t CECRST		:1;		//	неиспользуется CEC
	uint32_t reserv8	:1;		//	неиспользуется
} StructRCC_APB1RSTR;

/**********************AHB peripheral clock enable register (RCC_AHBENR)********************************/

typedef struct _StructRCC_AHBENR
{
	uint32_t DMAEN		:1;		//	включить тактирование DMA
	uint32_t DMA2EN		:1;		//	включить тактирование DMA2
	uint32_t SRAMEN		:1;		//	включить тактирование SRAM
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t FLITFEN	:1;		//	включить тактирование FLITF
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t CRCEN		:1;		//	включить тактирование CRC
	uint32_t reserv3	:10;	//	неиспользуется
	uint32_t IOPAEN		:1;		//	включить тактирование I/O port A
	uint32_t IOPBEN		:1;		//	включить тактирование I/O port B
	uint32_t IOPCEN		:1;		//	включить тактирование I/O port C
	uint32_t IOPDEN		:1;		//	включить тактирование I/O port D
	uint32_t IOPEEN		:1;		//	включить тактирование I/O port E
	uint32_t IOPFEN		:1;		//	включить тактирование I/O port F
	uint32_t reserv4	:1;		//	неиспользуется
	uint32_t TSCEN		:1;		//	включить тактирование контролера касаний
	uint32_t reserv5	:7;		//	неиспользуется
} StructRCC_AHBENR;

/**********************APB peripheral clock enable register 2 (RCC_APB2ENR)*****************************/

typedef struct _StructRCC_APB2ENR
{
	uint32_t SYSCFGEN	:1;		//	включить тактирование SYSCFG & COMP clock enable
	uint32_t reserv1	:4;		//	неиспользуется
	uint32_t USART6EN	:1;		//	включить тактирование USART6 clock enable
	uint32_t USART7EN	:1;		//	включить тактирование USART7 clock enable
	uint32_t USART8EN	:1;		//	включить тактирование USART8 clock enable
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t ADCEN		:1;		//	включить тактирование ADC interface clock enable
	uint32_t reserv3	:1;		//	неиспользуется
	uint32_t TIM1EN		:1;		//	включить тактирование TIM1 timer clock enable
	uint32_t SPI1EN		:1;		//	включить тактирование SPI1 clock enable
	uint32_t reserv4	:1;		//	неиспользуется
	uint32_t USART1EN	:1;		//	включить тактирование USART1 clock enable
	uint32_t reserv5	:1;		//	неиспользуется
	uint32_t TIM15EN	:1;		//	включить тактирование TIM15 timer clock enable
	uint32_t TIM16EN	:1;		//	включить тактирование TIM16 timer clock enable
	uint32_t TIM17EN	:1;		//	включить тактирование TIM17 timer clock enable
	uint32_t reserv6	:3;		//	неиспользуется
	uint32_t DBGMCUEN	:1;		//	включить тактирование MCU debug module clock enable
	uint32_t reserv7	:9;		//	неиспользуется
} StructRCC_APB2ENR;

/**********************APB peripheral clock enable register 1 (RCC_APB1ENR)*****************************/

typedef struct _StructRCC_APB1ENR
{
	uint32_t TIM2EN		:1;		//	включить тактирование TIM2 timer clock enable
	uint32_t TIM3EN		:1;		//	включить тактирование TIM3 timer clock enable
	uint32_t reserv1	:2;		//	неиспользуется
	uint32_t TIM6EN		:1;		//	включить тактирование TIM6 timer clock enable
	uint32_t TIM7EN		:1;		//	включить тактирование TIM7 timer clock enable
	uint32_t reserv2	:2;		//	неиспользуется
	uint32_t TIM14EN	:1;		//	включить тактирование TIM14 timer clock enable
	uint32_t reserv3	:2;		//	неиспользуется
	uint32_t WWDGEN		:1;		//	включить тактирование Window watchdog clock enable
	uint32_t reserv4	:2;		//	неиспользуется
	uint32_t SPI2EN		:1;		//	включить тактирование SPI2 clock enable
	uint32_t reserv5	:2;		//	неиспользуется
	uint32_t USART2EN	:1;		//	включить тактирование USART2 clock enable
	uint32_t USART3EN	:1;		//	включить тактирование USART3 clock enable
	uint32_t USART4EN	:1;		//	включить тактирование USART4 clock enable
	uint32_t USART5EN	:1;		//	включить тактирование USART5 clock enable
	uint32_t I2C1EN		:1;		//	включить тактирование I2C1 clock enable
	uint32_t I2C2EN		:1;		//	включить тактирование I2C2 clock enable
	uint32_t USBEN		:1;		//	включить тактирование USB interface clock enable
	uint32_t reserv6	:1;		//	неиспользуется
	uint32_t CANEN		:1;		//	включить тактирование CAN interface clock enable
	uint32_t reserv7	:1;		//	неиспользуется
	uint32_t CRSEN		:1;		//	включить тактирование Clock Recovery System interface clock enable
	uint32_t PWREN		:1;		//	включить тактирование Power interface clock enable
	uint32_t DACEN		:1;		//	включить тактирование DAC interface clock enable
	uint32_t CECEN		:1;		//	включить тактирование HDMI CEC clock enable
	uint32_t reserv8	:1;		//	неиспользуется
} StructRCC_APB1ENR;

/******************************RTC domain control register (RCC_BDCR)***********************************/

#define XtalLOW		(0b00)	//	‘Xtal mode’ low drive capability
#define XtalMHIGH	(0b01)	//	‘Xtal mode’ medium-high drive capability
#define XtalMLOW	(0b10)	//	‘Xtal mode’ medium-low drive capability
#define XtalHIGH	(0b11)	//	‘Xtal mode’ high drive capability (reset value)

#define NO_CLOCK	(0b00)	//	нет тактирования
#define LSE_CLOCK	(0b01)	//	LSE генератор используется для тактирования часов реального времени RTC
#define LSI_CLOCK	(0b10)	//	LSI генератор используется для тактирования часов реального времени RTC
#define HSE_CLOCK	(0b11)	//	HSE генератор с делителем 32 используется для тактирования RTC

typedef struct _StructRCC_BDCR	//	RTC domain control register (RCC_BDCR)
{
	uint32_t LSEON		:1;		//	включить генератор LSE
	uint32_t LSERDY		:1;		//	флаг готовности генератора LSE
	uint32_t LSEBYP		:1;		//	обход генератора LSE
	uint32_t reserv1	:3;		//	неиспользуется
	uint32_t LSEDRV		:2;		//	возможности генератора LSE
	uint32_t RTCSEL		:2;		//	выбор источника тактирования RTC
	uint32_t reserv2	:5;		//	неиспользуется
	uint32_t RTCEN		:1;		//	включить RTC
	uint32_t BDRST		:1;		//	сброс настроек области RTC
	uint32_t reserv3	:15;	//	неиспользуется
} StructRCC_BDCR;

/********************************Control/status register (RCC_CSR)**************************************/

typedef struct _StructRCC_CSR	//	Регистр контроля статуса (RCC_CSR)
{
	uint32_t LSION		:1;		//	LSI включен?
	uint32_t LSIRDY		:1;		//	устанавливается аппаратно при стабилизации LSI
	uint32_t reserv		:21;	//	неиспользуется
	uint32_t V18PWRRSTF	:1;		//	флаг сброса настроек области 1.8v
	uint32_t RMVF		:1;		//	удаление флага сброса
	uint32_t OBLRSTF	:1;		//	флаг сброса загрузчика опций
	uint32_t PINRSTF	:1;		//	устанавливается аппаратно при сбросе NRST
	uint32_t PORRSTF	:1;		//	устанавливается аппаратно при сбросе POR/PDR
	uint32_t SFTRSTF	:1;		//	устанавливается аппаратно при программном сбросе
	uint32_t IWDGRSTF	:1;		//	устанавливается аппаратно при сбросе независимого сторожевого таймера
	uint32_t WWDGRSTF	:1;		//	устанавливается аппаратно при сбросе оконного сторожевого таймера
	uint32_t LPWRRSTF	:1;		//	устанавливается аппаратно при сбросе управления питанием
} StructRCC_CSR;

/***************************AHB peripheral reset register (RCC_AHBRSTR)*********************************/

typedef struct _StructRCC_AHBRSTR	//	AHB peripheral reset register (RCC_AHBRSTR)
{
	uint32_t reserv1	:17;	//	неиспользуется
	uint32_t IOPARST	:1;		//	сбросить порт A
	uint32_t IOPBRST	:1;		//	сбросить порт B
	uint32_t IOPCRST	:1;		//	сбросить порт C
	uint32_t IOPDRST	:1;		//	сбросить порт D
	uint32_t IOPERST	:1;		//	сбросить порт E
	uint32_t IOPFRST	:1;		//	сбросить порт F
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t TSCRST		:1;		//	сброс контроллера касаний
	uint32_t reserv3	:7;		//	неиспользуется
} StructRCC_AHBRSTR;

/***************************Clock configuration register 2 (RCC_CFGR2)**********************************/

#define PREDIV0			(0b0000)	//	PREDIV input clock not divided
#define PREDIV2			(0b0001)	//	PREDIV input clock divided by 2
#define PREDIV3			(0b0010)	//	PREDIV input clock divided by 3
#define PREDIV4			(0b0011)	//	PREDIV input clock divided by 4
#define PREDIV5			(0b0100)	//	PREDIV input clock divided by 5
#define PREDIV6			(0b0101)	//	PREDIV input clock divided by 6
#define PREDIV7			(0b0110)	//	PREDIV input clock divided by 7
#define PREDIV8			(0b0111)	//	PREDIV input clock divided by 8
#define PREDIV9			(0b1000)	//	PREDIV input clock divided by 9
#define PREDIV10		(0b1001)	//	PREDIV input clock divided by 10
#define PREDIV11		(0b1010)	//	PREDIV input clock divided by 11
#define PREDIV12		(0b1011)	//	PREDIV input clock divided by 12
#define PREDIV13		(0b1100)	//	PREDIV input clock divided by 13
#define PREDIV14		(0b1101)	//	PREDIV input clock divided by 14
#define PREDIV15		(0b1110)	//	PREDIV input clock divided by 15
#define PREDIV16		(0b1111)	//	PREDIV input clock divided by 16

typedef struct _StructRCC_CFGR2	//	Clock configuration register 2 (RCC_CFGR2)
{
	uint32_t PREDIV		:4;		//	коэффициент деления
	uint32_t reserv		:28;	//	неиспользуется
} StructRCC_CFGR2;

/****************************Clock configuration register 3 (RCC_CFGR3)********************************/

typedef struct _StructRCC_CFGR3	//	Clock configuration register 3 (RCC_CFGR3)
{
	uint32_t USART1SW	:2;		//	выбор источника тактирования USART1
	uint32_t reserv1	:2;		//	неиспользуется
	uint32_t I2C1SW		:1;		//	выбор источника тактирования I2C1
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t CECSW		:1;		//	выбор источника тактирования CEC
	uint32_t USBSW		:1;		//	выбор источника тактирования USB
	uint32_t ADCSW		:1;		//	выбор источника тактирования ADC
	uint32_t reserv3	:7;		//	неиспользуется
	uint32_t USART2SW	:2;		//	выбор источника тактирования USART2
	uint32_t USART3SW	:2;		//	выбор источника тактирования USART3
	uint32_t reserv4	:12;	//	неиспользуется
} StructRCC_CFGR3;

/*************************Регистр управления тактированием 2 (RCC_CR2)*********************************/

typedef struct _StructRCC_CR2		//	Регистр управления тактированием 2 (RCC_CR2)
{
	uint32_t HSI14ON		:1;		//	включить HSI14
	uint32_t HSI14RDY		:1;		//	флаг готовности HSI14 (только чтение)
	uint32_t HSI14DIS		:1;		//	отключение тактирования ADC через HSI14
	uint32_t HSI14TRIM		:5;		//	подстройка тактирования HSI14
	uint32_t HSI14CAL		:8;		//	автоматическая калибровка тактирования HSI14 (только чтение)
	uint32_t HSI48ON		:1;		//	включить HSI48
	uint32_t HSI48RDY		:1;		//	флаг готовности HSI48 (только чтение)
	uint32_t reserv			:6;		//	неиспользуется
	uint32_t HSI48CAL		:8;		//	заводская калибровка HSI48 (только чтение)
} StructRCC_CR2;					//	Регистр управления тактированием 2 (RCC_CR2)

/******************************************************************************************************/

typedef struct _StructRCC
{
	volatile StructRCC_CR			CR;			//	регистр управления тактированием
	volatile StructRCC_CFGR			CFGR;		//	регистр конфигурации тактирования
	volatile StructRCC_CIR			CIR;		//	регистр прерываний системы тактирования
	volatile StructRCC_APB2RSTR		APB2RSTR;	//	регистр сброса переферии 2
	volatile StructRCC_APB1RSTR		APB1RSTR;	//	регистр сброса переферии 1
	volatile StructRCC_AHBENR		AHBENR;		//	регистр включения тактирования переферии на шине AHB
	volatile StructRCC_APB2ENR		APB2ENR;	//	2 регистр включения тактирования переферии на шине APB
	volatile StructRCC_APB1ENR		APB1ENR;	//	1 регистр включения тактирования переферии на шине APB
	volatile StructRCC_BDCR			BDCR;		//	регистр управления областью RTC
	volatile StructRCC_CSR			CSR;		//	регистр управления и статуса
	volatile StructRCC_AHBRSTR		AHBRSTR;	//	регистр сброса переферии на шине AHB
	volatile StructRCC_CFGR2		CFGR2;		//	регистр конфигурации тактирования 2
	volatile StructRCC_CFGR3		CFGR3;		//	регистр конфигурации тактирования 3
	volatile StructRCC_CR2			CR2;		//	регистр управления тактированием 2
}StructRCC;

#define	_RCC	((StructRCC *) (0x40021000))

/******************************************************************************************************/

#endif /* BSH_RCC_H_ */












