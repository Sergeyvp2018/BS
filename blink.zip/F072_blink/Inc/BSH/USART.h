/*
 * USART.h
 *
 *  Created on: 24 нояб. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_USART_H_
#define BSH_USART_H_

#include "BS.h"

/************************************Control register 1 (USART_CR1)*************************************/

typedef struct _StructUSART_CR1		//	регистр управления 1 (USART_CR1)
{
	uint32_t UE			:1;			//	включить/выключить USART
	uint32_t UESM		:1;			//	включить/выключить стоп режим USART
	uint32_t RE			:1;			//	включить/выключить приемник USART
	uint32_t TE			:1;			//	включить/выключить передатчик USART
	uint32_t IDLEIE		:1;			//	включить/выключить прерывание простоя USART
	uint32_t RXNEIE		:1;			//	включить/выключить прерывание RXNE
	uint32_t TCIE		:1;			//	включить/выключить прерывание при выполнении передачи
	uint32_t TXEIE		:1;			//	включить/выключить прерывание при передаче
	uint32_t PEIE		:1;			//	включить/выключить прерывание PE
	uint32_t PS			:1;			//	выбор паритета
	uint32_t PCE		:1;			//	включить/выключить управление паритетом
	uint32_t WAKE		:1;			//	метод пробуждения приёмника
	uint32_t M0			:1;			//	длина слова
	uint32_t MME		:1;			//	включить/выключить тихий режим
	uint32_t CMIE		:1;			//	прерывание при соответствии символов
	uint32_t OVER8		:1;			//	режим передискретизации
	uint32_t DEDT		:5;			//	время между стоп битом и сигналом деактивации
	uint32_t DEAT		:5;			//	время между активацией и стартовым битом
	uint32_t RTOIE		:1;			//	включить/выключить прерывание по истечении времени приема
	uint32_t EOBIE		:1;			//	включить/выключить прерывание при установке флага EOBF в USART_ISR
	uint32_t M1			:1;			//	длина слова
	uint32_t reserv1	:3;			//	неиспользуется
} StructUSART_CR1;

typedef union _USART_CR1			//	регистр управления 1 (USART_CR1)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_CR1 *BS;		//	Bit-Structure
} USART_CR1;

/*******************************************END (USART_CR1)*********************************************/

/************************************Control register 2 (USART_CR2)*************************************/

typedef struct _StructUSART_CR2		//	регистр управления 2 (USART_CR2)
{
	uint32_t reserv1	:4;			//	неиспользуется
	uint32_t ADDM7		:1;			//	7-bit определения адреса/4-bit определения адреса
	uint32_t LBDL		:1;			//	11 или 10 bit обнаружения разрыва
	uint32_t LBDIE		:1;			//	включить прерывание при LBDF=1 в регистре USART_ISR
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t LBCL		:1;			//	вывод последнего тактового бита
	uint32_t CPHA		:1;			//	фаза тактирования
	uint32_t CPOL		:1;			//	полярность тактирования
	uint32_t CLKEN		:1;			//	включить тактирование
	uint32_t STOP		:1;			//	стоп биты
	uint32_t LINEN		:1;			//	включить режим LIN
	uint32_t SWAP		:1;			//	поменять местами пины TX / RX
	uint32_t RXINV		:1;			//	инвертировать активный уровень пина RX
	uint32_t TXINV		:1;			//	инвертировать активный уровень пина TX
	uint32_t DATAINV	:1;			//	инверсия двоичных данных
	uint32_t MSBFIRST	:1;			//	сначала старший бит
	uint32_t ABREN		:1;			//	автоматическая скорость передачи
	uint32_t ABRMOD		:2;			//	режим автоматической скорости передачи
	uint32_t RTOEN		:1;			//	таймаут приёма
	uint32_t ADD1		:4;			//	адрес узла USART
	uint32_t ADD2		:4;			//	адрес узла USART
} StructUSART_CR2;

typedef union _USART_CR2			//	регистр управления 2 (USART_CR2)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_CR2 *BS;		//	Bit-Structure
} USART_CR2;

/*******************************************END (USART_CR2)*********************************************/

/************************************Control register 1 (USART_CR3)*************************************/

#define	WUF_ADDM7	(0b00)	//	WUF active on address match (as defined by ADD[7:0] and ADDM7)
#define	WUF_SBIT	(0b10)	//	WuF active on Start bit detection
#define	WUF_RXNE	(0b11)	//	WUF active on RXNE

typedef struct _StructUSART_CR3		//	регистр управления 3 (USART_CR3)
{
	uint32_t EIE		:1;			//	включить ошибку прерывания
	uint32_t IREN		:1;			//	включить режим IrDA
	uint32_t IRLP		:1;			//	низкий уровень потребления IrDA
	uint32_t HDSEL		:1;			//	выбор полудуплекса
	uint32_t NACK		:1;			//	режим смарткарты NACK
	uint32_t SCEN		:1;			//	режим смарткарты
	uint32_t DMAR		:1;			//	DMA режим приемника
	uint32_t DMAT		:1;			//	DMA	режим передатчика
	uint32_t RTSE		:1;			//	включить вывод RTS
	uint32_t CTSE		:1;			//	включить режим CTS
	uint32_t CTSIE		:1;			//	прерывание при CTSIF=1 в регистре USART_ISR
	uint32_t ONEBIT		:1;			//	включение однобитного метода
	uint32_t OVRDIS		:1;			//	отключить переполнение
	uint32_t DDRE		:1;			//	отключение DMA при ошибке приема
	uint32_t DEM		:1;			//	включить внешнее управление передачей
	uint32_t DEP		:1;			//	выбор полярности драйвера, 0-(DE high), 1-(DE low)
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t SCARCNT	:3;			//	количество автоповторов смарткарты
	uint32_t WUS		:2;			//	выбор режима пробуждения из СТОП режима
	uint32_t WUFIE		:1;			//	включить прерывание при пробуждении из СТОП режима
	uint32_t reserv2	:9;			//	неиспользуется
} StructUSART_CR3;

typedef union _USART_CR3			//	регистр управления 3 (USART_CR3)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_CR3 *BS;		//	Bit-Structure
} USART_CR3;

/*******************************************END (USART_CR3)*********************************************/

/************************************Baud rate register (USART_BRR)*************************************/

typedef struct _StructUSART_BRR		//	регистр скорости передачи (USART_BRR)
{
	uint32_t BRR		:16;		//	включить прерывание при пробуждении из СТОП режима
	uint32_t reserv1	:16;		//	неиспользуется
} StructUSART_BRR;

typedef union _USART_BRR			//	регистр скорости передачи (USART_BRR)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_BRR *BS;		//	Bit-Structure
} USART_BRR;

/*******************************************END (USART_BRR)*********************************************/

/*****************************Guard time and prescaler register (USART_GTPR)****************************/

typedef struct _StructUSART_GTPR	//	регистр предделителя и сторожевого времени (USART_GTPR)
{
	uint32_t PSC		:8;			//	значение предделителя
	uint32_t GT			:8;			//	значение сторожевого времени
	uint32_t reserv1	:16;		//	неиспользуется
} StructUSART_GTPR;

typedef union _USART_GTPR		//	регистр предделителя и сторожевого времени (USART_GTPR)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_GTPR *BS;		//	Bit-Structure
} USART_GTPR;

/*******************************************END (USART_GTPR)********************************************/

/*********************************Receiver timeout register (USART_RTOR)********************************/

typedef struct _StructUSART_RTOR	//	регистр таймаута приема (USART_RTOR)
{
	uint32_t RTO		:24;		//	значение таймаута приема
	uint32_t BLEN		:8;			//	длина блока
} StructUSART_RTOR;

typedef union _USART_RTOR		//	регистр таймаута приема (USART_RTOR)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_RTOR *BS;		//	Bit-Structure
} USART_RTOR;

/*******************************************END (USART_RTOR)********************************************/

/*************************************Request register (USART_RQR)**************************************/

typedef struct _StructUSART_RQR		//	регистр запроса (USART_RQR)
{
	uint32_t ABRRQ		:1;			//	запрос автоматической скорости
	uint32_t SBKRQ		:1;			//	послать запрос прекращения
	uint32_t MMRQ		:1;			//	запрос тихого режима
	uint32_t RXFRQ		:1;			//	сброс данных приема
	uint32_t TXFRQ		:1;			//	сброс данных передачи
	uint32_t reserv1	:27;		//	неиспользуется
} StructUSART_RQR;

typedef union _USART_RQR			//	регистр запроса (USART_RQR)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_RQR *BS;		//	Bit-Structure
} USART_RQR;

/*******************************************END (USART_RQR)*********************************************/

/********************************Interrupt and status register (USART_ISR)******************************/

typedef struct _StructUSART_ISR		//	регистр прерываний и статуса (USART_ISR)
{
	uint32_t PE			:1;			//	ошибка контроля четности
	uint32_t FE			:1;			//	ошибка в структуре кадра
	uint32_t NF			:1;			//	флаг обнаружения помехи
	uint32_t ORE		:1;			//	переполнение буфера приемника
	uint32_t IDLE		:1;			//	простой линии
	uint32_t RXNE		:1;			//	регистр чтения данных заполнен
	uint32_t TC			:1;			//	передача выполнена
	uint32_t TXE		:1;			//	регистр данных передатчика пуст
	uint32_t LBDF		:1;			//	флаг обнаружения разрыва LIN
	uint32_t CTSIF		:1;			//	флаг прерывания CTS
	uint32_t CTS		:1;			//	флаг CTS
	uint32_t RTOF		:1;			//	таймаут передатчика
	uint32_t EOBF		:1;			//	флаг конца блока
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t ABRE		:1;			//	ошибка автоматической настройки скорости
	uint32_t ABRF		:1;			//	флаг автоматической настройки скорости
	uint32_t BUSY		:1;			//	флаг линия занята
	uint32_t CMF		:1;			//	флаг соответствия символа
	uint32_t SBKF		:1;			//	флаг разрыва передачи
	uint32_t RWU		:1;			//	передачик пробужден из тихого режима
	uint32_t WUF		:1;			//	флаг пробуждения из стоп режима
	uint32_t TEACK		:1;			//	флаг запроса включения передачи
	uint32_t REACK		:1;			//	флаг запроса включения приема
	uint32_t reserv2	:9;			//	неиспользуется
} StructUSART_ISR;

typedef union _USART_ISR			//	регистр прерываний и статуса (USART_ISR)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_ISR *BS;		//	Bit-Structure
} USART_ISR;

/*******************************************END (USART_ISR)*********************************************/

/********************************Interrupt flag clear register (USART_ICR)******************************/

typedef struct _StructUSART_ICR		//	регистр очистки флагов прерываний (USART_ICR)
{
	uint32_t PECF		:1;			//	очистить флаг ошибки четности
	uint32_t FECF		:1;			//	очистить флаг ошибки кадра
	uint32_t NCF		:1;			//	очистить флаг помехи
	uint32_t ORECF		:1;			//	очистить флаг переполнения буфера
	uint32_t IDLECF		:1;			//	очистить флаг простоя линии
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t TCCF		:1;			//	очистить флаг выполненой передачи
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t LBDCF		:1;			//	очистить флаг разрыва линии
	uint32_t CTSCF		:1;			//	очистить флаг CTS
	uint32_t reserv3	:1;			//	неиспользуется
	uint32_t RTOCF		:1;			//	очистить флаг таймаута приемника
	uint32_t EOBCF		:1;			//	очистить флаг конца блока
	uint32_t reserv4	:4;			//	неиспользуется
	uint32_t CMCF		:1;			//	очистить флаг соответстивия символа
	uint32_t reserv5	:2;			//	неиспользуется
	uint32_t WUCF		:1;			//	очистить флаг пробуждения из стоп режима
	uint32_t reserv6	:11;		//	неиспользуется
} StructUSART_ICR;

typedef union _USART_ICR			//	регистр очистки флагов прерываний (USART_ICR)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_ICR *BS;		//	Bit-Structure
} USART_ICR;

/*******************************************END (USART_ICR)*********************************************/

/*********************************Receive data register (USART_RDR)*************************************/

typedef struct _StructUSART_RDR		//	регистр приема данных (USART_RDR)
{
	uint32_t RDR		:9;			//	значение принятых данных
	uint32_t reserv		:23;			//	неиспользуется
} StructUSART_RDR;

typedef union _USART_RDR			//	регистр приема данных (USART_RDR)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_RDR *BS;		//	Bit-Structure
} USART_RDR;

/*******************************************END (USART_RDR)*********************************************/

/*********************************Transmit data register (USART_TDR)************************************/

typedef struct _StructUSART_TDR		//	регистр передачи данных (USART_TDR)
{
	uint32_t TDR		:9;			//	значение данных передачи
	uint32_t reserv		:23;		//	неиспользуется
} StructUSART_TDR;

typedef union _USART_TDR			//	регистр передачи данных (USART_TDR)
{
	volatile uint32_t *R;				//	ссылка на регистр
	volatile StructUSART_TDR *BS;		//	Bit-Structure
} USART_TDR;

/*******************************************END (USART_TDR)*********************************************/

/*******************************************************************************************************/

typedef struct _StructUSART
{
	volatile StructUSART_CR1	CR1;		//	регистр управления 1
	volatile StructUSART_CR2	CR2;		//	регистр управления 2
	volatile StructUSART_CR3	CR3;		//	регистр управления 3
	volatile StructUSART_BRR	BRR;		//	регистр скорости передачи
	volatile StructUSART_GTPR	GTPR;		//	регистр предделителя и сторожевого времени
	volatile StructUSART_RTOR	RTOR;		//	регистр таймаута приема
	volatile StructUSART_RQR	RQR;		//	регистр запроса
	volatile StructUSART_ISR	ISR;		//	регистр прерываний и статуса
	volatile StructUSART_ICR	ICR;		//	регистр очистки флагов прерываний
	volatile StructUSART_RDR	RDR;		//	регистр приема данных
	volatile StructUSART_TDR	TDR;		//	регистр передачи данных
} const StructUSART;

#define	_USART1	((StructUSART *) 0x40013800)
#define	_USART2	((StructUSART *) 0x40004400)
#define	_USART3	((StructUSART *) 0x40004800)
#define	_USART4	((StructUSART *) 0x40004c00)

/*******************************************************************************************************/

#endif /* BSH_USART_H_ */













