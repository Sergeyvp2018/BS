/*
 * WDG.h
 *
 *  Created on: 11 нояб. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_WDG_H_
#define BSH_WDG_H_

#include "BS.h"

#define	IWDG_REFRESH      (uint32_t)(0x0000AAAA)
#define	IWDG_WRITE_ACCESS (uint32_t)(0x00005555)
#define	IWDG_START        (uint32_t)(0x0000CCCC)

/********************************Регистр ключа (IWDG_KR)*******************************************/

typedef struct _StructIWDG_KR	//	регистр ключа (IWDG_KR)
{
	uint32_t KEY		:16;	//	значение ключа (только запись, при чтении возвращает 0x0000)
	uint32_t reserv		:16;	//	неиспользуется
}StructIWDG_KR;

/**************************************************************************************************/

/*****************************Регистр предделителя (IWDG_PR)***************************************/

#define	PR_DIV4		(0b000)		//	делитель /4
#define	PR_DIV8		(0b001)		//	делитель /8
#define	PR_DIV16	(0b010)		//	делитель /16
#define	PR_DIV32	(0b011)		//	делитель /32
#define	PR_DIV64	(0b100)		//	делитель /64
#define	PR_DIV128	(0b101)		//	делитель /128
#define	PR_DIV256	(0b110)		//	делитель /256

typedef struct _StructIWDG_PR	//	регистр предделителя (IWDG_PR)
{
	uint32_t PR			:3;		//	значение ключа (только запись, при чтении возвращает 0x0000)
	uint32_t reserv		:29;	//	неиспользуется
}StructIWDG_PR;

/**************************************************************************************************/

/*******************************Регистр перезагрузки (IWDG_RLR)************************************/

typedef struct _StructIWDG_RLR	//	Регистр перезагрузки (IWDG_RLR)
{
	uint32_t RL			:12;	//	значение счетчика при перезагрузке
	uint32_t reserv		:20;	//	неиспользуется
}StructIWDG_RLR;

/**************************************************************************************************/

/*******************************Регистр статуса (IWDG_SR)******************************************/

typedef struct _StructIWDG_SR	//	регистр статуса (IWDG_SR)
{
	uint32_t PVU		:1;		//	обновлено значение предделителя watchdog
	uint32_t RVU		:1;		//	обновлено значение перезагрузки watchdog
	uint32_t WVU		:1;		//	обновлено значение окна счетчика watchdog
	uint32_t reserv		:29;	//	неиспользуется
}StructIWDG_SR;

/**************************************************************************************************/

/*******************************Оконный регистр (IWDG_WINR)****************************************/

typedef struct _StructIWDG_WINR	//	Оконный регистр (IWDG_WINR)
{
	uint32_t WIN		:12;	//	значение окна счетчика Watchdog
	uint32_t reserv		:20;	//	неиспользуется
}StructIWDG_WINR;

/******************************************END (IWDG)**********************************************/

/********************************Регистр управления (WWDG_CR)**************************************/

typedef struct _StructWWDG_CR	//	Регистр управления (WWDG_CR)
{
	uint32_t T			:6;		//	счётчик 7-bit (MSB to LSB)
	uint32_t WDGA		:1;		//	бит активации
	uint32_t reserv		:25;	//	неиспользуется
}StructWWDG_CR;

/**************************************************************************************************/

/********************************Конфигурационный регистр (WWDG_CFR)*******************************/

#define	WDGTB_DIV1	(0b00)		//	CK Counter Clock (PCLK div 4096) div 1
#define	WDGTB_DIV2	(0b01)		//	CK Counter Clock (PCLK div 4096) div 2
#define	WDGTB_DIV4	(0b10)		//	CK Counter Clock (PCLK div 4096) div 4
#define	WDGTB_DIV8	(0b11)		//	CK Counter Clock (PCLK div 4096) div 8

typedef struct _StructWWDG_CFR	//	Конфигурационный регистр (WWDG_CFR)
{
	uint32_t W			:6;		//	значение окна 7-bit
	uint32_t WDGTB		:2;		//	модификатор базового таймер
	uint32_t EWI		:1;		//	прерывание раннего пробуждения
	uint32_t reserv		:23;	//	неиспользуется
}StructWWDG_CFR;

/**************************************************************************************************/

/********************************Регистр статуса (WWDG_SR)*****************************************/

typedef struct _StructWWDG_SR	//	Регистр статуса (WWDG_SR)
{
	uint32_t EWIF		:12;	//	флаг прерывания раннего пробуждения
	uint32_t reserv		:20;	//	неиспользуется
}StructWWDG_SR;

/**************************************************************************************************/

/**************************************************************************************************/

typedef struct _StructIWDG
{
	volatile StructIWDG_KR		KR;			//	Регистр ключа (IWDG_KR)
	volatile StructIWDG_PR		PR;			//	Регистр предделителя (IWDG_PR)
	volatile StructIWDG_RLR		RLR;		//	Регистр значения перезагрузки (IWDG_RLR)
	volatile StructIWDG_SR		SR;			//	Регистр статуса (IWDG_SR)
	volatile StructIWDG_WINR	WINR;		//	Оконный регистр (IWDG_WINR)
}StructIWDG;

#define _IWDG	((StructIWDG *) 0x40003000)

typedef struct _StructWWDG
{
	volatile StructWWDG_CR		CR;			//	Регистр управления (WWDG_CR)
	volatile StructWWDG_CFR		CFR;		//	Конфигурационный регистр (WWDG_CFR)
	volatile StructWWDG_SR		SR;			//	Регистр статуса (WWDG_SR)
}StructWWDG;

#define _WWDG	((StructWWDG *) 0x40002c00)

#endif /* BSH_WDG_H_ */
















