/*
 * GPIO.h
 *
 *  Created on: 22 окт. 2020 г.
 *      Author: sergeyvp@gmail.com
 */

#ifndef BSH_GPIO_H_
#define BSH_GPIO_H_

#include "BS.h"

/**************************************************************************************
Каждый порт I/O имеет четыре конфигурационных регистра (MODER, OTYPER, OSPEEDR и PUPDR),
два 32-битных регистра данных (IDR и ODR) и 32-битный регистр сброса/установки (BSRR).
Порт A и B так же имеют 32-битный блокировочный регистр (LCKR) и два 32-битных регистра
выбора альтернативных функций (AFRH и AFRL).
В STM32F07x и STM32F09x порты C, D и E так же имеют два 32-битных регистра выбора
альтернативных функций (AFRH и AFRL).
Порт E доступен только в STM32F07x и STM32F09x.

Основные возможности GPIO
• состояние вывода: push-pull или открытый коллектор + pull-up/down
• вывод данных из соответствующего регистра (ODR) или альтернативных функций
• выбор скорости для каждого I/O
• состояние ввода: плавающее, pull-up/down, аналоговое
• ввод данных в соответствующий регистр (IDR) или альтернативные функции
• регистр установки и сброса бит (BSRR) для побитового доступа к регистру ODR
• механизм блокировки (LCKR) обеспечивает заморозку конфигурации порта A и B
• аналоговые функции
• регистры выбора альтернативных функций (возможно максимум 16 AF на каждый I/O)
• быстрое переключение в два такта
• очень гибкое мультиплексирование пинов позволяет использовать I/O как GPIOs
  или как переферийные функции

Назначение регистров BSRR и BRR в атомарном доступе к ODR.
Это позволяет избежать риска возникновения прерывания в промежуточном состоянии.

Все GPIO выводы имеют маломощные внутренние резисторы pull-up и pull-down, которые
можно активировать или деактивировать в регистре PUPDR.

С целью повышения читаемости кода в библиотеки применены имена структур отличные
от имён соответствующиъх им регистров:

BSRR (первые 16 бит) соответствует структуре SETR
BRR соответствует структуре RESETR
ODR соответствует структуре OUTPUTR
IDR соответствует структуре INPUTR

**************************************************************************************/

#define	_GPIOA	((StructGPIO *) 0x48000000)
#define	_GPIOB	((StructGPIO *) 0x48000400)
#define	_GPIOC	((StructGPIO *) 0x48000800)
#define	_GPIOD	((StructGPIO *) 0x48000c00)
#define	_GPIOE	((StructGPIO *) 0x48001000)
#define	_GPIOF	((StructGPIO *) 0x48001400)

#define	InputMOD		(0b00)	//	Режим ввода (по умолчанию)
#define	OutputMOD		(0b01)	//	Вывод общего использования
#define	AFMOD			(0b10)	//	Режим альтернативной функции
#define	AnalogMOD		(0b11)	//	Аналаоговый режим

#define	NoPUPD			(0b00)	//	No pull-up, pull-down
#define	PullUP			(0b01)	//	Pull-up
#define	PullDOWN		(0b10)	//	Pull-down

#define	LowSpeed		(0b00)	//	низкая скорость Low speed
#define	MediumSpeed		(0b01)	//	средняя скорость Medium speed
#define	HighSpeed		(0b11)	//	высокая скорость High speed

#define	OutOpenDrain	1	//	вывод с открытым коллектором
#define	OutPushPull		0	//	вывод с подтяжкой

#define AF0		(0b0000)	//	альтернативная функция 0
#define AF1		(0b0001)	//	альтернативная функция 1
#define AF2		(0b0010)	//	альтернативная функция 2
#define AF3		(0b0011)	//	альтернативная функция 3
#define AF4		(0b0100)	//	альтернативная функция 4
#define AF5		(0b0101)	//	альтернативная функция 5
#define AF6		(0b0110)	//	альтернативная функция 6
#define AF7		(0b0111)	//	альтернативная функция 7

typedef struct _Struct16x2
{
	uint32_t Pin0		:2;		//
	uint32_t Pin1		:2;		//
	uint32_t Pin2		:2;		//
	uint32_t Pin3		:2;		//
	uint32_t Pin4		:2;		//
	uint32_t Pin5		:2;		//
	uint32_t Pin6		:2;		//
	uint32_t Pin7		:2;		//
	uint32_t Pin8		:2;		//
	uint32_t Pin9		:2;		//
	uint32_t Pin10		:2;		//
	uint32_t Pin11		:2;		//
	uint32_t Pin12		:2;		//
	uint32_t Pin13		:2;		//
	uint32_t Pin14		:2;		//
	uint32_t Pin15		:2;		//
} Struct16x2;

typedef struct _Struct16
{
	uint32_t Pin0		:1;		//
	uint32_t Pin1		:1;		//
	uint32_t Pin2		:1;		//
	uint32_t Pin3		:1;		//
	uint32_t Pin4		:1;		//
	uint32_t Pin5		:1;		//
	uint32_t Pin6		:1;		//
	uint32_t Pin7		:1;		//
	uint32_t Pin8		:1;		//
	uint32_t Pin9		:1;		//
	uint32_t Pin10		:1;		//
	uint32_t Pin11		:1;		//
	uint32_t Pin12		:1;		//
	uint32_t Pin13		:1;		//
	uint32_t Pin14		:1;		//
	uint32_t Pin15		:1;		//
	uint32_t reserv		:16;	//	неиспользуется
} Struct16;

typedef struct _StructGPIO_AFRL
{
	uint32_t Pin0		:4;		//
	uint32_t Pin1		:4;		//
	uint32_t Pin2		:4;		//
	uint32_t Pin3		:4;		//
	uint32_t Pin4		:4;		//
	uint32_t Pin5		:4;		//
	uint32_t Pin6		:4;		//
	uint32_t Pin7		:4;		//
} StructGPIO_AFRL;

typedef struct _StructGPIO_AFRH
{
	uint32_t Pin8		:4;		//
	uint32_t Pin9		:4;		//
	uint32_t Pin10		:4;		//
	uint32_t Pin11		:4;		//
	uint32_t Pin12		:4;		//
	uint32_t Pin13		:4;		//
	uint32_t Pin14		:4;		//
	uint32_t Pin15		:4;		//
} StructGPIO_AFRH;

/*************************************************************************************/

typedef struct _StructGPIO
{
	volatile Struct16x2			MODER;		//	регистр режимов соответствующего порта
	volatile Struct16			OTYPER;		//	регистр типа вывода (1 - open-drain, 0 - push-pull)
	volatile Struct16x2			OSPEEDR;	//	регистр скорости вывода
	volatile Struct16x2			PUPDR;		//	регистр режимов подтяжки порта
	volatile Struct16			INPUTR;		//	регистр ввода данных порта
	volatile Struct16			OUTPUTR;	//	регистр вывода данных порта
	volatile Struct16			SETR;		//	регистр установки пина в высокий уровень (BSRR)
	volatile Struct16			LCKR;		//	регистр блокировки конфигурации пинов
	volatile StructGPIO_AFRL	AFRL;		//	нижний регистр альтернативных функций
	volatile StructGPIO_AFRH	AFRH;		//	верхний регистр альтернативных функций
	volatile Struct16			RESETR;		//	регистр сброса пина в 0 (BRR)
}StructGPIO;

/*************************************************************************************/

#endif /* BSH_GPIO_H_ */
