/*
 * DMA.h
 *
 *  Created on: 28 нояб. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_DMA_H_
#define BSH_DMA_H_

#include "BS.h"

/***************************DMA interrupt status register (DMA_ISR and DMA2_ISR)***************************/

typedef struct _StructDMA_ISR		//	регистр прерываний и статуса (DMA_ISR)
{
	uint32_t GIF1		:1;			//	флаг глобального прерывания канал 1
	uint32_t TCIF1		:1;			//	флаг завершения передачи канал 1
	uint32_t HTIF1		:1;			//	флаг полупередачи канал 1
	uint32_t TEIF1		:1;			//	флаг ошибки передачи канал 1
	uint32_t GIF2		:1;			//	флаг глобального прерывания канал 2
	uint32_t TCIF2		:1;			//	флаг завершения передачи канал 2
	uint32_t HTIF2		:1;			//	флаг полупередачи канал 2
	uint32_t TEIF2		:1;			//	флаг ошибки передачи канал 2
	uint32_t GIF3		:1;			//	флаг глобального прерывания канал 3
	uint32_t TCIF3		:1;			//	флаг завершения передачи канал 3
	uint32_t HTIF3		:1;			//	флаг полупередачи канал 3
	uint32_t TEIF3		:1;			//	флаг ошибки передачи канал 3
	uint32_t GIF4		:1;			//	флаг глобального прерывания канал 4
	uint32_t TCIF4		:1;			//	флаг завершения передачи канал 4
	uint32_t HTIF4		:1;			//	флаг полупередачи канал 4
	uint32_t TEIF4		:1;			//	флаг ошибки передачи канал 4
	uint32_t GIF5		:1;			//	флаг глобального прерывания канал 5
	uint32_t TCIF5		:1;			//	флаг завершения передачи канал 5
	uint32_t HTIF5		:1;			//	флаг полупередачи канал 5
	uint32_t TEIF5		:1;			//	флаг ошибки передачи канал 5
	uint32_t GIF6		:1;			//	флаг глобального прерывания канал 6
	uint32_t TCIF6		:1;			//	флаг завершения передачи канал 6
	uint32_t HTIF6		:1;			//	флаг полупередачи канал 6
	uint32_t TEIF6		:1;			//	флаг ошибки передачи канал 6
	uint32_t GIF7		:1;			//	флаг глобального прерывания канал 7
	uint32_t TCIF7		:1;			//	флаг завершения передачи канал 7
	uint32_t HTIF7		:1;			//	флаг полупередачи канал 7
	uint32_t TEIF7		:1;			//	флаг ошибки передачи канал 7
	uint32_t reserv1	:4;			//	неиспользуется
} StructDMA_ISR;

/**********************************************************************************************************/

/***********************DMA interrupt flag clear register (DMA_IFCR and DMA2_IFCR)*************************/

typedef struct _StructDMA_IFCR		//	регистр очистки флагов прерываний (DMA_IFCR)
{
	uint32_t CGIF1		:1;			//	очистить флаг глобального прерывания канал 1
	uint32_t CTCIF1		:1;			//	очистить флаг завершения передачи канал 1
	uint32_t CHTIF1		:1;			//	очистить флаг полупередачи канал 1
	uint32_t CTEIF1		:1;			//	очистить флаг ошибки передачи канал 1
	uint32_t CGIF2		:1;			//	очистить флаг глобального прерывания канал 2
	uint32_t CTCIF2		:1;			//	очистить флаг завершения передачи канал 2
	uint32_t CHTIF2		:1;			//	очистить флаг полупередачи канал 2
	uint32_t CTEIF2		:1;			//	очистить флаг ошибки передачи канал 2
	uint32_t CGIF3		:1;			//	очистить флаг глобального прерывания канал 3
	uint32_t CTCIF3		:1;			//	очистить флаг завершения передачи канал 3
	uint32_t CHTIF3		:1;			//	очистить флаг полупередачи канал 3
	uint32_t CTEIF3		:1;			//	очистить флаг ошибки передачи канал 3
	uint32_t CGIF4		:1;			//	очистить флаг глобального прерывания канал 4
	uint32_t CTCIF4		:1;			//	очистить флаг завершения передачи канал 4
	uint32_t CHTIF4		:1;			//	очистить флаг полупередачи канал 4
	uint32_t CTEIF4		:1;			//	очистить флаг ошибки передачи канал 4
	uint32_t CGIF5		:1;			//	очистить флаг глобального прерывания канал 5
	uint32_t CTCIF5		:1;			//	очистить флаг завершения передачи канал 5
	uint32_t CHTIF5		:1;			//	очистить флаг полупередачи канал 5
	uint32_t CTEIF5		:1;			//	очистить флаг ошибки передачи канал 5
	uint32_t CGIF6		:1;			//	очистить флаг глобального прерывания канал 6
	uint32_t CTCIF6		:1;			//	очистить флаг завершения передачи канал 6
	uint32_t CHTIF6		:1;			//	очистить флаг полупередачи канал 6
	uint32_t CTEIF6		:1;			//	очистить флаг ошибки передачи канал 6
	uint32_t CGIF7		:1;			//	очистить флаг глобального прерывания канал 7
	uint32_t CTCIF7		:1;			//	очистить флаг завершения передачи канал 7
	uint32_t CHTIF7		:1;			//	очистить флаг полупередачи канал 7
	uint32_t CTEIF7		:1;			//	очистить флаг ошибки передачи канал 7
	uint32_t reserv1	:4;			//	неиспользуется
} StructDMA_IFCR;

/**********************************************************************************************************/

/*********************DMA channel x configuration register (DMA_CCRx and DMA2_CCRx)************************/

#define	PSIZE_00	(0b00)	//	8-bits
#define	PSIZE_01	(0b01)	//	16-bits
#define	PSIZE_10	(0b10)	//	32-bits

#define	MSIZE_00	(0b00)	//	8-bits
#define	MSIZE_01	(0b01)	//	16-bits
#define	MSIZE_10	(0b10)	//	32-bits

#define	PL_00		(0b00)	//	Low
#define	PL_01		(0b01)	//	Medium
#define	PL_10		(0b10)	//	High
#define	PL_11		(0b11)	//	Very high

typedef struct _StructDMA_CCR		//	регистр конфигурации (DMA_CCR)
{
	uint32_t EN			:1;			//	включить канал
	uint32_t TCIE		:1;			//	включить прерывание при выполнении передачи
	uint32_t HTIE		:1;			//	включить прерывание полупередачи
	uint32_t TEIE		:1;			//	включить прерывание при ошибке передачи
	uint32_t DIR		:1;			//	направление передачи данных
	uint32_t CIRC		:1;			//	режим циркуляции
	uint32_t PINC		:1;			//	периферийный режим приращения
	uint32_t MINC		:1;			//	режим приращения памяти
	uint32_t PSIZE		:2;			//	размер переферии
	uint32_t MSIZE		:2;			//	размер памяти
	uint32_t PL			:2;			//	приоритет канала
	uint32_t MEM2MEM	:1;			//	режим память в память
	uint32_t reserv1	:17;		//	неиспользуется
} StructDMA_CCR;

/**********************************************************************************************************/

/********************DMA channel x number of data register (DMA_CNDTRx and DMA2_CNDTRx)********************/

typedef struct _StructDMA_CNDTR		//	регистр данных (DMA_CNDTR)
{
	uint32_t NDT		:16;		//	количество данных для передачи (от 0 до 65535)
	uint32_t reserv1	:16;		//	неиспользуется
} StructDMA_CNDTR;

/**********************************************************************************************************/

/******************DMA channel x peripheral address register (DMA_CPARx and DMA2_CPARx)********************/

typedef struct _StructDMA_CPAR		//	регистр адреса переферии (DMA_CPAR)
{
	uint32_t PA			:32;		//	адрес переферии
} StructDMA_CPAR;

/**********************************************************************************************************/

/********************DMA channel x memory address register (DMA_CMARx and DMA2_CMARx)**********************/

typedef struct _StructDMA_CMAR		//	регистр адреса памяти (DMA_CMAR)
{
	uint32_t MA			:32;		//	адрес переферии
} StructDMA_CMAR;

/**********************************************************************************************************/

/************************DMA channel selection register (DMA_CSELR and DMA2_CSELR)*************************/
/****************************This register is present only on STM32F09x devices****************************/

typedef struct _StructDMA_CSELR		//	регистр выбора канала (DMA_CSELR)
{
	uint32_t C1S		:4;			//	выбор канала
	uint32_t C2S		:4;			//	выбор канала
	uint32_t C3S		:4;			//	выбор канала
	uint32_t C4S		:4;			//	выбор канала
	uint32_t C5S		:4;			//	выбор канала
	uint32_t C6S		:4;			//	выбор канала
	uint32_t C7S		:4;			//	выбор канала
	uint32_t reserv1	:4;			//	неиспользуется
} StructDMA_CSELR;

/**********************************************************************************************************/

/**********************************************************************************************************/

typedef struct _StructDMA_Channel
{
	volatile StructDMA_CCR		CCR;		//	регистр конфигурации (DMA_CCR)
	volatile StructDMA_CNDTR	CNDTR1;		//	регистр данных (DMA_CNDTR)
	volatile StructDMA_CPAR		CPAR1;		//	регистр адреса переферии (DMA_CPAR)
	volatile StructDMA_CMAR		CMAR1;		//	регистр адреса памяти канал 1 (DMA_CMAR)
} StructDMA_Channel;

typedef struct _StructDMA
{
	volatile StructDMA_ISR		ISR;		//	регистр прерываний и статуса (DMA_ISR)
	volatile StructDMA_IFCR		IFCR;		//	регистр очистки флагов прерываний (DMA_IFCR)
	uint32_t					RESERV[40];	//	зарезервировано для декларации каналов 0x08 - 0xA4
	volatile StructDMA_CSELR	CSELR;		//	регистр выбора канала (DMA_CSELR)
} StructDMA;

#define _DMA1		((StructDMA *) (0x40020000))
#define _DMA1_Ch1	((StructDMA_Channel *) (0x40020000 + 0x00000008UL))
#define _DMA1_Ch2	((StructDMA_Channel *) (0x40020000 + 0x0000001CUL))
#define _DMA1_Ch3	((StructDMA_Channel *) (0x40020000 + 0x00000030UL))
#define _DMA1_Ch4	((StructDMA_Channel *) (0x40020000 + 0x00000044UL))
#define _DMA1_Ch5	((StructDMA_Channel *) (0x40020000 + 0x00000058UL))
#define _DMA1_Ch6	((StructDMA_Channel *) (0x40020000 + 0x0000006CUL))
#define _DMA1_Ch7	((StructDMA_Channel *) (0x40020000 + 0x00000080UL))

#define _DMA2		((StructDMA *) (0x40020400))
#define _DMA2_Ch1	((StructDMA_Channel *) (0x40020400 + 0x00000008UL))
#define _DMA2_Ch2	((StructDMA_Channel *) (0x40020400 + 0x0000001CUL))
#define _DMA2_Ch3	((StructDMA_Channel *) (0x40020400 + 0x00000030UL))
#define _DMA2_Ch4	((StructDMA_Channel *) (0x40020400 + 0x00000044UL))
#define _DMA2_Ch5	((StructDMA_Channel *) (0x40020400 + 0x00000058UL))

/**********************************************************************************************************/

#endif /* BSH_DMA_H_ */






















