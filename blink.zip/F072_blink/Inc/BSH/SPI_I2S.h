/*
 * SPI_I2S.h
 *
 *  Created on: 1 дек. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_SPI_I2S_H_
#define BSH_SPI_I2S_H_

#include "BS.h"

/*******************************SPI control register 1 (SPIx_CR1)******************************************/

#define	BR_PCLK_2		(0b000)		//	f PCLK /2
#define	BR_PCLK_4		(0b001)		//	f PCLK /4
#define	BR_PCLK_8		(0b010)		//	f PCLK /8
#define	BR_PCLK_16		(0b011)		//	f PCLK /16
#define	BR_PCLK_32		(0b100)		//	f PCLK /32
#define	BR_PCLK_64		(0b101)		//	f PCLK /64
#define	BR_PCLK_128		(0b110)		//	f PCLK /128
#define	BR_PCLK_256		(0b111)		//	f PCLK /256

typedef struct _StructSPI_CR1		//	1 регистр управления (SPI_CR1)
{
	uint32_t CPHA		:1;			//	фаза такта
	uint32_t CPOL		:1;			//	полярность тактирования
	uint32_t MSTR		:1;			//	выбо конфигурации, 0-ведомый, 1-мастер
	uint32_t BR			:3;			//	контроль скорости передачи
	uint32_t SPE		:1;			//	включить SPI
	uint32_t LSBFIRST	:1;			//	формат кадра
	uint32_t SSI		:1;			//	блокирует NSS пин
	uint32_t SSM		:1;			//	програмное управление ведомым
	uint32_t RXONLY		:1;			//	включить только прием данных
	uint32_t CRCL		:1;			//	0-8-bit CRC, 1-16-bit CRC
	uint32_t CRCNEXT	:1;			//	0-передача из буфера, 1-передача из регистра CRC
	uint32_t CRCEN		:1;			//	аппаратный расчет CRC
	uint32_t BIDIOE		:1;			//	вкл.\выкл. вывод
	uint32_t BIDIMODE	:1;			//	полудуплексная связь
	uint32_t reserv		:16;		//	неиспользуется
} StructSPI_CR1;

/**********************************************************************************************************/

/*******************************SPI control register 2 (SPIx_CR2)******************************************/

#define	DS_4bit		(0b0011)	//	4-bit
#define	DS_5bit		(0b0100)	//	5-bit
#define	DS_6bit		(0b0101)	//	6-bit
#define	DS_7bit		(0b0110)	//	7-bit
#define	DS_8bit		(0b0111)	//	8-bit
#define	DS_9bit		(0b1000)	//	9-bit
#define	DS_10bit	(0b1001)	//	10-bit
#define	DS_11bit	(0b1010)	//	11-bit
#define	DS_12bit	(0b1011)	//	12-bit
#define	DS_13bit	(0b1100)	//	13-bit
#define	DS_14bit	(0b1101)	//	14-bit
#define	DS_15bit	(0b1110)	//	15-bit
#define	DS_16bit	(0b1111)	//	16-bit

typedef struct _StructSPI_CR2		//	2 регистр управления (SPI_CR2)
{
	uint32_t RXDMAEN	:1;			//	включить буфер приема DMA
	uint32_t TXDMAEN	:1;			//	включить буфер передачи DMA
	uint32_t SSOE		:1;			//	включить вывод SS
	uint32_t NSSP		:1;			//	управление NSS, 0-импульсы не генерируются
	uint32_t FRF		:1;			//	формат кадра
	uint32_t ERRIE		:1;			//	включить прерывание при ошибке
	uint32_t RXNEIE		:1;			//	прерывание при заполнении буфера приема
	uint32_t TXEIE		:1;			//	прерывание при опустошении буфера передачи
	uint32_t DS			:4;			//	размер данных в битах
	uint32_t FRXTH		:1;			//	порог приема FIFO
	uint32_t LDMA_RX	:1;			//	последняя передача DMA для приема
	uint32_t LDMA_TX	:1;			//	последняя передача DMA для передачи
	uint32_t reserv		:17;		//	неиспользуется
} StructSPI_CR2;

/**********************************************************************************************************/

/*******************************SPI status register (SPIx_SR)**********************************************/

#define	FLVL_00	(0b00)	//	FIFO empty
#define	FLVL_01	(0b01)	//	1/4 FIFO
#define	FLVL_10	(0b10)	//	1/2 FIFO
#define	FLVL_11	(0b11)	//	FIFO full

typedef struct _StructSPI_SR		//	регистр статуса (SPI_SR)
{
	uint32_t RXNE		:1;			//	буфер приёма не пустой
	uint32_t TXE		:1;			//	буфер отправления пуст
	uint32_t CHSIDE		:1;			//	сторона канала (не используется в режиме SPI)
	uint32_t UDR		:1;			//	заземление (не используется в режиме SPI)
	uint32_t CRCERR		:1;			//	ошибка CRC
	uint32_t MODF		:1;			//	ошибка режима
	uint32_t OVR		:1;			//	переполнение
	uint32_t BSY		:1;			//	шина занята
	uint32_t FRE		:1;			//	ошибка формата кадра
	uint32_t FRLVL		:2;			//	уровень принимающего FIFO
	uint32_t FTLVL		:2;			//	уровень передающего FIFO
	uint32_t reserv		:19;		//	неиспользуется
} StructSPI_SR;

/**********************************************************************************************************/

/*******************************SPI data register (SPIx_DR)************************************************/

typedef struct _StructSPI_DR		//	регистр данных (SPI_DR)
{
	uint32_t DR			:16;		//	регистр данных
	uint32_t reserv		:16;		//	неиспользуется
} StructSPI_DR;

/**********************************************************************************************************/

/*******************************SPI CRC polynomial register (SPIx_CRCPR)***********************************/

typedef struct _StructSPI_CRCPR		//	полиномиальный регистр (SPI_CRCPR)
{
	uint32_t CRCPOLY	:16;		//	полиномиальный регистр CRC
	uint32_t reserv		:16;		//	неиспользуется
} StructSPI_CRCPR;

/**********************************************************************************************************/

/*******************************SPI Rx CRC register (SPIx_RXCRCR)******************************************/

typedef struct _StructSPI_RXCRCR	//	CRC регистр приема (SPI_RXCRCR)
{
	uint32_t RXCRC		:16;		//	регистр CRC
	uint32_t reserv		:16;		//	неиспользуется
} StructSPI_RXCRCR;

/**********************************************************************************************************/

/*******************************SPI Tx CRC register (SPIx_TXCRCR)******************************************/

typedef struct _StructSPI_TXCRCR	//	CRC регистр передачи (SPI_TXCRCR)
{
	uint32_t TXCRC		:16;		//	регистр CRC
	uint32_t reserv		:16;		//	неиспользуется
} StructSPI_TXCRCR;

/**********************************************************************************************************/

/*******************************SPIx_I2S configuration register (SPIx_I2SCFGR)*****************************/

#define	DATLEN_00	(0b00)	//	16-bit data length
#define	DATLEN_01	(0b01)	//	24-bit data length
#define	DATLEN_10	(0b10)	//	32-bit data length

#define	I2SSTD_00	(0b00)	//	I2S Philips standard.
#define	I2SSTD_01	(0b01)	//	MSB justified standard (left justified)
#define	I2SSTD_10	(0b10)	//	LSB justified standard (right justified)
#define	I2SSTD_11	(0b11)	//	PCM standard

#define	I2SCFG_00	(0b00)	//	Slave - transmit
#define	I2SCFG_01	(0b01)	//	Slave - receive
#define	I2SCFG_10	(0b10)	//	Master - transmit
#define	I2SCFG_11	(0b11)	//	Master - receive

typedef struct _StructSPI_I2SCFGR	//	конфигурационный регистр (SPI_I2SCFGR)
{
	uint32_t CHLEN		:1;			//	кол-во бит в аудио канале
	uint32_t DATLEN		:2;			//	длина данных для передачи
	uint32_t CKPOL		:1;			//	полярность в неактивном состоянии
	uint32_t I2SSTD		:2;			//	выбор стандарта I2S
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t PCMSYNC	:1;			//	синхронизация кадров PCM
	uint32_t I2SCFG		:2;			//	режим конфигурации I2S
	uint32_t I2SE		:1;			//	включить I2S
	uint32_t I2SMOD		:1;			//	выбор режима, 1-I2S, 0-SPI (поумолчанию)
	uint32_t reserv2	:20;		//	неиспользуется
} StructSPI_I2SCFGR;

/**********************************************************************************************************/

/*******************************SPIx_I2S prescaler register (SPIx_I2SPR)*********************************/

typedef struct _StructSPI_I2SPR		//	конфигурационный регистр (SPI_I2SPR)
{
	uint32_t I2SDIV		:8;			//	линейный предделитель
	uint32_t ODD		:1;			//	нечетный коэффициент для предварительного делителя
	uint32_t MCKOE		:1;			//	включение выхода тактовой частоты
	uint32_t reserv		:22;		//	неиспользуется
} StructSPI_I2SPR;

/**********************************************************************************************************/

/**********************************************************************************************************/

typedef struct _StructSPI_I2S
{
	volatile StructSPI_CR1			CR1;		//	1 регистр управления (SPI_CR1)
	volatile StructSPI_CR2			CR2;		//	2 регистр управления (SPI_CR2)
	volatile StructSPI_SR			SR;			//	регистр статуса (SPI_SR)
	volatile StructSPI_DR			DR;			//	регистр данных (SPI_DR)
	volatile StructSPI_CRCPR		CRCPR;		//	полиномиальный регистр (SPI_CRCPR)
	volatile StructSPI_RXCRCR		RXCRCR;		//	CRC регистр приема (SPI_RXCRCR)
	volatile StructSPI_TXCRCR		TXCRCR;		//	CRC регистр передачи (SPI_TXCRCR)
	volatile StructSPI_I2SCFGR		I2SCFGR;	//	конфигурационный регистр (SPI_I2SCFGR)
	volatile StructSPI_I2SPR		I2SPR;		//	конфигурационный регистр (SPI_I2SCFGR)
}StructSPI_I2S;

#define _SPI1	((StructSPI_I2S *) 0x40013000)
#define _SPI2	((StructSPI_I2S *) 0x40003800)

/**********************************************************************************************************/


#endif /* BSH_SPI_I2S_H_ */

























