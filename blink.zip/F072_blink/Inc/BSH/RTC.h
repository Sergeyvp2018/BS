/*
 * RTC.h
 *
 *  Created on: 14 нояб. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_RTC_H_
#define BSH_RTC_H_

#include "BS.h"

/**************************************RTC time register (RTC_TR)**************************************/

#define	BCD_1	(0b0001)
#define BCD_2	(0b0010)
#define BCD_3	(0b0011)
#define BCD_4	(0b0100)
#define BCD_5	(0b0101)
#define BCD_6	(0b0110)
#define BCD_7	(0b0111)
#define BCD_8	(0b1000)
#define BCD_9	(0b1001)

typedef struct _StructRTC_TR	//	RTC time register (RTC_TR)
{
	uint32_t SU			:4;		//	единицы секунд в BCD формате
	uint32_t ST			:3;		//	десятки секунд в BCD формате
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t MNU		:4;		//	единицы минут в BCD формате
	uint32_t MNT		:3;		//	десятки минут в BCD формате
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t HU			:4;		//	единицы часов в BCD формате
	uint32_t HT			:3;		//	десятки часов в BCD формате
	uint32_t PM			:1;		//	0 - AM или 24 часовой формат, 1 - PM
	uint32_t reserv3	:9;		//	неиспользуется
} StructRTC_TR;

/**********************************************END (RTC_TR)********************************************/

/**************************************RTC date register (RTC_DR)**************************************/

typedef struct _StructRTC_DR	//	RTC date register (RTC_DR)
{
	uint32_t DU			:4;		//	единиц дней в BCD формате
	uint32_t DT			:2;		//	десятки дней в BCD формате
	uint32_t reserv1	:2;		//	неиспользуется
	uint32_t MU			:4;		//	единицы месяца в BCD формате
	uint32_t MT			:1;		//	десятки месяца в BCD формате
	uint32_t WDU		:3;		//	день недели
	uint32_t YU			:4;		//	единицы года в BCD формате
	uint32_t YT			:4;		//	десятки лет в BCD формате
	uint32_t reserv2	:8;		//	неиспользуется
} StructRTC_DR;

/**********************************************END (RTC_DR)********************************************/

/*************************************RTC control register (RTC_CR)************************************/

#define	WUCKSEL_RTC_16	(0b000)		//	тактирование RTC/16
#define	WUCKSEL_RTC_8	(0b001)		//	тактирование RTC/8
#define	WUCKSEL_RTC_4	(0b010)		//	тактирование RTC/4
#define	WUCKSEL_RTC_2	(0b011)		//	тактирование RTC/2
#define	WUCKSEL_1Hz		(0b100)		//	тактирование ck_spre (обычно 1 Hz)
#define	WUCKSEL_1HzP	(0b110)		//	тактирование ck_spre (обычно 1 Hz) + 0x10000 к счетчику WUT

#define	OSEL_OFF	(0b00)		//	вывод выключен
#define	OSEL_A		(0b01)		//	вывод будильника А
#define	OSEL_WU		(0b11)		//	вывод пробуждения

typedef struct _StructRTC_CR	//	RTC регистр управления (RTC_CR)
{
	uint32_t WUCKSEL	:3;		//	тактирование пробуждения
	uint32_t TSEDGE		:1;		//	восходящий или нисходящий сигнал генерирует событие временной отметки
	uint32_t REFCKON	:1;		//	включить обнаружение опорных часов
	uint32_t BYPSHAD	:1;		//	обход теневых регистров, 1 - значение календаря устанавливается напрямую из счётчика
	uint32_t FMT		:1;		//	0 - 24 часовой формат, AM/PM формат
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t ALRAE		:1;		//	будильник А вкл./выкл.
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t WUTE		:1;		//	таймер пробуждения вкл./выкл.
	uint32_t TSE		:1;		//	временная отметка вкл./выкл.
	uint32_t ALRAIE		:1;		//	прерывание по будульнику А
	uint32_t reserv3	:1;		//	неиспользуется
	uint32_t WUTIE		:1;		//	прерывание по таймеру пробуждения
	uint32_t TSIE		:1;		//	прерывание по временной отметки
	uint32_t ADD1H		:1;		//	переход на летнее время
	uint32_t SUB1H		:1;		//	переход на зимнее время
	uint32_t BKP		:1;		//	сохранение параметров
	uint32_t COSEL		:1;		//	калибровка вывода
	uint32_t POL		:1;		//	полярность вывода
	uint32_t OSEL		:2;		//	выбор вывода
	uint32_t COE		:1;		//	включить калибровку вывода
	uint32_t reserv4	:8;		//	неиспользуется
} StructRTC_CR;

/**********************************************END (RTC_CR)********************************************/

/*****************************RTC initialization and status register (RTC_ISR)*************************/

typedef struct _StructRTC_ISR	//	RTC initialization and status register (RTC_ISR)
{
	uint32_t ALRAWF		:1;		//	флаг будильника А, 0 - запись запрещена, 1 - разрешена
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t WUTWF		:1;		//	флаг записи таймера пробуждения
	uint32_t SHPF		:1;		//	флаг записи в регистр RTC_SHIFTR
	uint32_t INITS		:1;		//	флаг статуса инициализации календаря
	uint32_t RSF		:1;		//	флаг синхронизации регистров
	uint32_t INITF		:1;		//	флаг разрешающий инициализацию календаря
	uint32_t INIT		:1;		//	режим инициализации
	uint32_t ALRAF		:1;		//	флаг будильника А
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t WUTF		:1;		//	флаг таймера пробуждения
	uint32_t TSF		:1;		//	флаг события соответствия отметки времени
	uint32_t TSOVF		:1;		//	флаг события соответсвия отметки времени произошедшее при установленном флаге TSF
	uint32_t TAMP1F		:1;		//	флаг обнаружения ввода RTC_TAMP1
	uint32_t TAMP2F		:1;		//	флаг обнаружения ввода RTC_TAMP2
	uint32_t TAMP3F		:1;		//	флаг обнаружения ввода RTC_TAMP3
	uint32_t RECALPF	:1;		//	флаг ожидания калибровки
	uint32_t reserv3	:15;	//	неиспользуется
} StructRTC_ISR;

/**********************************************END (RTC_ISR)*******************************************/

/***********************************RTC prescaler register (RTC_PRER)**********************************/

typedef struct _StructRTC_PRER	//	RTC prescaler register (RTC_PRER)
{
	uint32_t PREDIV_S	:14;	//	синхронный предделитель
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t PREDIV_A	:7;		//	асинхронный предделитель
	uint32_t reserv2	:9;		//	неиспользуется
} StructRTC_PRER;

/**********************************************END (RTC_PRER)******************************************/

/**********************************RTC wakeup timer register (RTC_WUTR)********************************/
//	доступен только в stm32f0[37]x[BC]

typedef struct _StructRTC_WUTR	//	RTC wakeup timer register (RTC_WUTR)
{
	uint32_t WUT		:16;	//	значение периода пробуждения
	uint32_t reserv1	:16;	//	неиспользуется
} StructRTC_WUTR;

/*********************************************END (RTC_WUTR)*******************************************/

/***********************************RTC alarm A register (RTC_ALRMAR)**********************************/

typedef struct _StructRTC_ALRMAR	//	RTC регистр будильника A (RTC_ALRMAR)
{
	uint32_t SU			:4;		//	единицы секунд в BCD формате
	uint32_t ST			:3;		//	десятки секунд в BCD формате
	uint32_t MSK1		:1;		//	1 - секунды игнорируются
	uint32_t MNU		:4;		//	единицы минут в BCD формате
	uint32_t MNT		:3;		//	десятки минут в BCD формате
	uint32_t MSK2		:1;		//	1 - минуты игнорируются
	uint32_t HU			:4;		//	единицы часов в BCD формате
	uint32_t HT			:2;		//	десятки часов в BCD формате
	uint32_t PM			:1;		//	0 - 24 часовой формат или AM, 1 - PM
	uint32_t MSK3		:1;		//	1 - часы игнорируются
	uint32_t DU			:4;		//	единицы даты в BCD формате
	uint32_t DT			:2;		//	десятки даты в BCD формате
	uint32_t WDSEL		:1;		//	день недели
	uint32_t MSK4		:1;		//	дата игнорируется
} StructRTC_ALRMAR;

/********************************************END (RTC_ALRMAR)******************************************/

/********************************RTC write protection register (RTC_WPR)*******************************/

typedef struct _StructRTC_WPR	//	RTC write protection register (RTC_WPR)
{
	uint32_t KEY		:8;		//	ключ защиты от записи
	uint32_t reserv1	:24;	//	неиспользуется
} StructRTC_WPR;

/**********************************************END (RTC_WPR)*******************************************/

/**********************************RTC sub second register (RTC_SSR)***********************************/

typedef struct _StructRTC_SSR	//	RTC sub second register (RTC_SSR)
{
	uint32_t SS			:16;	//	значение субсекунд
	uint32_t reserv1	:16;	//	неиспользуется
} StructRTC_SSR;

/**********************************************END (RTC_SSR)*******************************************/

/*******************************RTC shift control register (RTC_SHIFTR)********************************/

typedef struct _StructRTC_SHIFTR//	RTC shift control register (RTC_SHIFTR)
{
	uint32_t SUBFS		:15;	//	вычесть долю секунды
	uint32_t reserv1	:16;	//	неиспользуется
	uint32_t ADD1S		:1;		//	добавить одну секунду
} StructRTC_SHIFTR;

/**********************************************END (RTC_SHIFTR)****************************************/

/*******************************RTC timestamp time register (RTC_TSTR)*********************************/

typedef struct _StructRTC_TSTR	//	RTC timestamp time register (RTC_TSTR)
{
	uint32_t SU			:4;		//	единицы секунд в BCD формате
	uint32_t ST			:3;		//	десятки секунд в BCD формате
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t MNU		:4;		//	единицы минут в BCD формате
	uint32_t MNT		:3;		//	десятки минут в BCD формате
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t HU			:4;		//	единицы часов в BCD формате
	uint32_t HT			:2;		//	десятки часов в BCD формате
	uint32_t PM			:1;		//	0 - 24 часовой формат или AM, 1 - PM
	uint32_t reserv3	:9;		//	неиспользуется
} StructRTC_TSTR;

/**********************************************END (RTC_TSTR)******************************************/

/*******************************RTC timestamp date register (RTC_TSDR)*********************************/

typedef struct _StructRTC_TSDR	//	RTC timestamp date register (RTC_TSDR)
{
	uint32_t DU			:4;		//	единицы дней в BCD формате
	uint32_t DT			:3;		//	десятки дней в BCD формате
	uint32_t MU			:4;		//	единицы месяцев в BCD формате
	uint32_t MT			:1;		//	десяток месяцев в BCD формате
	uint32_t WDU		:3;		//	число дня недели в BCD формате
	uint32_t reserv1	:1;		//	неиспользуется в BCD формате
} StructRTC_TSDR;

/**********************************************END (RTC_TSDR)******************************************/

/***************************RTC time-stamp sub second register (RTC_TSSSR)*****************************/

typedef struct _StructRTC_TSSSR	//	RTC time-stamp sub second register (RTC_TSSSR)
{
	uint32_t SS			:16;	//	значение субсекунд
	uint32_t reserv1	:16;	//	неиспользуется
} StructRTC_TSSSR;

/********************************************END (RTC_TSSSR)*******************************************/

/*********************************RTC calibration register (RTC_CALR)**********************************/

typedef struct _StructRTC_CALR	//	RTC calibration register (RTC_CALR)
{
	uint32_t CALM		:9;		//	Calibration minus
	uint32_t reserv1	:4;		//	неиспользуется
	uint32_t CALW16		:9;		//	использовать 16 секундный период калибровки
	uint32_t CALW8		:9;		//	использовать 8 секундный период калибровки
	uint32_t CALP		:9;		//	увеличение частоты RTC на 488.5 ppm
	uint32_t reserv2	:16;	//	неиспользуется
} StructRTC_CALR;

/********************************************END (RTC_CALR)********************************************/

/******************RTC tamper and alternate function configuration register (RTC_TAFCR)****************/

typedef struct _StructRTC_TAFCR	//	RTC tamper and alternate function configuration register (RTC_TAFCR)
{
	uint32_t TAMP1E		:1;		//	включить обнаружение ввода RTC_TAMP1
	uint32_t TAMP1TRG	:1;		//	активный уровень ввода для RTC_TAMP1
	uint32_t TAMPIE		:1;		//	включить прерывание тампера
	uint32_t TAMP2E		:1;		//	включить обнаружение ввода RTC_TAMP2
	uint32_t TAMP2TRG	:1;		//	активный уровень ввода для RTC_TAMP2
	uint32_t TAMP3E		:1;		//	включить обнаружение ввода RTC_TAMP3
	uint32_t TAMP3TRG	:1;		//	активный уровень ввода для RTC_TAMP3
	uint32_t TAMPTS		:1;		//	активировать метку времени события обнаружения тампера
	uint32_t TAMPFREQ	:3;		//	частота дискретизации тампера
	uint32_t TAMPFLT	:2;		//	количество фильтров RTC_TAMPx
	uint32_t TAMPPRCH	:2;		//	продолжительность предварительной зарядки RTC_TAMPx
	uint32_t TAMPPUDIS	:1;		//	отключить подтяжку pull-up RTC_TAMPx
	uint32_t reserv1	:2;		//	неиспользуется
	uint32_t PC13VALUE	:1;		//	volatile StructRTC_ALARM output type/PC13 value
	uint32_t PC13MODE	:1;		//	режим PC13
	uint32_t PC14VALUE	:1;		//	значение PC14
	uint32_t PC14MODE	:1;		//	режим PC14
	uint32_t PC15VALUE	:1;		//	значение PC15
	uint32_t PC15MODE	:1;		//	режим PC15
	uint32_t reserv2	:8;		//	неиспользуется
} StructRTC_TAFCR;

/**********************************************END (RTC_TAFCR)*****************************************/

/****************************RTC alarm A sub second register (RTC_ALRMASSR)****************************/

typedef struct _StructRTC_ALRMASSR	//	RTC alarm A sub second register (RTC_ALRMASSR)
{
	uint32_t SS			:15;	//	значение субсекунд
	uint32_t reserv1	:9;		//	неиспользуется
	uint32_t MASKSS		:4;		//	Маскируйте наиболее значимые биты начиная с первого
	uint32_t reserv2	:4;		//	неиспользуется
} StructRTC_ALRMASSR;

/*********************************************END (RTC_ALRMASSR)***************************************/

/******************************************************************************************************/

typedef struct _StructRTC
{
	volatile StructRTC_TR		TR;			//	RTC регистр времени (RTC_TR)
	volatile StructRTC_DR		DR;			//	RTC регистр даты (RTC_DR)
	volatile StructRTC_CR		CR;			//	RTC регистр управления (RTC_CR)
	volatile StructRTC_ISR		ISR;		//	RTC регистр инициализации и статуса (RTC_ISR)
	volatile StructRTC_PRER		PRER;		//	RTC регистр предделителя (RTC_PRER)
	volatile StructRTC_WUTR		WUTR;		//	RTC регистр таймера пробуждения (RTC_WUTR)
	volatile const uint32_t		RESERV1;	//	зарезервировано, адрес смещения: 0x18
	volatile StructRTC_ALRMAR	ALRMAR;		//	RTC регистр будильника A (RTC_ALRMAR)
	volatile const uint32_t		RESERV2;	//	зарезервировано, адрес смещения: 0x20
	volatile StructRTC_WPR		WPR;		//	RTC регистр защиты от записи (RTC_WPR)
	volatile StructRTC_SSR		SSR;		//	RTC регистр субсекунд (RTC_SSR)
	volatile StructRTC_SHIFTR	SHIFTR;		//	RTC регистр управления смещением (RTC_SHIFTR)
	volatile StructRTC_TSTR		TSTR;		//	RTC регистр отметки времени (RTC_TSTR)
	volatile StructRTC_TSDR		TSDR;		//	RTC регистр отметки даты (RTC_TSDR)
	volatile StructRTC_TSSSR	TSSSR;		//	RTC регистр субсекунд отметки времени (RTC_TSSSR)
	volatile StructRTC_CALR		CALR;		//	RTC регистр калибровки (RTC_CALR)
	volatile StructRTC_TAFCR	TAFCR;		//	RTC tamper and alternate function configuration register (RTC_TAFCR)
	volatile StructRTC_ALRMASSR	ALRMASSR;	//	RTC alarm A sub second register (RTC_ALRMASSR)
	volatile const uint32_t		RESERV3;	//	зарезервировано, адрес смещения: 0x48
	volatile const uint32_t		RESERV4;	//	зарезервировано, адрес смещения: 0x4С
	volatile uint32_t			BKP0R;		//	регистр для архивации
	volatile uint32_t			BKP1R;		//	регистр для архивации
	volatile uint32_t			BKP2R;		//	регистр для архивации
	volatile uint32_t			BKP3R;		//	регистр для архивации
	volatile uint32_t			BKP4R;		//	регистр для архивации
}StructRTC;

#define _RTC	((StructRTC_TR *) 0x40002800)	//	инициализация битовых структур регистров RTC

/******************************************************************************************************/

#endif /* BSH_RTC_H_ */







