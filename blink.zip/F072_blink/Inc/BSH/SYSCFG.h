/*
 * SYSCFG.h
 *
 *  Created on: 23 окт. 2020 г.
 *      Author: sergeyvp@gmail.com
 */

#ifndef BSH_SYSCFG_H_
#define BSH_SYSCFG_H_

#include "BS.h"
/**************************************************************************************
Основные возможности контроллера системной конфигурации:
• вкл./выкл. I2C Fast Mode Plus на некоторых портах IO
• перенаправление некоторых источников DMA для разных каналов DMA
• изменение расположения начала области кода в памяти
• регистр статуса ожидания прерывания для каждой линии прерывания в STM32F09x
• управление подключением внешних линий прерывания к GPIOs
• управление отказоустойчивостью
**************************************************************************************/
/***********************SYSCFG configuration register 1 (SYSCFG_CFGR1)******************************/

typedef struct _StructSYSCFG_CFGR1		// SYSCFG configuration register 1
{
	uint32_t MEM_MODE			:2;		//	Memory mapping selection bits
	uint32_t reserv1			:2;		//	неиспользуется
	uint32_t PA11_PA12_RMP		:1;		//	PA11 and PA12 remapping bit for small packages (28 and 20 pins)
	uint32_t reserv2			:1;		//	неиспользуется
	uint32_t IR_MOD				:2;		//	IR Modulation Envelope signal selection. Available on STM32F09x devices
	uint32_t ADC_DMA_RMP		:1;		//	ADC DMA request remapping bit
	uint32_t USART1_TX_DMA_RMP	:1;		//	USART1_TX DMA request remapping bit
	uint32_t USART1_RX_DMA_RMP	:1;		//	USART1_RX DMA request remapping bit
	uint32_t TIM16_DMA_RMP		:1;		//	TIM16 DMA request remapping bit
	uint32_t TIM17_DMA_RMP		:1;		//	TIM17 DMA request remapping bit
	uint32_t TIM16_DMA_RMP2		:1;		//	TIM16 alternate DMA request remapping bit
	uint32_t TIM17_DMA_RMP2		:1;		//	TIM17 alternate DMA request remapping bit
	uint32_t reserv3			:1;		//	неиспользуется
	uint32_t I2C_PB6_FMP		:1;		//	Fast Mode Plus (FM+) driving capability activation bits
	uint32_t I2C_PB7_FMP		:1;		//	Fast Mode Plus (FM+) driving capability activation bits
	uint32_t I2C_PB8_FMP		:1;		//	Fast Mode Plus (FM+) driving capability activation bits
	uint32_t I2C_PB9_FMP		:1;		//	Fast Mode Plus (FM+) driving capability activation bits
	uint32_t I2C1_FMP			:1;		//	FM+ driving capability activation for I2C1
	uint32_t I2C2_FMP			:1;		//	FM+ driving capability activation for I2C2
	uint32_t I2C_PA9_FMP		:1;		//	Fast Mode Plus (FM+) driving capability activation bits
	uint32_t I2C_PA10_FMP		:1;		//	Fast Mode Plus (FM+) driving capability activation bits
	uint32_t SPI2_DMA_RMP		:1;		//	SPI2 DMA request remapping bit
	uint32_t USART2_DMA_RMP		:1;		//	USART2 DMA request remapping bit
	uint32_t USART3_DMA_RMP		:1;		//	USART3 DMA request remapping bit
	uint32_t I2C1_DMA_RMP		:1;		//	I2C1 DMA request remapping bit
	uint32_t TIM1_DMA_RMP		:1;		//	TIM1 DMA request remapping bit
	uint32_t TIM2_DMA_RMP		:1;		//	TIM2 DMA request remapping bit
	uint32_t TIM3_DMA_RMP		:1;		//	TIM3 DMA request remapping bit
	uint32_t reserv4			:1;		//	неиспользуется
} StructSYSCFG_CFGR1;

/*****************************************END (SYSCFG_CFGR1)****************************************/

/**************SYSCFG external interrupt configuration register 1 (SYSCFG_EXTICR1)******************/

#define	EXTI_PA	(0b0000)	//	Port A
#define EXTI_PB	(0b0001)	//	Port B
#define EXTI_PC	(0b0010)	//	Port C
#define EXTI_PD	(0b0011)	//	Port D
#define EXTI_PE	(0b0100)	//	Port E
#define EXTI_PF	(0b0101)	//	Port F

typedef struct _StructSYSCFG_EXTICR1	//	1 регистр конфигурации внешних прерываний
{
	uint32_t EXTI0		:4;				//	порт прерывания для пин 0
	uint32_t EXTI1		:4;				//	порт прерывания для пин 2
	uint32_t EXTI2		:4;				//	порт прерывания для пин 3
	uint32_t EXTI3		:4;				//	порт прерывания для пин 4
	uint32_t reserv		:16;			//	неиспользуется
} StructSYSCFG_EXTICR1;

/*****************************************END (SYSCFG_EXTICR1)**************************************/

/**************SYSCFG external interrupt configuration register 2 (SYSCFG_EXTICR2)******************/

typedef struct _StructSYSCFG_EXTICR2	//	2 регистр конфигурации внешних прерываний
{
	uint32_t EXTI4		:4;				//	порт прерывания для пин 4
	uint32_t EXTI5		:4;				//	порт прерывания для пин 5
	uint32_t EXTI6		:4;				//	порт прерывания для пин 6
	uint32_t EXTI7		:4;				//	порт прерывания для пин 7
	uint32_t reserv		:16;			//	неиспользуется
} StructSYSCFG_EXTICR2;

/*****************************************END (SYSCFG_EXTICR2)**************************************/

/**************SYSCFG external interrupt configuration register 3 (SYSCFG_EXTICR3)******************/

typedef struct _StructSYSCFG_EXTICR3	//	3 регистр конфигурации внешних прерываний
{
	uint32_t EXTI8		:4;				//	порт прерывания для пин 8
	uint32_t EXTI9		:4;				//	порт прерывания для пин 9
	uint32_t EXTI10		:4;				//	порт прерывания для пин 10
	uint32_t EXTI11		:4;				//	порт прерывания для пин 11
	uint32_t reserv		:16;			//	неиспользуется
} StructSYSCFG_EXTICR3;

/*****************************************END (SYSCFG_EXTICR3)**************************************/

/**************SYSCFG external interrupt configuration register 4 (SYSCFG_EXTICR4)******************/

typedef struct _StructSYSCFG_EXTICR4	//	4 регистр конфигурации внешних прерываний
{
	uint32_t EXTI12		:4;				//	порт прерывания для пин 12
	uint32_t EXTI13		:4;				//	порт прерывания для пин 13
	uint32_t EXTI14		:4;				//	порт прерывания для пин 14
	uint32_t EXTI15		:4;				//	порт прерывания для пин 15
	uint32_t reserv		:16;			//	неиспользуется
} StructSYSCFG_EXTICR4;

/*****************************************END (SYSCFG_EXTICR4)**************************************/

/***********************SYSCFG configuration register 2 (SYSCFG_CFGR2)******************************/

typedef struct _StructSYSCFG_CFGR2		// SYSCFG configuration register 2
{
	uint32_t LOCKUP_LOCK		:1;		//	Cortex-M0 LOCKUP bit enable bit
	uint32_t SRAM_PARITY_LOCK	:1;		//	SRAM parity lock bit
	uint32_t PVD_LOCK			:1;		//	PVD lock enable bit
	uint32_t reserv1			:5;		//	неиспользуется
	uint32_t SRAM_PEF			:1;		//	SRAM parity error flag
	uint32_t reserv2			:23;	//	неиспользуется
} StructSYSCFG_CFGR2;

/*****************************************END (SYSCFG_CFGR2)****************************************/

/*******************SYSCFG interrupt line 0 status register (SYSCFG_ITLINE0)************************/

typedef struct _StructSYSCFG_ITLINE0	//	SYSCFG interrupt line 0 status register
{
	uint32_t	flagWWDG		:1;		//	флаг прерывания Window WatchDoG
	uint32_t	reserv			:31;	//	неиспользуется
} StructSYSCFG_ITLINE0;

/*****************************************END (SYSCFG_ITLINE0)**************************************/

/*******************SYSCFG interrupt line 1 status register (SYSCFG_ITLINE1)************************/

typedef struct _StructSYSCFG_ITLINE1	//	SYSCFG interrupt line 1 status register
{
	uint32_t	PVDOUT		:1;			//	PVD supply monitoring interrupt request pending (EXTI line 16)
	uint32_t	VDDIO2		:1;			//	VDDIO2 supply monitoring interrupt request pending (EXTI line 31)
	uint32_t	reserv		:30;		//	неиспользуется
} StructSYSCFG_ITLINE1;

/*****************************************END (SYSCFG_ITLINE1)**************************************/

/*******************SYSCFG interrupt line 2 status register (SYSCFG_ITLINE2)************************/

typedef struct _StructSYSCFG_ITLINE2	//	SYSCFG interrupt line 2 status register
{
	uint32_t	RTC_WAKEUP	:1;			//	RTC Wake Up interrupt request pending (EXTI line 20)
	uint32_t	RTC_TSTAMP	:1;			//	RTC Tamper and TimeStamp interrupt request pending (EXTI line 19)
	uint32_t	RTC_ALRA	:1;			//	RTC Alarm interrupt request pending (EXTI line 17)
	uint32_t	reserv		:29;		//	неиспользуется
} StructSYSCFG_ITLINE2;

/*****************************************END (SYSCFG_ITLINE2)**************************************/

/*******************SYSCFG interrupt line 3 status register (SYSCFG_ITLINE3)************************/

typedef struct _StructSYSCFG_ITLINE3	//	SYSCFG interrupt line 3 status register
{
	uint32_t	FLASH_ITF	:1;			//	Flash interface interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE3;

/*****************************************END (SYSCFG_ITLINE3)**************************************/

/*******************SYSCFG interrupt line 4 status register (SYSCFG_ITLINE4)************************/

typedef struct _StructSYSCFG_ITLINE4	//	SYSCFG interrupt line 4 status register
{
	uint32_t	flagRCC		:1;			//	Reset and clock control interrupt request pending
	uint32_t	flagCRS		:1;			//	Clock recovery system interrupt request pending
	uint32_t	reserv		:30;		//	неиспользуется
} StructSYSCFG_ITLINE4;

/*****************************************END (SYSCFG_ITLINE4)**************************************/

/*******************SYSCFG interrupt line 5 status register (SYSCFG_ITLINE5)************************/

typedef struct _StructSYSCFG_ITLINE5	//	SYSCFG interrupt line 5 status register
{
	uint32_t	EXTI0		:1;			//	EXTI line 0 interrupt request pending
	uint32_t	EXTI1		:1;			//	EXTI line 1 interrupt request pending
	uint32_t	reserv		:30;		//	неиспользуется
} StructSYSCFG_ITLINE5;

/*****************************************END (SYSCFG_ITLINE5)**************************************/

/*******************SYSCFG interrupt line 6 status register (SYSCFG_ITLINE6)************************/

typedef struct _StructSYSCFG_ITLINE6	//	SYSCFG interrupt line 6 status register
{
	uint32_t	EXTI2		:1;			//	EXTI line 2 interrupt request pending
	uint32_t	EXTI3		:1;			//	EXTI line 3 interrupt request pending
	uint32_t	reserv		:30;		//	неиспользуется
} StructSYSCFG_ITLINE6;

/*****************************************END (SYSCFG_ITLINE6)**************************************/

/*******************SYSCFG interrupt line 7 status register (SYSCFG_ITLINE7)************************/

typedef struct _StructSYSCFG_ITLINE7	//	SYSCFG interrupt line 7 status register
{
	uint32_t	EXTI4		:1;			//	EXTI line 4 interrupt request pending
	uint32_t	EXTI5		:1;			//	EXTI line 5 interrupt request pending
	uint32_t	EXTI6		:1;			//	EXTI line 6 interrupt request pending
	uint32_t	EXTI7		:1;			//	EXTI line 7 interrupt request pending
	uint32_t	EXTI8		:1;			//	EXTI line 8 interrupt request pending
	uint32_t	EXTI9		:1;			//	EXTI line 9 interrupt request pending
	uint32_t	EXTI10		:1;			//	EXTI line 10 interrupt request pending
	uint32_t	EXTI11		:1;			//	EXTI line 11 interrupt request pending
	uint32_t	EXTI12		:1;			//	EXTI line 12 interrupt request pending
	uint32_t	EXTI13		:1;			//	EXTI line 13 interrupt request pending
	uint32_t	EXTI14		:1;			//	EXTI line 14 interrupt request pending
	uint32_t	EXTI15		:1;			//	EXTI line 15 interrupt request pending
	uint32_t	reserv		:21;		//	неиспользуется
} StructSYSCFG_ITLINE7;

/*****************************************END (SYSCFG_ITLINE7)**************************************/

/*******************SYSCFG interrupt line 8 status register (SYSCFG_ITLINE8)************************/

typedef struct _StructSYSCFG_ITLINE8	//	SYSCFG interrupt line 8 status register
{
	uint32_t	TCS_MCE		:1;			//	Touch sensing controller max count error interrupt request pending
	uint32_t	TCS_EOA		:1;			//	Touch sensing controller end of acquisition interrupt request pending
	uint32_t	reserv		:30;		//	неиспользуется
} StructSYSCFG_ITLINE8;

/*****************************************END (SYSCFG_ITLINE8)**************************************/

/*******************SYSCFG interrupt line 9 status register (SYSCFG_ITLINE9)************************/

typedef struct _StructSYSCFG_ITLINE9	//	SYSCFG interrupt line 9 status register
{
	uint32_t	DMA1_CH1	:1;			//	DMA1 channel 1 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE9;

/*****************************************END (SYSCFG_ITLINE9)**************************************/

/*******************SYSCFG interrupt line 10 status register (SYSCFG_ITLINE10)**********************/

typedef struct _StructSYSCFG_ITLINE10	//	SYSCFG interrupt line 10 status register
{
	uint32_t	DMA1_CH2	:1;			//	DMA1 channel 2 interrupt request pending
	uint32_t	DMA1_CH3	:1;			//	DMA1 channel 3 interrupt request pending
	uint32_t	DMA2_CH1	:1;			//	DMA2 channel 1 interrupt request pending
	uint32_t	DMA2_CH2	:1;			//	DMA2 channel 2 interrupt request pending
	uint32_t	reserv		:28;		//	неиспользуется
} StructSYSCFG_ITLINE10;

/*****************************************END (SYSCFG_ITLINE10)*************************************/

/*******************SYSCFG interrupt line 11 status register (SYSCFG_ITLINE11)**********************/

typedef struct _StructSYSCFG_ITLINE11	//	SYSCFG interrupt line 11 status register
{
	uint32_t	DMA1_CH4	:1;			//	DMA1 channel 4 interrupt request pending
	uint32_t	DMA1_CH5	:1;			//	DMA1 channel 5 interrupt request pending
	uint32_t	DMA1_CH6	:1;			//	DMA1 channel 6 interrupt request pending
	uint32_t	DMA1_CH7	:1;			//	DMA1 channel 7 interrupt request pending
	uint32_t	DMA2_CH3	:1;			//	DMA2 channel 3 interrupt request pending
	uint32_t	DMA2_CH4	:1;			//	DMA2 channel 4 interrupt request pending
	uint32_t	DMA2_CH5	:1;			//	DMA2 channel 5 interrupt request pending
	uint32_t	reserv		:25;		//	неиспользуется
} StructSYSCFG_ITLINE11;

/*****************************************END (SYSCFG_ITLINE11)*************************************/

/*******************SYSCFG interrupt line 12 status register (SYSCFG_ITLINE12)**********************/

typedef struct _StructSYSCFG_ITLINE12	//	SYSCFG interrupt line 12 status register
{
	uint32_t	ADC_		:1;			//	ADC interrupt request pending
	uint32_t	COMP1		:1;			//	Comparator 1 interrupt request pending (EXTI line 21)
	uint32_t	COMP2		:1;			//	Comparator 2 interrupt request pending (EXTI line 22)
	uint32_t	reserv		:29;		//	неиспользуется
} StructSYSCFG_ITLINE12;

/*****************************************END (SYSCFG_ITLINE12)*************************************/

/*******************SYSCFG interrupt line 13 status register (SYSCFG_ITLINE13)**********************/

typedef struct _StructSYSCFG_ITLINE13	//	SYSCFG interrupt line 13 status register
{
	uint32_t	TIM1_CCU	:1;			//	Timer 1 commutation interrupt request pending
	uint32_t	TIM1_TRG	:1;			//	Timer 1 trigger interrupt request pending
	uint32_t	TIM1_UPD	:1;			//	Timer 1 update interrupt request pending
	uint32_t	TIM1_BRK	:1;			//	Timer 1 break interrupt request pending
	uint32_t	reserv		:28;		//	неиспользуется
} StructSYSCFG_ITLINE13;

/*****************************************END (SYSCFG_ITLINE13)*************************************/

/*******************SYSCFG interrupt line 14 status register (SYSCFG_ITLINE14)**********************/

typedef struct _StructSYSCFG_ITLINE14	//	SYSCFG interrupt line 14 status register
{
	uint32_t	TIM1_CC		:1;			//	Timer 1 capture compare interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE14;

/*****************************************END (SYSCFG_ITLINE14)*************************************/

/*******************SYSCFG interrupt line 15 status register (SYSCFG_ITLINE15)**********************/

typedef struct _StructSYSCFG_ITLINE15	//	SYSCFG interrupt line 15 status register
{
	uint32_t	TIM2_		:1;			//	Timer 2 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE15;

/*****************************************END (SYSCFG_ITLINE15)*************************************/

/*******************SYSCFG interrupt line 16 status register (SYSCFG_ITLINE16)**********************/

typedef struct _StructSYSCFG_ITLINE16	//	SYSCFG interrupt line 16 status register
{
	uint32_t	TIM3_		:1;			//	Timer 3 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE16;

/*****************************************END (SYSCFG_ITLINE16)*************************************/

/*******************SYSCFG interrupt line 17 status register (SYSCFG_ITLINE17)**********************/

typedef struct _StructSYSCFG_ITLINE17	//	SYSCFG interrupt line 17 status register
{
	uint32_t	TIM6_		:1;			//	Timer 6 interrupt request pending
	uint32_t	DAC_		:1;			//	DAC underrun interrupt request pending
	uint32_t	reserv		:30;		//	неиспользуется
} StructSYSCFG_ITLINE17;

/*****************************************END (SYSCFG_ITLINE17)*************************************/

/*******************SYSCFG interrupt line 18 status register (SYSCFG_ITLINE18)**********************/

typedef struct _StructSYSCFG_ITLINE18	//	SYSCFG interrupt line 18 status register
{
	uint32_t	TIM7_		:1;			//	Timer 7 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE18;

/*****************************************END (SYSCFG_ITLINE18)*************************************/

/*******************SYSCFG interrupt line 19 status register (SYSCFG_ITLINE19)**********************/

typedef struct _StructSYSCFG_ITLINE19	//	SYSCFG interrupt line 19 status register
{
	uint32_t	TIM14_		:1;			//	Timer 14 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE19;

/*****************************************END (SYSCFG_ITLINE19)*************************************/

/*******************SYSCFG interrupt line 20 status register (SYSCFG_ITLINE20)**********************/

typedef struct _StructSYSCFG_ITLINE20	//	SYSCFG interrupt line 20 status register
{
	uint32_t	TIM15_		:1;			//	Timer 15 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE20;

/*****************************************END (SYSCFG_ITLINE20)*************************************/

/*******************SYSCFG interrupt line 21 status register (SYSCFG_ITLINE21)**********************/

typedef struct _StructSYSCFG_ITLINE21	//	SYSCFG interrupt line 21 status register
{
	uint32_t	TIM16_		:1;			//	Timer 16 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE21;

/*****************************************END (SYSCFG_ITLINE21)*************************************/

/*******************SYSCFG interrupt line 22 status register (SYSCFG_ITLINE22)**********************/

typedef struct _StructSYSCFG_ITLINE22	//	SYSCFG interrupt line 22 status register
{
	uint32_t	TIM17_		:1;			//	Timer 17 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE22;

/*****************************************END (SYSCFG_ITLINE22)*************************************/

/*******************SYSCFG interrupt line 23 status register (SYSCFG_ITLINE23)**********************/

typedef struct _StructSYSCFG_ITLINE23	//	SYSCFG interrupt line 23 status register
{
	uint32_t	I2C1_		:1;		//	I2C1 interrupt request pending, combined with EXTI line 23
	uint32_t	reserv		:31;	//	неиспользуется
} StructSYSCFG_ITLINE23;

/*****************************************END (SYSCFG_ITLINE23)*************************************/

/*******************SYSCFG interrupt line 24 status register (SYSCFG_ITLINE24)**********************/

typedef struct _StructSYSCFG_ITLINE24	//	SYSCFG interrupt line 24 status register
{
	uint32_t	I2C2_		:1;			//	I2C2 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE24;

/*****************************************END (SYSCFG_ITLINE24)*************************************/

/*******************SYSCFG interrupt line 25 status register (SYSCFG_ITLINE25)**********************/

typedef struct _StructSYSCFG_ITLINE25	//	SYSCFG interrupt line 25 status register
{
	uint32_t	SPI1_		:1;			//	SPI1 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE25;

/*****************************************END (SYSCFG_ITLINE25)*************************************/

/*******************SYSCFG interrupt line 26 status register (SYSCFG_ITLINE26)**********************/

typedef struct _StructSYSCFG_ITLINE26	//	SYSCFG interrupt line 26 status register
{
	uint32_t	SPI2_		:1;			//	SPI2 interrupt request pending
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE26;

/*****************************************END (SYSCFG_ITLINE26)*************************************/

/*******************SYSCFG interrupt line 27 status register (SYSCFG_ITLINE27)**********************/

typedef struct _StructSYSCFG_ITLINE27	//	SYSCFG interrupt line 27 status register
{
	uint32_t	USART1_		:1;			//	USART1 interrupt request pending, combined with EXTI line 25
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE27;

/*****************************************END (SYSCFG_ITLINE27)*************************************/

/*******************SYSCFG interrupt line 28 status register (SYSCFG_ITLINE28)**********************/

typedef struct _StructSYSCFG_ITLINE28	//	SYSCFG interrupt line 28 status register
{
	uint32_t	USART2_		:1;			//	USART2 interrupt request pending, combined with EXTI line 26
	uint32_t	reserv		:31;		//	неиспользуется
} StructSYSCFG_ITLINE28;

/*****************************************END (SYSCFG_ITLINE28)*************************************/

/*******************SYSCFG interrupt line 29 status register (SYSCFG_ITLINE29)**********************/

typedef struct _StructSYSCFG_ITLINE29	//	SYSCFG interrupt line 29 status register
{
	uint32_t	USART3_		:1;			//	USART3 interrupt request pending
	uint32_t	USART4_		:1;			//	USART4 interrupt request pending
	uint32_t	USART5_		:1;			//	USART5 interrupt request pending
	uint32_t	USART6_		:1;			//	USART6 interrupt request pending
	uint32_t	USART7_		:1;			//	USART7 interrupt request pending
	uint32_t	USART8_		:1;			//	USART8 interrupt request pending
	uint32_t	reserv		:26;		//	неиспользуется
} StructSYSCFG_ITLINE29;

/*****************************************END (SYSCFG_ITLINE29)*************************************/

/*******************SYSCFG interrupt line 30 status register (SYSCFG_ITLINE30)**********************/

typedef struct _StructSYSCFG_ITLINE30	//	SYSCFG interrupt line 30 status register
{
	uint32_t	CEC_		:1;			//	CEC interrupt request pending, combined with EXTI line 27
	uint32_t	CAN_		:1;			//	CAN interrupt request pending
	uint32_t	reserv		:30;		//	неиспользуется
} StructSYSCFG_ITLINE30;

/*****************************************END (SYSCFG_ITLINE30)*************************************/

/***************************************************************************************************/

typedef struct _StructSYSCFG
{
	volatile StructSYSCFG_CFGR1		CFGR1;			//	1 конфигурационный регистр
	volatile const uint32_t			RESERV0;		//	зарезервировано, адрес смещения: 0x04
	volatile StructSYSCFG_EXTICR1	EXTICR1;		//	1 конфигурационный регистр прерываний
	volatile StructSYSCFG_EXTICR2	EXTICR2;		//	2 конфигурационный регистр прерываний
	volatile StructSYSCFG_EXTICR3	EXTICR3;		//	3 конфигурационный регистр прерываний
	volatile StructSYSCFG_EXTICR4	EXTICR4;		//	4 конфигурационный регистр прерываний
	volatile StructSYSCFG_CFGR2		CFGR2;			//	2 конфигурационный регистр
	volatile const uint32_t			RESERV1[25];	//	зарезервировано, адрес смещения: 0x1C
	volatile StructSYSCFG_ITLINE0	ITLINE0;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE1	ITLINE1;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE2	ITLINE2;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE3	ITLINE3;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE4	ITLINE4;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE5	ITLINE5;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE6	ITLINE6;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE7	ITLINE7;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE8	ITLINE8;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE9	ITLINE9;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE10	ITLINE10;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE11	ITLINE11;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE12	ITLINE12;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE13	ITLINE13;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE14	ITLINE14;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE15	ITLINE15;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE16	ITLINE16;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE17	ITLINE17;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE18	ITLINE18;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE19	ITLINE19;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE20	ITLINE20;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE21	ITLINE21;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE22	ITLINE22;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE23	ITLINE23;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE24	ITLINE24;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE25	ITLINE25;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE26	ITLINE26;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE27	ITLINE27;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE28	ITLINE28;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE29	ITLINE29;		//	регистр статуса прерываний
	volatile StructSYSCFG_ITLINE30	ITLINE30;		//	регистр статуса прерываний
}StructSYSCFG;

#define _SYSCFG	((StructSYSCFG *) 0x40010000)

/***************************************************************************************************/

#endif /* BSH_SYSCFG_H_ */





