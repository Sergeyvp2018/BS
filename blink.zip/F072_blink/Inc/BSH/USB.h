/*
 * USB.h
 *
 *  Created on: 3 дек. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_USB_H_
#define BSH_USB_H_

#include "BS.h"

/*******************************USB control register (USB_CNTR)********************************************/

typedef struct _StructUSB_CNTR		//	регистр управления (USB_CNTR)
{
	uint32_t FRES		:1;			//	принудительная перезагрузка USB
	uint32_t PDWN		:1;			//	выключить питание
	uint32_t LP_MODE	:1;			//	режим низкого потребления
	uint32_t FSUSP		:1;			//	принудительная приостановка
	uint32_t RESUME		:1;			//	запрос продолжения
	uint32_t L1RESUME	:1;			//	LPM L1 запрос продолжения
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t L1REQM		:1;			//	LPM L1 маска прерывания запроса состояния
	uint32_t ESOFM		:1;			//	маска прерывания ожидаемого начала кадра
	uint32_t SOFM		:1;			//	маска прерывания начала кадра
	uint32_t RESETM		:1;			//	маска прерывания перезагрузки USB
	uint32_t SUSPM		:1;			//	маска прерывания режима приостановки
	uint32_t WKUPM		:1;			//	маска прерывания пробуждения
	uint32_t ERRM		:1;			//	маска прерывания ошибки
	uint32_t PMAOVRM	:1;			//	маска прерывания переполнения или неполного пакета
	uint32_t CTRM		:1;			//	маска прерывания корректной передачи
	uint32_t reserv2	:16;		//	неиспользуется
} StructUSB_CNTR;

/**********************************************************************************************************/

/*******************************USB interrupt status register (USB_ISTR)***********************************/

typedef struct _StructUSB_ISTR		//	регистр статуса прерываний (USB_ISTR)
{
	uint32_t EP_ID		:4;			//	идентификатор конечной точки
	uint32_t DIR		:1;			//	направление транзакции
	uint32_t reserv1	:2;			//	неиспользуется
	uint32_t L1REQ		:1;			//	LPM L1 состояние запроса
	uint32_t ESOF		:1;			//	ожидание начала кадра
	uint32_t RESET		:1;			//	перезагрузка
	uint32_t SUSP		:1;			//	приостановка
	uint32_t WKUP		:1;			//	пробуждение
	uint32_t ERR		:1;			//	ошибка
	uint32_t PMAOVR		:1;			//	переполнение памяти пространства пакета
	uint32_t CTR		:1;			//	корректная передача
	uint32_t reserv2	:16;		//	неиспользуется
} StructUSB_ISTR;

/**********************************************************************************************************/

/*******************************USB frame number register (USB_FNR)****************************************/

typedef struct _StructUSB_FNR		//	регистр количества кадров (USB_FNR)
{
	uint32_t FN			:1;			//	количество кадров
	uint32_t LSOF		:2;			//	последний SOF
	uint32_t LCK		:1;			//	блокировка
	uint32_t RXDM		:1;			//	получение данных минус состояние линии
	uint32_t RXDP		:1;			//	получение данных плюс состояние линии
	uint32_t reserv1	:16;		//	неиспользуется
} StructUSB_FNR;

/**********************************************************************************************************/

/*******************************USB device address (USB_DADDR)*********************************************/

typedef struct _StructUSB_DADDR		//	регистр адреса устройства (USB_DADDR)
{
	uint32_t ADD0			:1;		//	адрес устройства
	uint32_t ADD1			:1;		//	адрес устройства
	uint32_t ADD2			:1;		//	адрес устройства
	uint32_t ADD3			:1;		//	адрес устройства
	uint32_t ADD4			:1;		//	адрес устройства
	uint32_t ADD5			:1;		//	адрес устройства
	uint32_t ADD6			:1;		//	адрес устройства
	uint32_t EF				:1;		//	включить функцию
	uint32_t reserv1		:16;	//	неиспользуется
} StructUSB_DADDR;

typedef struct _StructUSB_ADDR		//	регистр адреса устройства (USB_DADDR)
{
	uint32_t ADD			:7;		//	адрес устройства
	uint32_t EF				:1;		//	включить функцию
	uint32_t reserv1		:16;	//	неиспользуется
} StructUSB_ADDR;

/**********************************************************************************************************/

/*******************************Buffer table address (USB_BTABLE)******************************************/

typedef struct _StructUSB_BTABLE	//	адрес буферной таблицы (USB_BTABLE)
{
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t BTABLE		:13;		//
	uint32_t reserv2	:16;		//	неиспользуется
} StructUSB_BTABLE;

/**********************************************************************************************************/

/*******************************LPM control and status register (USB_LPMCSR)*******************************/

typedef struct _StructUSB_LPMCSR	//	регистр управления и статуса (USB_LPMCSR)
{
	uint32_t LPMEN		:1;			//	включить поддержку LPM
	uint32_t LPMACK		:1;			//	включить подтверждение токена LPM
	uint32_t REMWAKE	:1;			//	значение bRemoteWake
	uint32_t BESL		:4;			//	значение BESL
	uint32_t reserv1	:24;		//	неиспользуется
} StructUSB_LPMCSR;

/**********************************************************************************************************/

/*******************************Battery charging detector (USB_BCDR)***************************************/

typedef struct _StructUSB_BCDR		//	детектор зарядки аккумулятора (USB_BCDR)
{
	uint32_t BCDEN		:1;			//	включить детектор зарядки аккумулятора BCD
	uint32_t DCDEN		:1;			//	включение режима обнаружения контакта данных (DCD)
	uint32_t PDEN		:1;			//	включение режима первичного обнаружения (PD)
	uint32_t SDEN		:1;			//	включение режима вторичного обнаружения (SD)
	uint32_t DCDET		:1;			//	статус обнаружения контакта данных (DCD)
	uint32_t PDET		:1;			//	статус первичного обнаружения (PD)
	uint32_t SDET		:1;			//	статус вторичного обнаружения (SD)
	uint32_t PS2DET		:1;			//	статус обнаружения подтяжки DM
	uint32_t reserv1	:7;			//	неиспользуется
	uint32_t DPPU		:1;			//	управление подтяжкой DP
	uint32_t reserv2	:16;		//	неиспользуется
} StructUSB_BCDR;

/**********************************************************************************************************/

/*******************************USB endpoint n register (USB_EPnR), n=[0..7]*******************************/

#define	STAT_RTX_DISABLED	(0b00)	//	DISABLED: все запросы приёма/передачи этой точкой игнорируются
#define	STAT_RTX_STALL		(0b01)	//	STALL: конечная точка остановлена
#define	STAT_RTX_NAK		(0b10)	//	NAK:конечная точка открыта
#define	STAT_RTX_VALID		(0b11)	//	VALID: конечная точка включена для приёма/передачи

typedef struct _StructUSB_EPR		//	регистр конечной точки (USB_EPR)
{
	uint32_t EA			:4;			//	адрес конечной точки
	uint32_t STAT_TX	:2;			//	статус передачи
	uint32_t DTOG_TX	:1;			//	переключатель данных, для передачи данных
	uint32_t CTR_TX		:1;			//	корректная передача
	uint32_t EP_KIND	:1;			//	тип конечной точки
	uint32_t EP_TYPE	:2;			//	тип конечной точки
	uint32_t SETUP		:1;			//	установка транзакции выполнена
	uint32_t STAT_RX	:2;			//	статус приема
	uint32_t DTOG_RX	:1;			//	переключатель данных, для приёма данных
	uint32_t CTR_RX		:1;			//	корректный приём
	uint32_t reserv		:16;		//	неиспользуется
} StructUSB_EPR;

/**********************************************************************************************************/

/*******************************Transmission buffer address n (USB_ADDRn_TX)*******************************/

typedef struct _StructUSB_ADDR_TX	//	адрес буфера передачи (USB_ADDR_TX)
{
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t ADDR_TX	:15;		//	адрес буфера передачи
	uint32_t reserv2	:16;		//	неиспользуется
} StructUSB_ADDR_TX;

/**********************************************************************************************************/

/*******************************Transmission byte count n (USB_COUNTn_TX)**********************************/

typedef struct _StructUSB_COUNT_TX	//	количество передаваемых байт (USB_COUNT_TX)
{
	uint32_t COUNT_TX	:10;		//	количество передаваемых байт
	uint32_t reserv1	:22;		//	неиспользуется
} StructUSB_COUNT_TX;

/**********************************************************************************************************/

/*******************************Reception buffer address n (USB_ADDRn_RX)**********************************/

typedef struct _StructUSB_ADDR_RX	//	адрес буфера приёма (USB_ADDR_RX)
{
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t ADDR_RX	:15;		//	адрес буфера приёма
	uint32_t reserv2	:16;		//	неиспользуется
} StructUSB_ADDR_RX;

/**********************************************************************************************************/

/*******************************Reception byte count n (USB_COUNTn_RX)*************************************/

typedef struct _StructUSB_COUNT_RX	//	количество принимаемых байт (USB_COUNT_RX)
{
	uint32_t COUNT_RX	:10;		//	количество принимаемых байт
	uint32_t reserv1	:22;		//	неиспользуется
} StructUSB_COUNT_RX;

/**********************************************************************************************************/

/**********************************************************************************************************/

typedef struct _StructUSB
{
	volatile StructUSB_EPR			EP0R;		//	регистр конечной точки (USB_EP0R)
	volatile StructUSB_EPR			EP1R;		//	регистр конечной точки (USB_EP1R)
	volatile StructUSB_EPR			EP2R;		//	регистр конечной точки (USB_EP2R)
	volatile StructUSB_EPR			EP3R;		//	регистр конечной точки (USB_EP3R)
	volatile StructUSB_EPR			EP4R;		//	регистр конечной точки (USB_EP4R)
	volatile StructUSB_EPR			EP5R;		//	регистр конечной точки (USB_EP5R)
	volatile StructUSB_EPR			EP6R;		//	регистр конечной точки (USB_EP6R)
	volatile StructUSB_EPR			EP7R;		//	регистр конечной точки (USB_EP7R)
	volatile const uint32_t			RESERV0[8]; //	зарезервировано
	volatile StructUSB_CNTR			CNTR;		//	регистр управления (USB_CNTR)
	volatile StructUSB_ISTR			ISTR;		//	регистр статуса прерываний (USB_ISTR)
	volatile StructUSB_FNR			FNR;		//	регистр количества кадров (USB_FNR)
	volatile StructUSB_DADDR		DADDR;		//	регистр адреса устройства (USB_DADDR)
	volatile StructUSB_BTABLE		BTABLE;		//	адрес буферной таблицы (USB_BTABLE)
	volatile StructUSB_LPMCSR		LPMCSR;		//	регистр управления и статуса (USB_LPMCSR)
	volatile StructUSB_BCDR			BCDR;		//	детектор зарядки аккумулятора (USB_BCDR)
}StructUSB;

#define _USB	((StructUSB *) 0x40005c00)

/**********************************************************************************************************/

#endif /* BSH_USB_H_ */

























