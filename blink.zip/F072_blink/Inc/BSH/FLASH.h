/*
 * Flash.h
 *
 *  Created on: 5 дек. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_FLASH_H_
#define BSH_FLASH_H_

#include "BS.h"

/*******************************Flash access control register (FLASH_ACR)**********************************/

typedef struct _StructFLASH_ACR		//	регистр управления доступом к памяти (FLASH_ACR)
{
	uint32_t LATENCY	:3;			//	000: если SYSCLK ≤ 24 MHz, 001: если 24 MHz < SYSCLK ≤ 48 MHz
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t PRFTBE		:1;			//	включить буфер предварительной выборки
	uint32_t PRFTBS		:1;			//	состояние буфера предварительной выборки
	uint32_t reserv2	:28;		//	неиспользуется
} StructFLASH_ACR;

/**********************************************************************************************************/

/*******************************Flash key register (FLASH_KEYR)********************************************/

typedef struct _StructFLASH_KEYR	//	регистр ключа памяти (FLASH_KEYR)
{
	uint32_t FKEY	:32;			//	ключ памяти
} StructFLASH_KEYR;

/**********************************************************************************************************/

/*******************************Flash option key register (FLASH_OPTKEYR)**********************************/

typedef struct _StructFLASH_OPTKEYR	//	регистр ключа памяти (FLASH_OPTKEYR)
{
	uint32_t OPTKEY	:32;			//	дополнение ключа памяти
} StructFLASH_OPTKEYR;

/**********************************************************************************************************/

/*******************************Flash status register (FLASH_SR)*******************************************/

typedef struct _StructFLASH_SR		//	регистр статуса памяти (FLASH_SR)
{
	uint32_t BSY		:1;			//	занята
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t PGERR		:1;			//	програмная ошибка
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t WRPRTERR	:1;			//	ошибка защиты записи
	uint32_t EOP		:1;			//	операция завершена
	uint32_t reserv3	:26;		//	неиспользуется
} StructFLASH_SR;

/**********************************************************************************************************/

/*******************************Flash control register (FLASH_CR)******************************************/

typedef struct _StructFLASH_CR		//	регистр управления памятью (FLASH_CR)
{
	uint32_t PG			:1;			//	програмирование
	uint32_t PER		:1;			//	стирание страницы
	uint32_t MER		:1;			//	стирание всех пользовательских данных
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t OPTPG		:1;			//	программирование опциональных байт
	uint32_t OPTER		:1;			//	стирание опциональных байт
	uint32_t STRT		:1;			//	бит переключается при выборе операции стирания
	uint32_t LOCK		:1;			//	блокировка памяти
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t OPTWRE		:1;			//	включить запись опциональных байт
	uint32_t ERRIE		:1;			//	ошибка прерывания
	uint32_t reserv3	:1;			//	неиспользуется
	uint32_t EOPIE		:1;			//	прерывание при окончании операции
	uint32_t OBL_LAUNCH	:1;			//	сгенерировать перезагрузку системы
	uint32_t reserv4	:18;		//	неиспользуется
} StructFLASH_CR;

/**********************************************************************************************************/

/*******************************Flash address register (FLASH_AR)******************************************/

typedef struct _StructFLASH_AR		//	регистр адреса памяти (FLASH_AR)
{
	uint32_t FAR		:32;		//	алрес памяти
} StructFLASH_AR;

/**********************************************************************************************************/

/*******************************Flash Option byte register (FLASH_OBR)*************************************/

#define RDPRT_00	(0b00)			//	Read protection level 0 is enabled (ST production configuration)
#define RDPRT_01	(0b01)			//	Read protection level 1 is enabled
#define RDPRT_11	(0b11)			//	Read protection level 2 is enabled.

typedef struct _StructFLASH_OBR		//	регистр опциональных байт памяти (FLASH_OBR)
{
	uint32_t OPTERR				:1;	//	ошибка опциональных байт
	uint32_t RDPRT				:2;	//	статус уровня защиты чтения
	uint32_t WDG_SW				:1;	//	0: аппаратный сторожевой таймер, 1: програмный
	uint32_t nRST_STOP			:1;	//	0: при стоп режиме сгенирировать перезагрузку, 1: не генерировать
	uint32_t nRST_STDBY			:1;	//	0: в режиме ожидания сгенирировать перезагрузку, 1: не генерировать
	uint32_t nBOOT0				:1;	//	выбор режима загрузки
	uint32_t nBOOT1				:1;	//	выбор режима загрузки
	uint32_t VDDA_MONITOR		:1;	//	диспетчер питания
	uint32_t RAM_PARITY_CHECK	:1;	//	0: Проверка четности RAM включена, 1: выключена
	uint32_t BOOT_SEL			:1;	//	0: BOOT0 сигнал определяется битом nBOOT0, 1: BOOT0 пином
	uint32_t DATA0				:8;	//
	uint32_t DATA1				:8;	//
} StructFLASH_OBR;

/**********************************************************************************************************/

/*******************************Write protection register (FLASH_WRPR)*************************************/

typedef struct _StructFLASH_WRPR	//	регистр защиты от записи (FLASH_WRPR)
{
	uint32_t WRPR		:32;		//	защита от записи
} StructFLASH_WRPR;

/**********************************************************************************************************/

/**********************************************************************************************************/

typedef struct _StructFLASH
{
	volatile StructFLASH_ACR		ACR;		//	регистр управления доступом к памяти (FLASH_ACR)
	volatile StructFLASH_KEYR		KEYR;		//	регистр ключа памяти (FLASH_KEYR)
	volatile StructFLASH_OPTKEYR	OPTKEYR;	//	регистр ключа памяти (FLASH_OPTKEYR)
	volatile StructFLASH_SR			SR;			//	регистр статуса памяти (FLASH_SR)
	volatile StructFLASH_CR			CR;			//	регистр управления памятью (FLASH_CR)
	volatile StructFLASH_AR			AR;			//	регистр адреса памяти (FLASH_AR)
	volatile uint32_t				RESERVED;   //	зарезервировано 0x18
	volatile StructFLASH_OBR		OBR;		//	регистр опциональных байт памяти (FLASH_OBR)
	volatile StructFLASH_WRPR		WRPR;		//	регистр защиты от записи (FLASH_WRPR)
}StructFLASH;

#define	_FLASH	((StructFLASH *) 0x40022000)

/**********************************************************************************************************/


#endif /* BSH_FLASH_H_ */






















