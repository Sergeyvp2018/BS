/*
 * SYSTICK.h
 *
 *  Created on: 17 дек. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_SYSTICK_H_
#define BSH_SYSTICK_H_

#include "BS.h"

/****************************************************************************************
При включении таймера:
- начинается отсчёт от значения перезагрузки до нуля
- перезагружается значение из STK_RVR
- снова начинается отсчёт до нуля
Запись нулевого значения в STK_RVR отключает счетчик.
Когда счетчик переходит через 0 бит состояния COUNTFLAG устанавливается в 1.
Считывание STK_CSR очищает бит COUNTFLAG в 0.
Запись в STK_CVR очищает регистр и бит состояния COUNTFLAG в 0.
Чтение регистра возвращает его значение на момент обращения к нему.
Когда процессор останавливается для отладки, счетчик не уменьшается.
****************************************************************************************/

void _SYSTICK_ini( void);

/*****************SYST_CSR — SysTick Control and Status Register************************/

typedef struct _StructSYST_CSR	//	SysTick Control and Status Register
{
	uint32_t ENABLE		:1;		//	вкл./выкл.
	uint32_t TICKINT	:1;		//	прерывание
	uint32_t CLKSOURCE	:1;		//	источник тактирования
	uint32_t reserv1	:13;	//	неиспользуется
	uint32_t COUNTFLAG	:1;		//	флаг о переполнении счётчика
	uint32_t reserv		:15;	//	неиспользуется
} StructSYST_CSR;

/***************************************************************************************/

/*********************SYST_RVR — SysTick Reload Value Register**************************/

typedef struct _StructSYST_RVR	//	SysTick Reload Value Register
{
	uint32_t RELOAD		:24;	//	значение счетчика при перезагрузке
	uint32_t reserv1	:8;		//	неиспользуется
} StructSYST_RVR;

/***************************************************************************************/

/*********************SYST_CVR — SysTick Current Value Register*************************/

typedef struct _StructSYST_CVR	//	SysTick Current Value Register
{
	uint32_t CURRENT	:24;	//	текущее значение счетчика
	uint32_t reserv1	:8;		//	неиспользуется
} StructSYST_CVR;

/***************************************************************************************/

/******************SYST_CALIB — SysTick Calibration Value Register**********************/

typedef struct _StructSYST_CALIB	//	SysTick Calibration Value Register
{
	uint32_t TENMS		:24;	//	калибровочная константа
	uint32_t reserv1	:6;		//	неиспользуется
	uint32_t SKEW		:1;		//	0 - константа содержит значение, 1 - мусор
	uint32_t NOREF		:1;		//	0 - эталонная тактовая частота есть, 1 - нет
} StructSYST_CALIB;

/***************************************************************************************/

/***************************************************************************************/

typedef struct _StructSYSTICK
{
	volatile StructSYST_CSR		CSR;		//	регистр контроля системного таймера
	volatile StructSYST_RVR		RVR;		//	значение системного таймера при перезагрузке
	volatile StructSYST_CVR		CVR;		//	текущее значение системного таймера
	volatile StructSYST_CALIB 	CALIB;		//	регистр калибровки системного таймера
}StructSYSTICK;

#define	_SYSTICK	((StructSYSTICK *) 0xe000e010)

/**************************************END SysTick**************************************/


#endif /* BSH_SYSTICK_H_ */
