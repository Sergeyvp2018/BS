/*
 * NVIC.h
 *
 *  Created on: 16 дек. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_NVIC_H_
#define BSH_NVIC_H_

#include "BS.h"

/*****************************************************************************************
Контроллер прерываний NVIC Cortex-M0
- поддерживает 32 прерывания
- программируемый уровень приоритета 0-192 с шагом 64 для каждого прерывания
- обнаружение уровня и импульса сигналов прерывания
- прерывание tail-chaining, позволяет сократить количество тактов при обработке
- внешнее немаскируемое прерывание (NMI)
Контроллер автоматически сохраняет в стеке свое состояние по входу в обработчик прерывания
и восстанавливает его по завершению обработчика, без необходимости непосредственного
программирования этих операций. Это обеспечивает обработку исключительных ситуаций
с малой задержкой.
******************************************************************************************/
/***********************Interrupt set-enable register (ISER)******************************/

typedef struct _StructINTERRUPT
{
	uint32_t WWDG_IRQ					:1;		//	прерывание оконного сторожевого таймера
	uint32_t PVD_VDDIO2_IRQ				:1;		//	PVD & VDDIO2 прерывание через линии 16 и 31
	uint32_t RTC_IRQ					:1;		//	RTC прерывание через линии 17, 19 и 20
	uint32_t FLASH_IRQ					:1;		//	глобальное прерывание FLASH
	uint32_t RCC_CRS_IRQ				:1;		//	глобальное прерывание RCC & CRS
	uint32_t EXTI0_1_IRQ				:1;		//	прерывание EXTI Line 0 и 1
	uint32_t EXTI2_3_IRQ				:1;		//	прерывание EXTI Line 2 и 3
	uint32_t EXTI4_15_IRQ				:1;		//	прерывание EXTI Line 4 по 15
	uint32_t TSC_IRQ					:1;		//	прерывание контроллера касаний
	uint32_t DMA1_Channel1_IRQ			:1;		//	прерывание DMA1 канал 1
	uint32_t DMA1_Channel2_3_IRQ		:1;		//	прерывание DMA1 канал 2 и канал 3
	uint32_t DMA1_Channel4_5_IRQ		:1;		//	прерывание DMA1 канал 4 и канал 5
	uint32_t ADC1_IRQ					:1;		//	прерывание ADC1
	uint32_t TIM1_BRK_UP_TRG_COM_IRQ	:1;		//	прерывание TIM1 перерыв, обновление, переключение и комутация
	uint32_t TIM1_CC_IRQ				:1;		//	прерывание TIM1 захват и сравнение
	uint32_t TIM2_IRQ					:1;		//	глобальное прерывание TIM2
	uint32_t TIM3_IRQ					:1;		//	глобальное прерывание TIM3
	uint32_t TIM6_DAC					:1;		//	глобальное прерывание TIM6 и прерывание при опустошении DAC
	uint32_t TIM7_IRQ					:1;		//	глобальное прерывание TIM7
	uint32_t TIM14_IRQ					:1;		//	глобальное прерывание TIM14
	uint32_t TIM15_IRQ					:1;		//	глобальное прерывание TIM15
	uint32_t TIM16_IRQ					:1;		//	глобальное прерывание TIM16
	uint32_t TIM17_IRQ					:1;		//	глобальное прерывание TIM17
	uint32_t I2C1_IRQ					:1;		//	прерывание события I2C1 и EXTI Line23 (I2C1 пробуждение)
	uint32_t I2C2_IRQ					:1;		//	прерывание события I2C2
	uint32_t SPI1_IRQ					:1;		//	глобальное прерывание SPI1
	uint32_t SPI2_IRQ					:1;		//	глобальное прерывание SPI2
	uint32_t USART1_IRQ					:1;		//	глобальное прерывание USART1& EXTI Line25 (USART1 пробуждение)
	uint32_t USART2_IRQ					:1;		//	глобальное прерывание USART2
	uint32_t USART3_8_IRQn				:1;		//	глобальное прерывание USART3 (совмещено с EXTI line 28)
	uint32_t CEC_CAN_IRQ				:1;		//	глобальное прерывание CEC, CAN & EXTI Line27
	uint32_t USB_IRQ					:1;		//	глобальное прерывание USB & EXTI Line18
} StructINTERRUPT;

/*******************************************************************************************/

#define PRI_HIGHEST	(0b00000000)	//	наивысший приоритет
#define PRI_HIGH	(0b01000000)	//	высокий приоритет
#define PRI_MEDIUM	(0b10000000)	//	средний приоритет
#define PRI_LOW		(0b11000000)	//	низкий приоритет

/**************************Interrupt priority register (IPR0)*******************************/

typedef struct _StructIPR0
{
	uint32_t WWDG_IRQ					:8;		//	прерывание оконного сторожевого таймера
	uint32_t PVD_VDDIO2_IRQ				:8;		//	PVD & VDDIO2 прерывание через линии 16 и 31
	uint32_t RTC_IRQ					:8;		//	RTC прерывание через линии 17, 19 и 20
	uint32_t FLASH_IRQ					:8;		//	глобальное прерывание FLASH
} StructNVIC_IPR0;

/*******************************************************************************************/

/**************************Interrupt priority register (IPR1)*******************************/

typedef struct _StructIPR1
{
	uint32_t RCC_CRS_IRQ				:8;		//	глобальное прерывание RCC & CRS
	uint32_t EXTI0_1_IRQ				:8;		//	прерывание EXTI Line 0 и 1
	uint32_t EXTI2_3_IRQ				:8;		//	прерывание EXTI Line 2 и 3
	uint32_t EXTI4_15_IRQ				:8;		//	прерывание EXTI Line 4 по 15
} StructNVIC_IPR1;

/*******************************************************************************************/

/**************************Interrupt priority register (IPR2)*******************************/

typedef struct _StructIPR2
{
	uint32_t TSC_IRQ					:8;		//	прерывание контроллера касаний
	uint32_t DMA1_Channel1_IRQ			:8;		//	прерывание DMA1 канал 1
	uint32_t DMA1_Channel2_3_IRQ		:8;		//	прерывание DMA1 канал 2 и канал 3
	uint32_t DMA1_Channel4_5_IRQ		:8;		//	прерывание DMA1 канал 4 и канал 5
} StructNVIC_IPR2;

/*******************************************************************************************/

/**************************Interrupt priority register (IPR3)*******************************/

typedef struct _StructIPR3
{
	uint32_t ADC1_IRQ					:8;		//	прерывание ADC1
	uint32_t TIM1_BRK_UP_TRG_COM_IRQ	:8;		//	прерывание TIM1 перерыв, обновление, переключение и комутация
	uint32_t TIM1_CC_IRQ				:8;		//	прерывание TIM1 захват и сравнение
	uint32_t TIM2_IRQ					:8;		//	глобальное прерывание TIM2
} StructNVIC_IPR3;

/*******************************************************************************************/

/**************************Interrupt priority register (IPR4)*******************************/

typedef struct _StructIPR4
{
	uint32_t TIM3_IRQ					:8;		//	глобальное прерывание TIM3
	uint32_t TIM6_DAC					:8;		//	глобальное прерывание TIM6 и прерывание при опустошении DAC
	uint32_t TIM7						:8;		//	глобальное прерывание TIM7
	uint32_t TIM14_IRQ					:8;		//	глобальное прерывание TIM14
} StructNVIC_IPR4;

/*******************************************************************************************/

/**************************Interrupt priority register (IPR5)*******************************/

typedef struct _StructIPR5
{
	uint32_t TIM15_IRQ					:8;		//	глобальное прерывание TIM15
	uint32_t TIM16_IRQ					:8;		//	глобальное прерывание TIM16
	uint32_t TIM17_IRQ					:8;		//	глобальное прерывание TIM17
	uint32_t I2C1_IRQ					:8;		//	прерывание события I2C1 и EXTI Line23 (I2C1 пробуждение)
} StructNVIC_IPR5;

/*******************************************************************************************/

/**************************Interrupt priority register (IPR6)*******************************/

typedef struct _StructIPR6
{
	uint32_t I2C2_IRQ					:8;		//	прерывание события I2C2
	uint32_t SPI1_IRQ					:8;		//	глобальное прерывание SPI1
	uint32_t SPI2_IRQ					:8;		//	глобальное прерывание SPI2
	uint32_t USART1_IRQ					:8;		//	глобальное прерывание USART1& EXTI Line25 (USART1 пробуждение)
} StructNVIC_IPR6;

/*******************************************************************************************/

/**************************Interrupt priority register (IPR7)*******************************/

typedef struct _StructIPR7
{
	uint32_t USART2_IRQ					:8;		//	глобальное прерывание USART2
	uint32_t USART3_8_IRQn				:8;		//	неиспользуется
	uint32_t CEC_CAN_IRQ				:8;		//	глобальное прерывание CEC, CAN & EXTI Line27
	uint32_t USB_IRQ					:8;		//	глобальное прерывание USB & EXTI Line18
} StructNVIC_IPR7;

/*******************************************************************************************/

typedef struct _StructNVIC
{
	volatile StructINTERRUPT	ISER;			//	регистр включения прерываний
	volatile const uint32_t 	RESERV0[31U];
	volatile StructINTERRUPT	ICER;			//	регистр выключения прерываний
	volatile const uint32_t 	RESERV1[31U];
	volatile StructINTERRUPT	ISPR;			//	регистр утановки флагов ожидания
	volatile const uint32_t 	RESERV2[31U];
	volatile StructINTERRUPT	ICPR;			//	регистр сброса флагов ожидания
	volatile const uint32_t 	RESERV3[31U];
	volatile const uint32_t 	RESERV4[64U];
	volatile StructNVIC_IPR0	IPR0;			//	регистр приоритетов
	volatile StructNVIC_IPR1	IPR1;			//	регистр приоритетов
	volatile StructNVIC_IPR2	IPR2;			//	регистр приоритетов
	volatile StructNVIC_IPR3	IPR3;			//	регистр приоритетов
	volatile StructNVIC_IPR4	IPR4;			//	регистр приоритетов
	volatile StructNVIC_IPR5	IPR5;			//	регистр приоритетов
	volatile StructNVIC_IPR6	IPR6;			//	регистр приоритетов
	volatile StructNVIC_IPR7	IPR7;			//	регистр приоритетов
}StructNVIC;

#define	_NVIC	((StructNVIC *) 0xE000E100)		//	структура регистров прерываний

/***************************************************************************************/

#endif /* BSH_NVIC_H_ */





















