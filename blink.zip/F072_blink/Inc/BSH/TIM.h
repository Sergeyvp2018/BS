/*
 * TIM.h
 *
 *  Created on: 31 окт. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_TIM_H_
#define	BSH_TIM_H_

#include "BS.h"

//	Таймеры TIM6/TIM7 доступны только в сериях STM32F05x, STM32F07x и STM32F09x
//	Таймер TIM15 недоступен в серии STM32F03x

/***********************TIM1 1 регистр управления (TIM1_CR1)******************************/

#define	CKD_00		(0b00)		//	tDTS = tCK_INT
#define	CKD_2x		(0b01)		//	tDTS = 2 x tCK_INT
#define	CKD_4x		(0b10)		//	tDTS = 4 x tCK_INT

#define	CMS_DIR		(0b00)		//	направление счёта зависит от бита DIR
#define	CMS_DOWN	(0b01)		//	счёт вниз и вверх, прерывание при счёте вниз
#define	CMS_UP		(0b10)		//	счёт вниз и вверх, прерывание при счёте вверх
#define	CMS_UPDOWN	(0b11)		//	счёт вниз и вверх, прерывание при любом направлении

typedef struct _StructTIM1_CR1	//	TIM1 1 регистр управления (TIM1_CR1)
{
	uint32_t CEN		:1;		//	включить счётчик
	uint32_t UDIS		:1;		//	отключить обновление
	uint32_t URS		:1;		//	запрос обновления источника
	uint32_t OPM		:1;		//	одноимпульсный режим
	uint32_t DIR		:1;		//	направление
	uint32_t CMS		:2;		//	режим счёта
	uint32_t ARPE		:1;		//	включить автоперезагрузку
	uint32_t CKD		:2;		//	делитель тактов
	uint32_t reserv1	:22;	//	неиспользуется
} StructTIM1_CR1;

/*****************************************************************************************/

/***********************TIM1 2 регистр управления (TIM1_CR2)******************************/

#define	MMS_OC1REF	(0b100)		//	сравнение - OC1REF сигнал используется как триггер вывода (TRGO)
#define	MMS_OC2REF	(0b101)		//	сравнение - OC2REF сигнал используется как триггер вывода (TRGO)
#define	MMS_OC3REF	(0b110)		//	сравнение - OC3REF сигнал используется как триггер вывода (TRGO)
#define	MMS_OC4REF	(0b111)		//	сравнение - OC4REF сигнал используется как триггер вывода (TRGO)

typedef struct _StructTIM1_CR2	//	TIM1 2 регистр управления (TIM1_CR2)
{
	uint32_t CCPC		:1;		//	управление предзагрузкой захвата/сравнения
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t CCUS		:1;		//	управление выбором обновления захвата/сравнения
	uint32_t CCDS		:1;		//	выбор DMA захвата/сравнения
	uint32_t MMS		:3;		//	выбор основного режима
	uint32_t TI1S		:1;		//	выбор TI1
	uint32_t OIS1		:1;		//	1 выход в состоянии ожидания (OC1 вывод)
	uint32_t OIS1N		:1;		//	1 выход в состоянии ожидания (OC1N вывод)
	uint32_t OIS2		:1;		//	2 выход в состоянии ожидания (OC2 вывод)
	uint32_t OIS2N		:1;		//	2 выход в состоянии ожидания (OC2N вывод)
	uint32_t OIS3		:1;		//	3 выход в состоянии ожидания (OC3 вывод)
	uint32_t OIS3N		:1;		//	3 выход в состоянии ожидания (OC3N вывод)
	uint32_t OIS4		:1;		//	4 выход в состоянии ожидания (OC4 вывод)
	uint32_t reserv2	:17;	//	неиспользуется
} StructTIM1_CR2;

/*****************************************************************************************/

/*****************TIM1 регистр управления ведомым режимом (TIM1_SMCR)*********************/

#define	SMS_OFF		(0b000)		//	подчинённый режим выключен
#define	SMS_TI2FP1	(0b001)		//	счётчик считает вверх/вниз TI2FP1 фронт зависит от уровня TI1FP2
#define	SMS_TI1FP2	(0b010)		//	счётчик считает вверх/вниз TI1FP2 фронт зависит от уровня TI2FP1
#define	SMS_BOTH	(0b011)		//	счётчик считает вверх/вниз фронты TI1FP1 и TI2FP2 зависят друг от друга
#define	SMS_RESET	(0b100)		//	режим сброса - восходящий фронт выбранного триггерного входа (TRGI)
								//	повторно инициализирует счетчик и генерирует обновление регистров.
#define	SMS_CLOSE	(0b101)		//	ждущий режим - счетчик тактов включается когда триггерный вход (TRGI) в высоком уровне.
								//	Счёт останавливается (но не перезагружается) как только уровень станет низким.
								//	Внешний сигнал управляет как запуском, так и остановкой счётчика.
#define	SMS_TRG		(0b110)		//	режим триггера - счёт начинается на высоком фронте триггера TRGI (но не перезагружается).
								//	Внешний сигнал управляет только началом счёта.
#define	SMS_EXT		(0b111)		//	режим внешнего тактирования 1 - счётчик тактируется восходящим фронтом выбранного триггера (TRGI).

#define	TS_ITR0		(0b000)		//	внутренний триггер 0 (ITR0)
#define	TS_ITR1		(0b001)		//	внутренний триггер 1 (ITR1)
#define	TS_ITR2		(0b010)		//	внутренний триггер 2 (ITR2)
#define	TS_ITR3		(0b011)		//	внутренний триггер 3 (ITR3)
#define	TS_TI1F_ED	(0b100)		//	TI1 детектор фронта (TI1F_ED)
#define	TS_TI1FP1	(0b101)		//	фильтрованный вход таймер 1 (TI1FP1)
#define	TS_TI2FP2	(0b110)		//	фильтрованный вход таймер 2 (TI2FP2)
#define	TS_ETRF		(0b111)		//	вход внешнего триггера (ETRF)

#define	ETF_OFF		(0b0000)	//	нет фильтра
#define	ETF_2		(0b0001)	//	fSAMPLING = fCK_INT , N = 2
#define	ETF_4		(0b0010)	//	fSAMPLING = fCK_INT , N = 4
#define	ETF_8		(0b0011)	//	fSAMPLING = fCK_INT , N = 8
#define	ETF_2_6		(0b0100)	//	fSAMPLING = fDTS / 2, N = 6
#define	ETF_2_8		(0b0101)	//	fSAMPLING = fDTS / 2, N = 8
#define	ETF_4_6		(0b0110)	//	fSAMPLING = fDTS / 4, N = 6
#define	ETF_4_8		(0b0111)	//	fSAMPLING = fDTS / 4, N = 8
#define	ETF_8_6		(0b1000)	//	fSAMPLING = fDTS / 8, N = 6
#define	ETF_8_8		(0b1001)	//	fSAMPLING = fDTS / 8, N = 8
#define	ETF_16_5	(0b1010)	//	fSAMPLING = fDTS / 16, N = 5
#define	ETF_16_6	(0b1011)	//	fSAMPLING = fDTS / 16, N = 6
#define	ETF_16_8	(0b1100)	//	fSAMPLING = fDTS / 16, N = 8
#define	ETF_32_5	(0b1101)	//	fSAMPLING = fDTS / 32, N = 5
#define	ETF_32_6	(0b1110)	//	fSAMPLING = fDTS / 32, N = 6
#define	ETF_32_8	(0b1111)	//	fSAMPLING = fDTS / 32, N = 8

#define	ETPS_OFF	(0b00)		//	нет делителя
#define	ETPS_2		(0b01)		//	ETRP делитель частоты 2
#define	ETPS_4		(0b10)		//	ETRP делитель частоты 4
#define	ETPS_8		(0b11)		//	ETRP делитель частоты 8

typedef struct _StructTIM1_SMCR	//	TIM1 регистр управления ведомым режимом (TIM1_SMCR)
{
	uint32_t SMS		:3;		//	выбор режима подчинённого/ведомого
	uint32_t OCCS		:1;		//	выбор источника очистки OCREF
	uint32_t TS			:3;		//	выбор триггера, изменять только когда SMS=000
	uint32_t MSM		:1;		//	режим основной или подчинённый/ведомый
	uint32_t ETF		:4;		//	фильтр внешнего триггера
	uint32_t ETPS		:2;		//	предделитель внешнего триггера
	uint32_t ECE		:1;		//	внешний сигнал тактов
	uint32_t ETP		:1;		//	полярность внешнего триггера
	uint32_t reserv1	:16;	//	неиспользуется
} StructTIM1_SMCR;

/*****************************************************************************************/

/****************TIM1 регистр включения прерываний/DMA (TIM1_DIER)************************/

typedef struct _StructTIM1_DIER	//	TIM1 регистр включения прерываний/DMA (TIM1_DIER)
{
	uint32_t UIE		:1;		//	включить прерывание при обновлении
	uint32_t CC1IE		:1;		//	включить прерывание захват/сравнение 1
	uint32_t CC2IE		:1;		//	включить прерывание захват/сравнение 2
	uint32_t CC3IE		:1;		//	включить прерывание захват/сравнение 3
	uint32_t CC4IE		:1;		//	включить прерывание захват/сравнение 4
	uint32_t COMIE		:1;		//	включить прервание COM
	uint32_t TIE		:1;		//	включить прервание триггера
	uint32_t BIE		:1;		//	включить прервание при обрыве
	uint32_t UDE		:1;		//	включить запрос DMA при обновлении
	uint32_t CC1DE		:1;		//	включить запрос DMA захват/сравнение 1
	uint32_t CC2DE		:1;		//	включить запрос DMA захват/сравнение 2
	uint32_t CC3DE		:1;		//	включить запрос DMA захват/сравнение 3
	uint32_t CC4DE		:1;		//	включить запрос DMA захват/сравнение 4
	uint32_t COMDE		:1;		//	COM включить запрос DMA
	uint32_t TDE		:1;		//	включить триггер запрос DMA
	uint32_t reserv1	:17;	//	неиспользуется
} StructTIM1_DIER;

/*****************************************************************************************/

/*************************TIM1 регистр состояния (TIM1_SR)********************************/

typedef struct _StructTIM1_SR	//	TIM1 регистр состояния (TIM1_SR)
{
	uint32_t UIF		:1;		//	флаг прерывания при обновлении
	uint32_t CC1IF		:1;		//	флаг прерывания захват/сравнение 1
	uint32_t CC2IF		:1;		//	флаг прерывания захват/сравнение 2
	uint32_t CC3IF		:1;		//	флаг прерывания захват/сравнение 3
	uint32_t CC4IF		:1;		//	флаг прерывания захват/сравнение 4
	uint32_t COMIF		:1;		//	COM флаг прерывания
	uint32_t TIF		:1;		//	флаг прерывания триггера
	uint32_t BIF		:1;		//	флаг прерывания обрыва
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t CC1OF		:1;		//	флаг переполнения захват/сравнение 1
	uint32_t CC2OF		:1;		//	флаг переполнения захват/сравнение 2
	uint32_t CC3OF		:1;		//	флаг переполнения захват/сравнение 3
	uint32_t CC4OF		:1;		//	флаг переполнения захват/сравнение 4
	uint32_t reserv2	:19;	//	неиспользуется
} StructTIM1_SR;

/*****************************************************************************************/

/*******************TIM1 регистр генерации событий (TIM1_EGR)*****************************/

typedef struct _StructTIM1_EGR	//	TIM1 регистр генерации событий (TIM1_EGR)
{
	uint32_t UG			:1;		//	генерация обновления
	uint32_t CC1G		:1;		//	генерация захват/сравнение 1
	uint32_t CC2G		:1;		//	генерация захват/сравнение 2
	uint32_t CC3G		:1;		//	генерация захват/сравнение 3
	uint32_t CC4G		:1;		//	генерация захват/сравнение 4
	uint32_t COMG		:1;		//	захват/сравнение упраление генерацией обновления
	uint32_t TG			:1;		//	генерация триггера
	uint32_t BG			:1;		//	генерация разрыва
	uint32_t reserv1	:24;	//	неиспользуется
} StructTIM1_EGR;

/*****************************************************************************************/

/***************TIM1 регистр режима захват/сравнение 1 (TIM1_CCMR1)***********************/

#define	CCxS_OUT	(0b00)		//	CCx канал настроен на вывод
#define	CCxS_TI13	(0b01)		//	CCx канал настроен на вход, ICx сопоставлен с TI[1,3]
#define	CCxS_TI24	(0b10)		//	CCx канал настроен на вход, ICx сопоставлен с TI[2,4]
#define	CCxS_TRC	(0b11)		//	CCx канал настроен на вход, ICx сопоставлен с TRC

#define	ICxPSC_00	(0b00)		//	нет делителя, захват выполняется каждый раз при изменении уровня на входе
#define	ICxPSC_2	(0b01)		//	захват выполняется каждые 2 события
#define	ICxPSC_4	(0b10)		//	захват выполняется каждые 4 события
#define	ICxPSC_8	(0b11)		//	захват выполняется каждые 8 события

#define	ICxF_0000	(0b0000)	//	нет фильтра
#define	ICxF_2		(0b0001)	//	fSAMPLING = Fck_int , N = 2
#define	ICxF_4		(0b0010)	//	fSAMPLING = Fck_int , N = 4
#define	ICxF_8		(0b0011)	//	fSAMPLING = Fck_int , N = 8
#define	ICxF_2_6	(0b0100)	//	fSAMPLING = Fdts / 2, N = 6
#define	ICxF_2_8	(0b0101)	//	fSAMPLING = Fdts / 2, N = 8
#define	ICxF_4_6	(0b0110)	//	fSAMPLING = Fdts / 4, N = 6
#define	ICxF_4_8	(0b0111)	//	fSAMPLING = Fdts / 4, N = 8
#define	ICxF_8_6	(0b1000)	//	fSAMPLING = Fdts / 8, N = 6
#define	ICxF_8_8	(0b1001)	//	fSAMPLING = Fdts / 8, N = 8
#define	ICxF_16_5	(0b1010)	//	fSAMPLING = Fdts / 16, N = 5
#define	ICxF_16_6	(0b1011)	//	fSAMPLING = Fdts / 16, N = 6
#define	ICxF_16_8	(0b1100)	//	fSAMPLING = Fdts / 16, N = 8
#define	ICxF_32_5	(0b1101)	//	fSAMPLING = Fdts / 32, N = 5
#define	ICxF_32_6	(0b1110)	//	fSAMPLING = Fdts / 32, N = 6
#define	ICxF_32_8	(0b1111)	//	fSAMPLING = Fdts / 32, N = 8

#define	OCxM_000	(0b000)		//	заморожен - сравнение между регистром вывода сравнения TIMx_CCR1 и счётчиком TIMx_CNT не влияют на вывод (этот режим используется для генерации основного тайминга).
#define	OCxM_HIGH	(0b001)		//	установить канал 1 в активный уровень при совпадении.
								//	OC1REF сигнал принудительно высокий когда счётчик TIMx_CNT соответствует регистру захват/сравнение 1 (TIMx_CCR1).
#define	OCxM_LOW	(0b010)		//	установить канал 1 в неактивный уровень при совпадении.
								//	OC1REF сигнал принудительно низкий когда счётчик TIMx_CNT соответствует регистру захват/сравнение 1 (TIMx_CCR1).
#define	OCxM_TGG	(0b011)		//	переключение OC1REF когда TIMx_CNT = TIMx_CCR1.
#define	OCxM_PASS	(0b100)		//	принудительно неактивный уровень - OC1REF принудительно низкий.
#define	OCxM_ACTIV	(0b101)		//	принудительно активный уровень - OC1REF принудительно высокий.
#define	OCxM_PWM1	(0b110)		//	PWM mode 1 - при возрастающем счёте, канал 1 активен пока TIMx_CNT < TIMx_CCR1 затем неактивен.
								//	при нисходящем счёте, канал 1 неактивен (OC1REF=‘0’) пока TIMx_CNT > TIMx_CCR1 затем активен (OC1REF=’1’).
#define	OCxM_PWM2	(0b111)		//	PWM mode 2 - при возрастающем счёте, канал 1 неактивен пока TIMx_CNT < TIMx_CCR1 затем активен.
								//	при нисходящем счёте, канал 1 активен пока TIMx_CNT > TIMx_CCR1 затем неактивен.

typedef struct _Struct1TIM1_CCMR1	//	TIM1 регистр режима захват/сравнение 1 (TIM1_CCMR1)
{
	uint32_t CC1S		:2;		//	выбор ввод/вывод захват/сравнение 1
	uint32_t IC1PSC		:2;		//	предделитель, 1 вход захвата
	uint32_t IC1F		:4;		//	фильтр, 1 вход захвата
	uint32_t CC2S		:2;		//	выбор ввод/вывод захват/сравнение 2
	uint32_t IC2PSC		:2;		//	предделитель, 2 вход захвата
	uint32_t IC2F		:4;		//	фильтр, 2 вход захвата
	uint32_t reserv1	:16;	//	неиспользуется
} Struct1TIM1_CCMR1;

typedef struct _Struct2TIM1_CCMR1	//	TIM1 регистр режима захват/сравнение 1 (TIM1_CCMR1)
{
	uint32_t CC1S		:2;		//	выбор ввод/вывод захват/сравнение 1
	uint32_t OC1FE		:1;		//	быстрое сравнение вывод 1
	uint32_t OC1PE		:1;		//	буферизация вывод сравнения 1
	uint32_t OC1M		:3;		//	выбор ввод/вывод захват/сравнение 2
	uint32_t OC1CE		:1;		//	высокий уровень ETRF сбрасывает OC1Ref
	uint32_t CC2S		:2;		//	выбор ввод/вывод захват/сравнение 2
	uint32_t OC2FE		:1;		//	быстрое сравнение вывод сравнения 2
	uint32_t OC2PE		:1;		//	буферизация вывод сравнения 2
	uint32_t OC2M		:3;		//	режим вывода сравнения 2
	uint32_t OC2CE		:1;		//	высокий уровень ETRF сбрасывает OC1Ref
	uint32_t reserv1	:16;	//	неиспользуется
} Struct2TIM1_CCMR1;

typedef union _TIM1_CCMR1_BS		//	TIM1 регистр режима захват/сравнение 1 (TIM1_CCMR1)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile Struct1TIM1_CCMR1 BS1;	//	структура бит
	volatile Struct2TIM1_CCMR1 BS2;	//	структура бит
} UnionTIM1_CCMR1;

/*****************************************************************************************/

/***************TIM1 регистр режима захват/сравнение 2 (TIM1_CCMR2)***********************/

typedef struct _Struct1TIM1_CCMR2	//	TIM1 регистр режима захват/сравнение 2 (TIM1_CCMR2)
{
	uint32_t CC3S		:2;		//	набор захват/сравнение 3
	uint32_t IC3PSC		:2;		//	Input capture 3 prescaler
	uint32_t IC3F		:4;		//	Input capture 3 filter
	uint32_t CC4S		:2;		//	набор захват/сравнение 4
	uint32_t IC4PSC		:2;		//	Input capture 4 prescaler
	uint32_t IC4F		:4;		//	захват/сравнение упраление генерацией обновления
	uint32_t reserv		:16;	//	неиспользуется
} Struct1TIM1_CCMR2;

typedef struct _Struct2TIM1_CCMR2	//	TIM1 регистр режима захват/сравнение 2 (TIM1_CCMR2)
{
	uint32_t CC3S		:2;		//	набор захват/сравнение 3
	uint32_t OC3FE		:1;		//	вывод сравнения 3 быстрое включение
	uint32_t OC3PE		:1;		//	вывод сравнения 3 включить предзагрузку
	uint32_t OC3M		:3;		//	набор захват/сравнение 3
	uint32_t OC3CE		:1;		//	вывод сравнения 3 включить очистку
	uint32_t CC4S		:2;		//	набор захват/сравнение 4
	uint32_t OC4FE		:1;		//	вывод сравнения 4 быстрое включение
	uint32_t OC4PE		:1;		//	вывод сравнения 4 включить предзагрузку
	uint32_t OC4M		:3;		//	вывод сравнения 4 mode
	uint32_t OC4CE		:1;		//	вывод сравнения 4 включить очистку
	uint32_t reserv		:16;	//	неиспользуется
} Struct2TIM1_CCMR2;

typedef union _TIM1_CCMR2_BS		//	TIM1 регистр режима захват/сравнение 2 (TIM1_CCMR2)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile Struct1TIM1_CCMR2 BS1;	//	структура бит
	volatile Struct2TIM1_CCMR2 BS2;	//	структура бит
} UnionTIM1_CCMR2;

/*****************************************************************************************/

/****************TIM1 регистр включения захват/сравнения (TIM1_CCER)**********************/

typedef struct _StructTIM1_CCER		//	TIM1 регистр включения захват/сравнения (TIM1_CCER)
{
	uint32_t CC1E		:1;			//	включить вывод захват/сравнение 1
	uint32_t CC1P		:1;			//	полярность вывода захват/сравнение 1
	uint32_t CC1NE		:1;			//	включить дополнительный вывод захват/сравнение 1
	uint32_t CC1NP		:1;			//	полярность дополнительного вывода захват/сравнение 1
	uint32_t CC2E		:1;			//	захват/сравнение 2 output enable
	uint32_t CC2P		:1;			//	захват/сравнение 2 output polarity
	uint32_t CC2NE		:1;			//	захват/сравнение 2 complementary output enable
	uint32_t CC2NP		:1;			//	полярность на дополнительном выводе захват/сравнение 2
	uint32_t CC3E		:1;			//	захват/сравнение 3 output enable
	uint32_t CC3P		:1;			//	захват/сравнение 3 output polarity
	uint32_t CC3NE		:1;			//	захват/сравнение 3 complementary output enable
	uint32_t CC3NP		:1;			//	захват/сравнение 3 complementary output polarity
	uint32_t CC4E		:1;			//	захват/сравнение 4 output enable
	uint32_t CC4P		:1;			//	захват/сравнение 4 output polarity
	uint32_t reserv1	:18;		//	неиспользуется
} StructTIM1_CCER;

/*****************************************************************************************/

/******************TIM1 регистр обрыва связи и времени простоя (TIM1_BDTR)**********************/

#define	LOCK_OFF	(0b00)			//	нет бит защищённых от записи.
#define	LOCK_LVL1	(0b01)			//	LOCK Level 1 = DTG биты в регистре TIMx_BDTR,
									//	OISx и OISxN биты в регистре TIMx_CR2 и
									//	BKE/BKP/AOE биты в регистре TIMx_BDTR заблокированы для записи.
#define	LOCK_LVL2	(0b10)			//	LOCK Level 2 = LOCK Level 1 + CC биты полярности
									//	(CCxP/CCxNP биты в регистре TIMx_CCER, пока связанный канал настроен на вывод через биты CCxS)
									//	а также OSSR и OSSI биты заблокированы для записи.
#define	LOCK_LVL3	(0b11)			//	LOCK Level 3 = LOCK Level 2 + CC биты управления
									//	(OCxM и OCxPE биты в регистре TIMx_CCMRx, пока связанный канал настроен на вывод через биты CCxS)
									//	заблокированы для записи.

typedef struct _StructTIM1_BDTR		//	TIM1 регистр разрыва и времени простоя (TIM1_BDTR)
{
	uint32_t DTG		:8;			//	установка генератора времени простоя
	uint32_t LOCK		:2;			//	блокировка конфигурации
	uint32_t OSSI		:1;			//	выбор выключенного состояния в режиме простоя
	uint32_t OSSR		:1;			//	выбор выключенного состояния в режиме выполнения
	uint32_t BKE		:1;			//	разрешить разрыв
	uint32_t BKP		:1;			//	полярность обрыва
	uint32_t AOE		:1;			//	включить автоматический вывод
	uint32_t MOE		:1;			//	включить основной вывод
	uint32_t reserv1	:16;		//	неиспользуется
} StructTIM1_BDTR;

/*****************************************************************************************/

/***********************TIM1 регистр управления DMA (TIM1_DCR)****************************/

typedef struct _StructTIM1_DCR		//	TIM1 регистр управления DMA (TIM1_DCR)
{
	uint32_t DBA		:5;			//	базовый адрес DMA
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t DBL		:5;			//	длина пакета DMA
	uint32_t reserv2	:19;		//	неиспользуется
} StructTIM1_DCR;

/*****************************************************************************************/

/*****************************************************************************************/

typedef struct _StructTIM1				//	структура регистров таймера 1
{
	volatile StructTIM1_CR1		CR1;	//	первый регистр управления (TIM1_CR1)
	volatile StructTIM1_CR2		CR2;	//	второй регистр управления (TIM1_CR2)
	volatile StructTIM1_SMCR	SMCR;	//	регистр управления ведомым режимом (TIM1_SMCR)
	volatile StructTIM1_DIER	DIER;	//	регистр включения прерываний/DMA (TIM1_DIER)
	volatile StructTIM1_SR		SR;		//	регистр статуса (TIM1_SR)
	volatile StructTIM1_EGR		EGR;	//	регистр генерации событий (TIM1_EGR)
	volatile UnionTIM1_CCMR1	CCMR1;	//	первый регистр режима захват/сравнение (TIM1_CCMR1)
	volatile UnionTIM1_CCMR2	CCMR2;	//	второй регистр режима захват/сравнение (TIM1_CCMR2)
	volatile StructTIM1_CCER	CCER;	//	регистр включения захвт/сравнение (TIM1_CCER)
	volatile uint16_t			CNT;	//	счетчик (TIM1_CNT)
	volatile const uint16_t		RESERV0;//	зарезервировано
	volatile uint16_t			PSC;	//	предделитель (TIM1_PSC)
	volatile const uint16_t		RESERV1;//	зарезервировано
	volatile uint16_t			ARR;	//	регистр автоперезагрузки (TIM1_ARR)
	volatile const uint16_t		RESERV2;//	зарезервировано
	volatile uint16_t			RCR;	//	регистр счетчика повторений (TIM1_RCR)
	volatile const uint16_t		RESERV3;//	зарезервировано
	volatile uint16_t			CCR1;	//	первый регистр захват/сравнение (TIM1_CCR1)
	volatile const uint16_t		RESERV4;//	зарезервировано
	volatile uint16_t			CCR2;	//	второй регистр захват/сравнение (TIM1_CCR2)
	volatile const uint16_t		RESERV5;//	зарезервировано
	volatile uint16_t			CCR3;	//	третий регистр захват/сравнение (TIM1_CCR3)
	volatile const uint16_t		RESERV6;//	зарезервировано
	volatile uint16_t			CCR4;	//	четвёртый регистр захват/сравнение (TIM1_CCR4)
	volatile const uint16_t		RESERV7;//	зарезервировано
	volatile StructTIM1_BDTR	BDTR;	//	регистр паузы и простоя (TIM1_BDTR)
	volatile StructTIM1_DCR		DCR;	//	регистр управления DMA (TIM1_DCR)
	volatile uint16_t			DMAR;	//	базовый адрес DMA (TIM1_DMAR)
	volatile const uint16_t		RESERV8;//	зарезервировано
}StructTIM1;

#define	_TIM1	((StructTIM1 *) 0x40012c00)

/**************************************TIM1 END*******************************************/

/*************TIM2 и TIM3 1 регистр управления (TIM2_CR1 and TIM3_CR1)********************/

typedef struct _StructTIM23_CR1	//	TIM2 и TIM3 1 регистр управления (TIM23_CR1)
{
	uint32_t CEN		:1;		//	включить счётчик
	uint32_t UDIS		:1;		//	отключить обновление
	uint32_t URS		:1;		//	запрос обновления источника
	uint32_t OPM		:1;		//	одноимпульсный режим
	uint32_t DIR		:1;		//	направление
	uint32_t CMS		:2;		//	режим счёта
	uint32_t ARPE		:1;		//	включить автоперезагрузку
	uint32_t CKD		:2;		//	делитель тактов
	uint32_t reserv1	:22;	//	неиспользуется
} StructTIM23_CR1;

/*****************************************************************************************/

/**************TIM2 и TIM3 2 регистр управления (TIM2_CR2 and TIM3_CR2)*******************/

typedef struct _StructTIM23_CR2	//	TIM2 и TIM3 2 регистр управления (TIM23_CR2)
{
	uint32_t reserv1	:3;		//	неиспользуется
	uint32_t CCDS		:1;		//	выбор DMA захвата/сравнения
	uint32_t MMS		:3;		//	выбор основного режима
	uint32_t TI1S		:1;		//	выбор TI1
	uint32_t reserv2	:24;	//	неиспользуется
} StructTIM23_CR2;

/*****************************************************************************************/

/***************TIM2 и TIM3 регистр управления ведомым режимом (TIM23_SMCR)***************/

typedef struct _StructTIM23_SMCR	//	TIM2 и TIM3 регистр управления ведомым режимом (TIM23_SMCR)
{
	uint32_t SMS		:3;		//	выбор режима подчинённого/ведомого
	uint32_t OCCS		:1;		//	выбор источника очистки OCREF
	uint32_t TS			:3;		//	выбор триггера, изменять только когда SMS=000
	uint32_t MSM		:1;		//	режим основной или подчинённый/ведомый
	uint32_t ETF		:4;		//	фильтр внешнего триггера
	uint32_t ETPS		:2;		//	предделитель внешнего триггера
	uint32_t ECE		:1;		//	внешний сигнал тактов
	uint32_t ETP		:1;		//	полярность внешнего триггера
	uint32_t reserv1	:16;	//	неиспользуется
} StructTIM23_SMCR;

/*****************************************************************************************/

/****************TIM2 и TIM3 регистр включения прерываний/DMA (TIM23_DIER)****************/

typedef struct _StructTIM23_DIER	//	TIM2 и TIM3 регистр включения прерываний/DMA (TIM23_DIER)
{
	uint32_t UIE		:1;		//	включить прерывание при обновлении
	uint32_t CC1IE		:1;		//	включить прерывание захват/сравнение 1
	uint32_t CC2IE		:1;		//	включить прерывание захват/сравнение 2
	uint32_t CC3IE		:1;		//	включить прерывание захват/сравнение 3
	uint32_t CC4IE		:1;		//	включить прерывание захват/сравнение 4
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t TIE		:1;		//	включить прервание триггера
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t UDE		:1;		//	включить запрос DMA при обновлении
	uint32_t CC1DE		:1;		//	включить запрос DMA захват/сравнение 1
	uint32_t CC2DE		:1;		//	включить запрос DMA захват/сравнение 2
	uint32_t CC3DE		:1;		//	включить запрос DMA захват/сравнение 3
	uint32_t CC4DE		:1;		//	включить запрос DMA захват/сравнение 4
	uint32_t reserv3	:1;		//	неиспользуется
	uint32_t TDE		:1;		//	включить триггер запрос DMA
	uint32_t reserv4	:17;	//	неиспользуется
} StructTIM23_DIER;

/*****************************************************************************************/

/*************************TIM2 и TIM3 регистр состояния (TIM23_SR)************************/

typedef struct _StructTIM23_SR	//	TIM2 и TIM3 регистр состояния (TIM23_SR)
{
	uint32_t UIF		:1;		//	флаг прерывания при обновлении
	uint32_t CC1IF		:1;		//	флаг прерывания захват/сравнение 1
	uint32_t CC2IF		:1;		//	флаг прерывания захват/сравнение 2
	uint32_t CC3IF		:1;		//	флаг прерывания захват/сравнение 3
	uint32_t CC4IF		:1;		//	флаг прерывания захват/сравнение 4
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t TIF		:1;		//	флаг прерывания триггера
	uint32_t reserv2	:2;		//	неиспользуется
	uint32_t CC1OF		:1;		//	флаг переполнения захват/сравнение 1
	uint32_t CC2OF		:1;		//	флаг переполнения захват/сравнение 2
	uint32_t CC3OF		:1;		//	флаг переполнения захват/сравнение 3
	uint32_t CC4OF		:1;		//	флаг переполнения захват/сравнение 4
	uint32_t reserv3	:19;	//	неиспользуется
} StructTIM23_SR;

/*****************************************************************************************/

/*******************TIM2 и TIM3 регистр генерации событий (TIM23_EGR)*********************/

typedef struct _StructTIM23_EGR	//	TIM2 и TIM3 регистр генерации событий (TIM23_EGR)
{
	uint32_t UG			:1;		//	генерация обновления
	uint32_t CC1G		:1;		//	генерация захват/сравнение 1
	uint32_t CC2G		:1;		//	генерация захват/сравнение 2
	uint32_t CC3G		:1;		//	генерация захват/сравнение 3
	uint32_t CC4G		:1;		//	генерация захват/сравнение 4
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t TG			:1;		//	генерация триггера
	uint32_t reserv2	:25;	//	неиспользуется
} StructTIM23_EGR;

/*****************************************************************************************/

/*************TIM2 и TIM3 1 регистр режима захвата/сравнения (TIM23_CCMR1)****************/

typedef struct _Struct1TIM23_CCMR1	//	TIM2 и TIM3 1 регистр режима захвата/сравнения (TIM23_CCMR1)
{
	uint32_t CC1S		:2;		//	выбор ввод/вывод захват/сравнение 1
	uint32_t IC1PSC		:2;		//	предделитель захвата 1 вход
	uint32_t IC1F		:4;		//	фильтр, 1 вход захвата
	uint32_t CC2S		:2;		//	выбор ввод/вывод захват/сравнение 2
	uint32_t IC2PSC		:2;		//	предделитель захвата 2 вход
	uint32_t IC2F		:4;		//	фильтр, 2 вход захвата
	uint32_t reserv		:16;	//	неиспользуется
} Struct1TIM23_CCMR1;

typedef struct _Struct2TIM23_CCMR1	//	TIM2 и TIM3 1 регистр режима захвата/сравнения (TIM23_CCMR1)
{
	uint32_t CC1S		:2;		//	выбор ввод/вывод захват/сравнение 1
	uint32_t OC1FE		:1;		//	быстрое сравнение вывод 1
	uint32_t OC1PE		:1;		//	буферизация вывод сравнения 1
	uint32_t OC1M		:3;		//	выбор ввод/вывод захват/сравнение 2
	uint32_t OC1CE		:1;		//	высокий уровень ETRF сбрасывает OC1Ref
	uint32_t CC2S		:2;		//	выбор ввод/вывод захват/сравнение 2
	uint32_t OC2FE		:1;		//	быстрое сравнение вывод сравнения 2
	uint32_t OC2PE		:1;		//	буферизация вывод сравнения 2
	uint32_t OC2M		:3;		//	режим вывода сравнения 2
	uint32_t OC2CE		:1;		//	высокий уровень ETRF сбрасывает OC1Ref
	uint32_t reserv		:16;	//	неиспользуется
} Struct2TIM23_CCMR1;

typedef union _TIM23_CCMR1_BS	//	TIM2 и TIM3 1 регистр режима захвата/сравнения (TIM23_CCMR1)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile Struct1TIM23_CCMR1 BS1;	//	структура бит
	volatile Struct2TIM23_CCMR1 BS2;	//	структура бит
} UnionTIM23_CCMR1;

/*****************************************************************************************/

/***************TIM2 и TIM3 2 регистр режима захвата/сравнения (TIM23_CCMR2)**************/

typedef struct _Struct1TIM23_CCMR2	//	TIM2 и TIM3 2 регистр режима захвата/сравнения (TIM23_CCMR2)
{
	uint32_t CC3S		:2;		//	набор захват/сравнение 3
	uint32_t IC3PSC		:2;		//	Input capture 3 prescaler
	uint32_t IC3F		:4;		//	Input capture 3 filter
	uint32_t CC4S		:2;		//	набор захват/сравнение 4
	uint32_t IC4PSC		:2;		//	Input capture 4 prescaler
	uint32_t IC4F		:4;		//	захват/сравнение упраление генерацией обновления
	uint32_t reserv1	:16;	//	неиспользуется
} Struct1TIM23_CCMR2;

typedef struct _Struct2TIM23_CCMR2	//	TIM2 и TIM3 2 регистр режима захвата/сравнения (TIM23_CCMR2)
{
	uint32_t CC3S		:2;		//	набор захват/сравнение 3
	uint32_t OC3FE		:1;		//	вывод сравнения 3 быстрое включение
	uint32_t OC3PE		:1;		//	вывод сравнения 3 включить предзагрузку
	uint32_t OC3M		:3;		//	набор захват/сравнение 3
	uint32_t OC3CE		:1;		//	вывод сравнения 3 включить очистку
	uint32_t CC4S		:2;		//	набор захват/сравнение 4
	uint32_t OC4FE		:1;		//	вывод сравнения 4 быстрое включение
	uint32_t OC4PE		:1;		//	вывод сравнения 4 включить предзагрузку
	uint32_t OC4M		:3;		//	вывод сравнения 4 mode
	uint32_t OC4CE		:1;		//	вывод сравнения 4 включить очистку
	uint32_t reserv1	:16;	//	неиспользуется
} Struct2TIM23_CCMR2;

typedef union _TIM23_CCMR2_BS		//	TIM2 и TIM3 2 регистр режима захвата/сравнения (TIM23_CCMR2)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile Struct1TIM23_CCMR2 BS1;	//	структура бит
	volatile Struct2TIM23_CCMR2 BS2;	//	структура бит
} UnionTIM23_CCMR2;

/*****************************************************************************************/

/****************TIM2 и TIM3 регистр включения захват/сравнения (TIM23_CCER)**************/

typedef struct _StructTIM23_CCER	//	TIM2 и TIM3 регистр включения захват/сравнения (TIM23_CCER)
{
	uint32_t CC1E		:1;			//	включить вывод захват/сравнение 1
	uint32_t CC1P		:1;			//	полярность вывода захват/сравнение 1
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t CC1NP		:1;			//	полярность дополнительного вывода захват/сравнение 1
	uint32_t CC2E		:1;			//	захват/сравнение 2 output enable
	uint32_t CC2P		:1;			//	захват/сравнение 2 output polarity
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t CC2NP		:1;			//	полярность на дополнительном выводе захват/сравнение 2
	uint32_t CC3E		:1;			//	захват/сравнение 3 output enable
	uint32_t CC3P		:1;			//	захват/сравнение 3 output polarity
	uint32_t reserv3	:1;			//	неиспользуется
	uint32_t CC3NP		:1;			//	захват/сравнение 3 complementary output polarity
	uint32_t CC4E		:1;			//	захват/сравнение 4 output enable
	uint32_t CC4P		:1;			//	захват/сравнение 4 output polarity
	uint32_t reserv4	:1;			//	неиспользуется
	uint32_t CC4NP		:1;			//	захват/сравнение 4 output Polarity
	uint32_t reserv5	:16;		//	неиспользуется
} StructTIM23_CCER;

/*****************************************************************************************/

/***********************TIM2 и TIM3 регистр управления DMA (TIM23_DCR)********************/

typedef struct _StructTIM23_DCR	//	TIM2 и TIM3 регистр управления DMA (TIM23_DCR)
{
	uint32_t DBA		:5;			//	базовый адрес DMA
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t DBL		:5;			//	длина пакета DMA
	uint32_t reserv2	:19;		//	неиспользуется
} StructTIM23_DCR;

/*****************************************************************************************/

/*****************************************************************************************/

typedef struct _StructTIM23					//	структура регистров таймеров 2 и 3
{
	volatile StructTIM23_CR1	CR1;		//	первый регистр управления (TIM23_CR1)
	volatile StructTIM23_CR2	CR2;		//	второй регистр управления (TIM23_CR2)
	volatile StructTIM23_SMCR	SMCR;		//	регистр управления ведомым режимом (TIM23_SMCR)
	volatile StructTIM23_DIER	DIER;		//	регистр включения прерываний/DMA (TIM23_DIER)
	volatile StructTIM23_SR		SR;			//	регистр статуса (TIM23_SR)
	volatile StructTIM23_EGR	EGR;		//	регистр генерации событий (TIM23_EGR)
	volatile UnionTIM23_CCMR1	CCMR1;		//	первый регистр режима захват/сравнение (TIM23_CCMR1)
	volatile UnionTIM23_CCMR2	CCMR2;		//	второй регистр режима захват/сравнение (TIM23_CCMR2)
	volatile StructTIM23_CCER	CCER;		//	регистр включения захвт/сравнение (TIM23_CCER)
	volatile uint32_t			CNT;		//	счетчик (TIM23_CNT)
	volatile uint32_t			PSC;		//	предделитель (TIM23_PSC)
	volatile uint32_t			ARR;		//	регистр автоперезагрузки (TIM23_ARR)
	volatile const uint32_t		RESERV0;	//	зарезервировано
	volatile uint32_t			CCR1;		//	первый регистр захват/сравнение (TIM23_CCR1)
	volatile uint32_t			CCR2;		//	второй регистр захват/сравнение (TIM23_CCR2)
	volatile uint32_t			CCR3;		//	третий регистр захват/сравнение (TIM23_CCR3)
	volatile uint32_t			CCR4;		//	четвёртый регистр захват/сравнение (TIM23_CCR4)
	volatile const uint32_t		RESERV1;	//	зарезервировано
	volatile StructTIM23_DCR	DCR;		//	регистр управления DMA (TIM23_DCR)
	volatile uint32_t			DMAR;		//	базовый адрес DMA (TIM23_DMAR)
}StructTIM23;

#define	_TIM2	((StructTIM23 *) 0x40000000)
#define	_TIM3	((StructTIM23 *) 0x40000400)

/**************************************TIM2 и TIM3 END************************************/

/*********************TIM14 1 регистр управления (TIM14_CR1)******************************/

typedef struct _StructTIM14_CR1	//	TIM14 1 регистр управления (TIM14_CR1)
{
	uint32_t CEN		:1;		//	включить счётчик
	uint32_t UDIS		:1;		//	отключить обновление
	uint32_t URS		:1;		//	запрос обновления источника
	uint32_t reserv1	:4;		//	неиспользуется
	uint32_t ARPE		:1;		//	включить автоперезагрузку
	uint32_t CKD		:2;		//	делитель тактов
	uint32_t reserv2	:22;	//	неиспользуется
} StructTIM14_CR1;

/*****************************************************************************************/

/****************TIM14 регистр включения прерываний (TIM14_DIER)**************************/

typedef struct _StructTIM14_DIER	//	TIM14 регистр включения прерываний (TIM14_DIER)
{
	uint32_t UIE		:1;			//	включить прерывание при обновлении
	uint32_t CC1IE		:1;			//	включить прерывание захват/сравнение 1
	uint32_t reserv1	:30;		//	неиспользуется
} StructTIM14_DIER;

/*****************************************************************************************/

/***********************TIM14 регистр состояния (TIM14_SR)********************************/

typedef struct _StructTIM14_SR	//	TIM14 регистр состояния (TIM14_SR)
{
	uint32_t UIF		:1;		//	включить прерывание при обновлении
	uint32_t CC1IF		:1;		//	флаг прерывания захват/сравнение 1
	uint32_t reserv1	:7;		//	неиспользуется
	uint32_t CC1OF		:1;		//	флаг переполнения захват/сравнение 1
	uint32_t reserv2	:22;	//	неиспользуется
} StructTIM14_SR;

/*****************************************************************************************/

/****************TIM14 регистр генерации событий (TIM14_EGR)******************************/

typedef struct _StructTIM14_EGR	//	TIM14 регистр генерации событий (TIM14_EGR)
{
	uint32_t UG			:1;		//	генерация обновления
	uint32_t CC1G		:1;		//	генерация захват/сравнение 1
	uint32_t reserv2	:30;	//	неиспользуется
} StructTIM14_EGR;

/*****************************************************************************************/

/*************TIM14 регистр режима захват/сравнение 1 (TIM14_CCMR1)***********************/

#define	OC1M_000		(0b000)		//	сравнение отключено
#define	OC1M_001		(0b001)		//	OC1REF - высокий уровень когда счётчик TIMx_CNT равен регистру захвата сравнения 1 (TIMx_CCR1)
#define	OC1M_010		(0b010)		//	OC1REF - низкий уровень когда счётчик TIMx_CNT равен регистру захвата сравнения 1 (TIMx_CCR1)
#define	OC1M_011		(0b011)		//	OC1REF переключается когда TIMx_CNT = TIMx_CCR1
#define	OC1M_100		(0b100)		//	OC1REF принудительно низкий уровень
#define	OC1M_101		(0b101)		//	OC1REF принудительно высоки уровень
#define	OC1M_110		(0b110)		//	PWM режим 1 - канал 1 высокий уровень пока TIMx_CNT < TIMx_CCR1 иначе низкий
#define	OC1M_111		(0b111)		//	PWM режим 2 - канал 1 низкий уровень пока TIMx_CNT < TIMx_CCR1 иначе высокий

#define	IC1F_0			(0b0000)	//	нет фильтра, отбор производится в Fdts
#define	IC1F_2			(0b0001)	//	Fs = Fck_int , N = 2
#define	IC1F_4			(0b0010)	//	Fs = Fck_int , N = 4
#define	IC1F_8			(0b0011)	//	Fs = Fck_int , N = 8
#define	IC1F_2_6		(0b0100)	//	Fs = Fdts / 2, N = 6
#define	IC1F_2_8		(0b0101)	//	Fs = Fdts / 2, N = 8
#define	IC1F_4_6		(0b0110)	//	Fs = Fdts / 4, N = 6
#define	IC1F_4_8		(0b0111)	//	Fs = Fdts / 4, N = 8
#define	IC1F_8_6		(0b1000)	//	Fs = Fdts / 8, N = 6
#define	IC1F_8_8		(0b1001)	//	Fs = Fdts / 8, N = 8
#define	IC1F_16_5		(0b1010)	//	Fs = Fdts / 16, N = 5
#define	IC1F_16_6		(0b1011)	//	Fs = Fdts / 16, N = 6
#define	IC1F_16_8		(0b1100)	//	Fs = Fdts / 16, N = 8
#define	IC1F_32_5		(0b1101)	//	Fs = Fdts / 32, N = 5
#define	IC1F_32_6		(0b1110)	//	Fs = Fdts / 32, N = 6
#define	IC1F_32_8		(0b1111)	//	Fs = Fdts / 32, N = 8

#define	IC1PSC_00		(0b00)		//	нет предделителя, захват выполняется при каждом событии
#define	IC1PSC_2		(0b01)		//	захват выполняется один раз в 2 события
#define	IC1PSC_4		(0b10)		//	захват выполняется один раз в 4 события
#define	IC1PSC_8		(0b11)		//	захват выполняется один раз в 8 событий

#define	CC1S_OUT		(0b00)		//	выход
#define	CC1S_INPUT		(0b01)		//	вход

typedef struct _StructTIM14_CCMR1	//	TIM14 регистр режима захват/сравнение 1 (TIM14_CCMR1)
{
	uint32_t CC1S		:2;			//	00 - выход, 01 - вход
	uint32_t OC1FE		:1;			//	сравнение вывода 1 быстрое включение
	uint32_t OC1PE		:1;			//	сравнение вывода 1 включение предварительной загрузки
	uint32_t IC1F		:4;			//	фильтр захвата входа 1
	uint32_t reserv1	:24;		//	неиспользуется
} StructTIM14_CCMR1;

typedef struct _StructTIM14_CCMR1_ADD	//	TIM14 регистр режима захват/сравнение 1 (TIM14_CCMR1)
{
	uint32_t CC1S		:2;			//	00 - выход, 01 - вход ICx сопоставлен с TI[1,3], 10 - TI[2,4], 11 - TRC
	uint32_t IC1PSC		:2;			//	предделитель входящего сигнала
	uint32_t OC1M		:3;			//	режим сравнения вывод 1
	uint32_t reserv1	:25;		//	неиспользуется
} StructTIM14_CCMR1_ADD;

typedef union _TIM14_CCMR1_BS		//	TIM14 регистр режима захват/сравнение 1 (TIM14_CCMR1)
{
	volatile uint32_t R;					//	ссылка на регистр
	volatile StructTIM14_CCMR1 BS1;		//	структура бит
	volatile StructTIM14_CCMR1_ADD BS2;	//	структура бит
} UnionTIM14_CCMR1;

/*****************************************************************************************/

/**************TIM14 регистр включения захват/сравнения (TIM14_CCER)**********************/

typedef struct _StructTIM14_CCER	//	TIM14 регистр включения захват/сравнения (TIM14_CCER)
{
	uint32_t CC1E		:1;			//	включить вывод захват/сравнение 1
	uint32_t CC1P		:1;			//	полярность вывода захват/сравнение 1
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t CC1NP		:1;			//	полярность дополнительного вывода захват/сравнение 1
	uint32_t reserv2	:28;		//	неиспользуется
} StructTIM14_CCER;

/*****************************************************************************************/

/***********************TIM14 регистр опций (TIM14_OR)************************************/

#define	TI1_RMP_GPIO	(0b00)		//	TIM14 Channel1 is connected to the GPIO
#define	TI1_RMP_RTCCLK	(0b01)		//	TIM14 Channel1 is connected to the RTCCLK
#define	TI1_RMP_HSE32	(0b10)		//	TIM14 Channel1 is connected to the HSE/32 Clock
#define	TI1_RMP_MCO	(0b11)		//	TIM14 Channel1 is connected to the microcontroller clock output (MCO)

typedef struct _StructTIM14_OR		//	TIM14 регистр опций (TIM14_OR)
{
	uint32_t TI1_RMP	:2;			//	переопределение входа 1 таймера
	uint32_t reserv		:30;		//	неиспользуется
} StructTIM14_OR;

/*****************************************************************************************/

/*****************************************************************************************/


typedef struct _StructTIM14					//	структура регистров таймера 14
{
	volatile StructTIM14_CR1	CR1;		//	первый регистр управления (TIM14_CR1)
	volatile const uint32_t		RESERV0;	//	зарезервировано
	volatile const uint32_t		RESERV1;	//	зарезервировано
	volatile StructTIM14_DIER	DIER;		//	регистр включения прерываний/DMA (TIM14_DIER)
	volatile StructTIM14_SR		SR;			//	регистр статуса (TIM14_SR)
	volatile StructTIM14_EGR	EGR;		//	регистр генерации событий (TIM14_EGR)
	volatile UnionTIM14_CCMR1	CCMR1;		//	первый регистр режима захват/сравнение (TIM14_CCMR1)
	volatile const uint32_t		RESERV2;	//	зарезервировано
	volatile StructTIM14_CCER	CCER;		//	регистр включения захвт/сравнение (TIM14_CCER)
	volatile uint16_t			CNT;		//	счетчик (TIM14_CNT)
	volatile const uint16_t		RESERV3;	//	зарезервировано
	volatile uint16_t			PSC;		//	предделитель (TIM14_PSC)
	volatile const uint16_t		RESERV4;	//	зарезервировано
	volatile uint16_t			ARR;		//	регистр автоперезагрузки (TIM14_ARR)
	volatile const uint16_t		RESERV5;	//	зарезервировано
	volatile const uint32_t		RESERV6;	//	зарезервировано
	volatile uint16_t			CCR1;		//	первый регистр захват/сравнение (TIM14_CCR1)
	volatile const uint16_t		RESERV7;	//	зарезервировано
	volatile const uint32_t		RESERV[6];	//	зарезервировано
	volatile StructTIM14_OR		OR;			//	регистр опций (TIM14_OR)
}StructTIM14;

#define	_TIM14	((StructTIM14 *) 0x40002000))

/***********************************TIM14 END*********************************************/

/***********************TIM15 1 регистр управления (TIM15_CR1)****************************/

typedef struct _StructTIM15_CR1	//	TIM15 1 регистр управления (TIM15_CR1)
{
	uint32_t CEN		:1;		//	включить счётчик
	uint32_t UDIS		:1;		//	отключить обновление
	uint32_t URS		:1;		//	запрос обновления источника
	uint32_t OPM		:1;		//	одноимпульсный режим
	uint32_t reserv1	:3;		//	неиспользуется
	uint32_t ARPE		:1;		//	включить автоперезагрузку
	uint32_t CKD		:2;		//	делитель тактов
	uint32_t reserv2	:22;	//	неиспользуется
} StructTIM15_CR1;

/*****************************************************************************************/

/***********************TIM15 2 регистр управления (TIM15_CR2)****************************/

typedef struct _StructTIM15_CR2	//	TIM15 2 регистр управления (TIM15_CR2)
{
	uint32_t CCPC		:1;		//	управление предзагрузкой захвата/сравнения
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t CCUS		:1;		//	управление выбором обновления захвата/сравнения
	uint32_t CCDS		:1;		//	выбор DMA захвата/сравнения
	uint32_t MMS		:3;		//	выбор основного режима
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t OIS1		:1;		//	выход в состоянии ожидания 1 (OC1 вывод)
	uint32_t OIS1N		:1;		//	выход в состоянии ожидания 1 (OC1N вывод)
	uint32_t OIS2		:1;		//	выход в состоянии ожидания 2 (OC2 вывод)
	uint32_t reserv3	:21;	//	неиспользуется
} StructTIM15_CR2;

/*****************************************************************************************/

/*****************TIM15 регистр управления ведомым режимом (TIM15_SMCR)*******************/

typedef struct _StructTIM15_SMCR	//	TIM15 регистр управления ведомым режимом (TIM15_SMCR)
{
	uint32_t SMS		:3;			//	выбор режима подчинённого/ведомого
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t TS			:3;			//	выбор триггера, изменять только когда SMS=000
	uint32_t MSM		:1;			//	режим основной или подчинённый/ведомый
	uint32_t reserv2	:24;		//	неиспользуется
} StructTIM15_SMCR;

/*****************************************************************************************/

/****************TIM15 регистр включения прерываний/DMA (TIM15_DIER)**********************/

typedef struct _StructTIM15_DIER	//	TIM15 регистр включения прерываний/DMA (TIM15_DIER)
{
	uint32_t UIE		:1;			//	включить прерывание при обновлении
	uint32_t CC1IE		:1;			//	включить прерывание захват/сравнение 1
	uint32_t CC2IE		:1;			//	включить прерывание захват/сравнение 2
	uint32_t reserv1	:2;			//	неиспользуется
	uint32_t COMIE		:1;			//	включить прервание COM
	uint32_t TIE		:1;			//	включить прервание триггера
	uint32_t BIE		:1;			//	включить прервание при обрыве
	uint32_t UDE		:1;			//	включить запрос DMA при обновлении
	uint32_t CC1DE		:1;			//	включить запрос DMA захват/сравнение 1
	uint32_t CC2DE		:1;			//	включить запрос DMA захват/сравнение 2
	uint32_t reserv2	:3;			//	неиспользуется
	uint32_t TDE		:1;			//	включить триггер запрос DMA
	uint32_t reserv3	:17;		//	неиспользуется
} StructTIM15_DIER;

/*****************************************************************************************/

/*************************TIM15 регистр состояния (TIM15_SR)******************************/

typedef struct _StructTIM15_SR	//	TIM15 регистр состояния (TIM15_SR)
{
	uint32_t UIF		:1;		//	флаг прерывания при обновлении
	uint32_t CC1IF		:1;		//	флаг прерывания захват/сравнение 1
	uint32_t CC2IF		:1;		//	флаг прерывания захват/сравнение 2
	uint32_t reserv1	:2;		//	неиспользуется
	uint32_t COMIF		:1;		//	COM флаг прерывания
	uint32_t TIF		:1;		//	флаг прерывания триггера
	uint32_t BIF		:1;		//	флаг прерывания обрыва
	uint32_t reserv2	:1;		//	неиспользуется
	uint32_t CC1OF		:1;		//	флаг переполнения захват/сравнение 1
	uint32_t CC2OF		:1;		//	флаг переполнения захват/сравнение 2
	uint32_t reserv3	:21;	//	неиспользуется
} StructTIM15_SR;

/*****************************************************************************************/

/*******************TIM15 регистр генерации событий (TIM15_EGR)***************************/

typedef struct _StructTIM15_EGR	//	TIM15 регистр генерации событий (TIM15_EGR)
{
	uint32_t UG			:1;		//	генерация обновления
	uint32_t CC1G		:1;		//	генерация захват/сравнение 1
	uint32_t CC2G		:1;		//	генерация захват/сравнение 2
	uint32_t reserv1	:2;		//	неиспользуется
	uint32_t COMG		:1;		//	захват/сравнение упраление генерацией обновления
	uint32_t TG			:1;		//	генерация триггера
	uint32_t BG			:1;		//	генерация разрыва
	uint32_t reserv2	:24;	//	неиспользуется
} StructTIM15_EGR;

/*****************************************************************************************/

/***************TIM15 регистр режима захват/сравнение 1 (TIM15_CCMR1)*********************/

#define	CC1S_OUT	(0b00)		//	CC1 выход
#define	CC1S_TI1	(0b01)		//	вход, IC1 сопоставлен с TI1.
#define	CC1S_TI2	(0b10)		//	вход, IC1 сопоставлен с TI2.
#define	CC1S_TRC	(0b11)		//	вход, IC1 сопоставлен с TRC. если установлен бит TS в регистре TIMx_SMCR

typedef struct _Struct1TIM15_CCMR1	//	TIM15 регистр режима захват/сравнение 1 (TIM15_CCMR1)
{
	uint32_t CC1S		:2;		//	выбор ввод/вывод захват/сравнение 1
	uint32_t IC1PSC		:2;		//	предделитель, 1 вход захвата
	uint32_t IC1F		:4;		//	фильтр, 1 вход захвата
	uint32_t CC2S		:2;		//	выбор ввод/вывод захват/сравнение 2
	uint32_t IC2PSC		:2;		//	предделитель, 2 вход захвата
	uint32_t IC2F		:4;		//	фильтр, 2 вход захвата
	uint32_t reserv		:16;	//	неиспользуется
} Struct1TIM15_CCMR1;

typedef struct _Struct2TIM15_CCMR1	//	TIM15 регистр режима захват/сравнение 1 (TIM15_CCMR1)
{
	uint32_t CC1S		:2;		//	выбор ввод/вывод захват/сравнение 1
	uint32_t OC1FE		:1;		//	быстрое сравнение вывод 1
	uint32_t OC1PE		:1;		//	буферизация вывод сравнения 1
	uint32_t OC1M		:3;		//	режим вывода сравнения 1
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t CC2S		:2;		//	выбор ввод/вывод захват/сравнение 2
	uint32_t OC2FE		:1;		//	быстрое сравнение вывод сравнения 2
	uint32_t OC2PE		:1;		//	буферизация вывод сравнения 2
	uint32_t OC2M		:3;		//	режим вывода сравнения 2
	uint32_t reserv2	:17;	//	неиспользуется
} Struct2TIM15_CCMR1;

typedef union _TIM15_CCMR1_BS			//	TIM15 регистр режима захват/сравнение 1 (TIM15_CCMR1)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile Struct1TIM15_CCMR1 BS1;	//	структура бит
	volatile Struct2TIM15_CCMR1 BS2;	//	структура бит
} UnionTIM15_CCMR1;

/*****************************************************************************************/

/****************TIM15 регистр включения захват/сравнения (TIM15_CCER)********************/

typedef struct _StructTIM15_CCER	//	TIM15 регистр включения захват/сравнения (TIM15_CCER)
{
	uint32_t CC1E		:1;			//	включить вывод захват/сравнение 1
	uint32_t CC1P		:1;			//	полярность вывода захват/сравнение 1
	uint32_t CC1NE		:1;			//	включить дополнительный вывод захват/сравнение 1
	uint32_t CC1NP		:1;			//	полярность дополнительного вывода захват/сравнение 1
	uint32_t CC2E		:1;			//	захват/сравнение 2 output enable
	uint32_t CC2P		:1;			//	захват/сравнение 2 output polarity
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t CC2NP		:1;			//	полярность на дополнительном выводе захват/сравнение 2
	uint32_t reserv2	:24;		//	неиспользуется
} StructTIM15_CCER;

/*****************************************************************************************/

/*****************************TIM15 счётчик (TIM15_CNT)***********************************/

typedef struct _StructTIM15_CNT		//	TIM15 счётчик (TIM15_CNT)
{
	uint32_t CNT		:16;		//	значение счётчика
	uint32_t reserv		:16;		//	неиспользуется
} StructTIM15_CNT;

/*****************************************************************************************/

/******************TIM15 регистр обрыва и времени простоя (TIM15_BDTR)********************/

typedef struct _StructTIM15_BDTR	//	TIM15 регистр обрыва и времени простоя (TIM15_BDTR)
{
	uint32_t DTG		:8;			//	установка генератора времени простоя
	uint32_t LOCK		:2;			//	блокировка конфигурации
	uint32_t OSSI		:1;			//	выбор выключенного состояния в режиме простоя
	uint32_t OSSR		:1;			//	выбор выключенного состояния в режиме выполнения
	uint32_t BKE		:1;			//	разрешить разрыв
	uint32_t BKP		:1;			//	полярность обрыва
	uint32_t AOE		:1;			//	включить автоматический вывод
	uint32_t MOE		:1;			//	включить основной вывод
	uint32_t reserv1	:16;		//	неиспользуется
} StructTIM15_BDTR;

/*****************************************************************************************/

/***********************TIM15 регистр управления DMA (TIM15_DCR)**************************/

typedef struct _StructTIM15_DCR		//	TIM15 регистр управления DMA (TIM15_DCR)
{
	uint32_t DBA		:5;			//	базовый адрес DMA
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t DBL		:5;			//	длина пакета DMA
	uint32_t reserv2	:19;		//	неиспользуется
}StructTIM15_DCR;

/*****************************************************************************************/

/******************TIM15 DMA адрес для полной передачи (TIM15_DMAR)***********************/

typedef struct _StructTIM15_DMAR	//	TIM15 DMA адрес для полной передачи (TIM15_DMAR)
{
	uint32_t DMAB		:16;		//	доступ к данным при пакетной передаче DMA
	uint32_t reserv1	:16;		//	неиспользуется
} StructTIM15_DMAR;

/*****************************************************************************************/

/*****************************************************************************************/

typedef struct _StructTIM15					//	структура регистров таймера 15
{
	volatile StructTIM15_CR1	CR1;		//	первый регистр управления (TIM15_CR1)
	volatile StructTIM15_CR2	CR2;		//	второй регистр управления (TIM15_CR2)
	volatile StructTIM15_SMCR	SMCR;		//	регистр управления ведомым режимом (TIM15_SMCR)
	volatile StructTIM15_DIER	DIER;		//	регистр включения прерываний/DMA (TIM15_DIER)
	volatile StructTIM15_SR		SR;			//	регистр статуса (TIM15_SR)
	volatile StructTIM15_EGR	EGR;		//	регистр генерации событий (TIM15_EGR)
	volatile UnionTIM15_CCMR1	CMR1;		//	первый регистр режима захват/сравнение (TIM15_CCMR1)
	volatile const uint32_t		RESERV0;	//	зарезервировано
	volatile StructTIM15_CCER	CCER;		//	регистр включения захвт/сравнение (TIM15_CCER)
	volatile uint16_t			CNT;		//	счетчик (TIM15_CNT)
	volatile const uint16_t		RESERV1;	//	зарезервировано
	volatile uint16_t			PSC;		//	предделитель (TIM15_PSC)
	volatile const uint16_t		RESERV2;	//	зарезервировано
	volatile uint16_t			ARR;		//	регистр автоперезагрузки (TIM15_ARR)
	volatile const uint16_t		RESERV3;	//	зарезервировано
	volatile uint16_t			RCR;		//	регистр счетчика повторений (TIM15_RCR)
	volatile const uint16_t		RESERV4;	//	зарезервировано
	volatile uint16_t			CCR1;		//	первый регистр захват/сравнение (TIM15_CCR1)
	volatile const uint16_t		RESERV5;	//	зарезервировано
	volatile uint16_t			CCR2;		//	второй регистр захват/сравнение (TIM15_CCR2)
	volatile const uint16_t		RESERV6;	//	зарезервировано
	volatile const uint32_t		RESERV7;	//	зарезервировано
	volatile const uint32_t		RESERV8;	//	зарезервировано
	volatile StructTIM15_BDTR	BDTR;		//	регистр паузы и простоя (TIM15_BDTR)
	volatile StructTIM15_DCR	DCR;		//	регистр управления DMA (TIM15_DCR)
	volatile StructTIM15_DMAR	DMAR;		//	базовый адрес DMA (TIM15_DMAR)
}StructTIM15;

#define	_TIM15	((StructTIM15 *) 0x40014000)

/**************************************TIM15 END******************************************/

/***********************TIM1617 1 регистр управления (TIM1617_CR1)************************/

typedef struct _StructTIM1617_CR1	//	TIM1617 1 регистр управления (TIM1617_CR1)
{
	uint32_t CEN		:1;			//	включить счётчик
	uint32_t UDIS		:1;			//	отключить обновление
	uint32_t URS		:1;			//	запрос обновления источника
	uint32_t OPM		:1;			//	одноимпульсный режим
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t ARPE		:1;			//	включить автоперезагрузку
	uint32_t CKD		:2;			//	делитель тактов
	uint32_t reserv2	:22;		//	неиспользуется
} StructTIM1617_CR1;

/*****************************************************************************************/

/***********************TIM1617 2 регистр управления (TIM1617_CR2)************************/

typedef struct _StructTIM1617_CR2	//	TIM1617 2 регистр управления (TIM1617_CR2)
{
	uint32_t CCPC		:1;			//	управление предзагрузкой захвата/сравнения
	uint32_t reserv1	:1;			//	неиспользуется
	uint32_t CCUS		:1;			//	управление выбором обновления захвата/сравнения
	uint32_t CCDS		:1;			//	выбор DMA захвата/сравнения
	uint32_t reserv2	:4;			//	неиспользуется
	uint32_t OIS1		:1;			//	выход в состоянии ожидания 1 (OC1 вывод)
	uint32_t OIS1N		:1;			//	выход в состоянии ожидания 1 (OC1N вывод)
	uint32_t reserv3	:22;		//	неиспользуется
} StructTIM1617_CR2;

/*****************************************************************************************/

/****************TIM1617 регистр включения прерываний/DMA (TIM1617_DIER)******************/

typedef struct _StructTIM1617_DIER	//	TIM1617 регистр включения прерываний/DMA (TIM1617_DIER)
{
	uint32_t UIE		:1;			//	включить прерывание при обновлении
	uint32_t CC1IE		:1;			//	включить прерывание захват/сравнение 1
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t COMIE		:1;			//	включить прервание COM
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t BIE		:1;			//	включить прервание при обрыве
	uint32_t UDE		:1;			//	включить запрос DMA при обновлении
	uint32_t OC1DE		:1;			//	включить запрос DMA захват/сравнение 1
	uint32_t reserv3	:22;		//	неиспользуется
} StructTIM1617_DIER;

/*****************************************************************************************/

/*************************TIM1617 регистр состояния (TIM1617_SR)**************************/

typedef struct _StructTIM1617_SR	//	TIM1617 регистр состояния (TIM1617_SR)
{
	uint32_t UIF		:1;			//	флаг прерывания при обновлении
	uint32_t CC1IF		:1;			//	флаг прерывания захват/сравнение 1
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t COMIF		:1;			//	COM флаг прерывания
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t BIF		:1;			//	флаг прерывания обрыва
	uint32_t reserv3	:1;			//	неиспользуется
	uint32_t CC1OF		:1;			//	флаг переполнения захват/сравнение 1
	uint32_t reserv4	:22;		//	неиспользуется
} StructTIM1617_SR;

/*****************************************************************************************/

/*******************TIM1617 регистр генерации событий (TIM1617_EGR)***********************/

typedef struct _StructTIM1617_EGR	//	TIM1617 регистр генерации событий (TIM1617_EGR)
{
	uint32_t UG			:1;			//	генерация обновления
	uint32_t CC1G		:1;			//	генерация захват/сравнение 1
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t COMG		:1;			//	захват/сравнение упраление генерацией обновления
	uint32_t reserv2	:1;			//	неиспользуется
	uint32_t BG			:1;			//	генерация разрыва
	uint32_t reserv3	:24;		//	неиспользуется
} StructTIM1617_EGR;

/*****************************************************************************************/

/***************TIM1617 регистр режима захват/сравнение 1 (TIM1617_CCMR1)*****************/

typedef struct _Struct1TIM1617_CCMR1	//	TIM1617 регистр режима захват/сравнение 1 (TIM1617_CCMR1)
{
	uint32_t CC1S		:2;				//	выбор ввод/вывод захват/сравнение 1
	uint32_t IC1PSC		:2;				//	предделитель, 1 вход захвата
	uint32_t IC1F		:4;				//	фильтр, 1 вход захвата
	uint32_t reserv		:24;			//	неиспользуется
} Struct1TIM1617_CCMR1;

typedef struct _Struct2TIM1617_CCMR1	//	TIM1617 регистр режима захват/сравнение 1 (TIM1617_CCMR1)
{
	uint32_t CC1S		:2;				//	выбор ввод/вывод захват/сравнение 1
	uint32_t OC1FE		:1;				//	быстрое сравнение вывод 1
	uint32_t OC1PE		:1;				//	буферизация вывод сравнения 1
	uint32_t OC1M		:3;				//	выбор режима захват/сравнение
	uint32_t reserv		:25;			//	неиспользуется
} Struct2TIM1617_CCMR1;

typedef union _TIM1617_CCMR1_BS			//	TIM1617 регистр режима захват/сравнение 1 (TIM1617_CCMR1)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile Struct1TIM1617_CCMR1 BS1;	//	структура бит
	volatile Struct2TIM1617_CCMR1 BS2;	//	структура бит
} UnionTIM1617_CCMR1;

/*****************************************************************************************/

/****************TIM1617 регистр включения захват/сравнения (TIM1617_CCER)****************/

typedef struct _StructTIM1617_CCER		//	TIM1617 регистр включения захват/сравнения (TIM1617_CCER)
{
	uint32_t CC1E		:1;				//	включить вывод захват/сравнение 1
	uint32_t CC1P		:1;				//	полярность вывода захват/сравнение 1
	uint32_t CC1NE		:1;				//	включить дополнительный вывод захват/сравнение 1
	uint32_t CC1NP		:1;				//	полярность дополнительного вывода захват/сравнение 1
	uint32_t reserv		:28;			//	неиспользуется
} StructTIM1617_CCER;

/*****************************************************************************************/

/*****************************TIM1617 счётчик (TIM1617_CNT)*******************************/

typedef struct _StructTIM1617_CNT	//	TIM1617 счётчик (TIM1617_CNT)
{
	uint32_t VAL		:16;		//	значение счётчика
	uint32_t reserv		:16;		//	неиспользуется
} StructTIM1617_CNT;

/*****************************************************************************************/

/******************TIM1617 регистр обрыва и времени простоя (TIM1617_BDTR)****************/

typedef struct _StructTIM1617_BDTR	//	TIM1617 регистр обрыва и времени простоя (TIM1617_BDTR)
{
	uint32_t DTG		:8;			//	установка генератора времени простоя
	uint32_t LOCK		:2;			//	блокировка конфигурации
	uint32_t OSSI		:1;			//	выбор выключенного состояния в режиме простоя
	uint32_t OSSR		:1;			//	выбор выключенного состояния в режиме выполнения
	uint32_t BKE		:1;			//	разрешить разрыв
	uint32_t BKP		:1;			//	полярность сигнала разрыва
	uint32_t AOE		:1;			//	включить автоматический вывод
	uint32_t MOE		:1;			//	включить основной вывод
	uint32_t reserv		:16;		//	неиспользуется
} StructTIM1617_BDTR;

/*****************************************************************************************/

/***********************TIM1617 регистр управления DMA (TIM1617_DCR)**********************/

typedef struct _StructTIM1617_DCR	//	TIM1617 регистр управления DMA (TIM1617_DCR)
{
	uint32_t DBA		:5;			//	базовый адрес DMA
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t DBL		:5;			//	длина пакета DMA
	uint32_t reserv2	:19;		//	неиспользуется
} StructTIM1617_DCR;

/*****************************************************************************************/

/*****************************************************************************************/

typedef struct _StructTIM1617					//	структура регистров таймеров 16 и 17
{
	volatile StructTIM1617_CR1		CR1;		//	первый регистр управления (TIM_CR1)
	volatile StructTIM1617_CR2		CR2;		//	второй регистр управления (TIM_CR2)
	volatile const uint32_t			RESERV0;	//	зарезервировано
	volatile StructTIM1617_DIER		DIER;		//	регистр включения прерываний/DMA (TIM_DIER)
	volatile StructTIM1617_SR		SR;			//	регистр статуса (TIM_SR)
	volatile StructTIM1617_EGR		EGR;		//	регистр генерации событий (TIM_EGR)
	volatile UnionTIM1617_CCMR1		CMR1;		//	первый регистр режима захват/сравнение (TIM_CCMR1)
	volatile const uint32_t			RESERV1;	//	зарезервировано
	volatile StructTIM1617_CCER		CCER;		//	регистр включения захвт/сравнение (TIM_CCER)
	volatile uint16_t				CNT;		//	счетчик (TIM_CNT)
	volatile const uint16_t			RESERV2;	//	зарезервировано
	volatile uint16_t				PSC;		//	предделитель (TIM_PSC)
	volatile const uint16_t			RESERV3;	//	зарезервировано
	volatile uint16_t				ARR;		//	регистр автоперезагрузки (TIM_ARR)
	volatile const uint16_t			RESERV4;	//	зарезервировано
	volatile uint16_t				RCR;		//	регистр счетчика повторений (TIM_RCR)
	volatile const uint16_t			RESERV5;	//	зарезервировано
	volatile uint16_t				CCR1;		//	первый регистр захват/сравнение (TIM_CCR1)
	volatile const uint16_t			RESERV6;	//	зарезервировано
	volatile const uint32_t			RESERV[3];	//	зарезервировано
	volatile StructTIM1617_BDTR		BDTR;		//	регистр паузы и простоя (TIM_BDTR)
	volatile StructTIM1617_DCR		DCR;		//	регистр управления DMA (TIM_DCR)
	volatile uint32_t				DMAR;		//	базовый адрес DMA (TIM_DMAR)
} const StructTIM1617;

#define	_TIM16	((StructTIM1617 *) 0x40012c00)
#define	_TIM17	((StructTIM1617 *) 0x40014800)

/**************************************TIM1617 END****************************************/

/********************TIM6/TIM7 1 регистр управления (TIMx_CR1)****************************/

typedef struct _StructTIM_6_7_CR1	//	TIM6/TIM7 1 регистр управления (TIMx_CR1)
{
	uint32_t CEN		:1;			//	включить счетчик
	uint32_t UDIS		:1;			//	отключить обновление
	uint32_t URS		:1;			//	источник запроса обновления
	uint32_t OPM		:1;			//	одноимпульсный режим
	uint32_t reserv1	:3;			//	неиспользуется
	uint32_t ARPE		:1;			//	включить предзагрузку автозагрузки
	uint32_t reserv2	:8;			//	неиспользуется
} StructTIM_6_7_CR1;

/*****************************************************************************************/

/********************TIM6/TIM7 2 регистр управления (TIMx_CR2)****************************/

typedef struct _StructTIM_6_7_CR2	//	TIM6/TIM7 2 регистр управления (TIMx_CR2)
{
	uint32_t reserv1	:4;			//	неиспользуется
	uint32_t MMS		:3;			//	выбор основного режима
	uint32_t reserv2	:9;			//	неиспользуется
} StructTIM_6_7_CR2;

/*****************************************************************************************/

/**************TIM6/TIM7 регистр включения прерываний/DMA (TIMx_DIER)*********************/

typedef struct _StructTIM_6_7_DIER	//	TIM6/TIM7 регистр включения прерываний/DMA (TIMx_DIER)
{
	uint32_t UIE		:1;			//	включить прерывание при обновлении
	uint32_t reserv1	:7;			//	неиспользуется
	uint32_t UDE		:1;			//	включить запрос DMA при обновлении
	uint32_t reserv2	:7;			//	неиспользуется
} StructTIM_6_7_DIER;

/*****************************************************************************************/

/**********************TIM6/TIM7 регистр состояния (TIMx_SR)******************************/

typedef struct _StructTIM_6_7_SR	//	TIM6/TIM7 регистр состояния (TIMx_SR)
{
	uint32_t UIF		:1;			//	флаг прерывания при обновлении
	uint32_t reserv		:15;		//	неиспользуется
} StructTIM_6_7_SR;

/*****************************************************************************************/

/****************TIM6/TIM7 регистр генерации событий (TIMx_EGR)***************************/

typedef struct _StructTIM_6_7_EGR	//	TIM6/TIM7 регистр генерации событий (TIMx_EGR)
{
	uint32_t UG			:1;			//	генерация обновления
	uint32_t reserv		:15;		//	неиспользуется
} StructTIM_6_7_EGR;

/*****************************************************************************************/

/*****************************************************************************************/

typedef struct _StructTIM67
{
	volatile StructTIM_6_7_CR1		CR1;		//	первый регистр управления (TIM6/TIM7_CR1)
	volatile StructTIM_6_7_CR2		CR2;		//	второй регистр управления (TIM6/TIM7_CR2)
	volatile const uint32_t			RESERV0;	//	зарезервировано
	volatile StructTIM_6_7_DIER		DIER;		//	регистр включения прерываний/DMA (TIM6/TIM7_DIER)
	volatile StructTIM_6_7_SR		SR;			//	регистр статуса (TIM6/TIM7_SR)
	volatile StructTIM_6_7_EGR		EGR;		//	регистр генерации событий (TIM6/TIM7_EGR)
	volatile const uint32_t			RESERV[3];	//	зарезервировано
	volatile uint16_t				CNT;		//	счетчик (TIM6/TIM7_CNT)
	volatile const uint16_t			RESERV1;	//	зарезервировано
	volatile uint16_t				PSC;		//	предделитель (TIM6/TIM7_PSC)
	volatile const uint16_t			RESERV2;	//	зарезервировано
	volatile uint16_t				ARR;		//	регистр автоперезагрузки (TIM6/TIM7_ARR)
	volatile const uint16_t			RESERV3;	//	зарезервировано
} const StructTIM67;

#define	_TIM6	((StructTIM67 *) 0x40001000)
#define	_TIM7	((StructTIM67 *) 0x40001400)

/**************************************TIM6/TIM7 END**************************************/

#endif /* BSH_TIM_H_ */



























