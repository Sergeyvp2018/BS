/*
 * HDMI_CEC.h
 *
 *  Created on: 5 дек. 2020 г.
 *      Author: sergey
 */

#ifndef BSH_HDMI_CEC_H_
#define BSH_HDMI_CEC_H_

#include "BS.h"

/*******************************CEC control register (CEC_CR)**********************************************/

typedef struct _StructCEC_CR		//	регистр управления (CEC_CR)
{
	uint32_t CECEN		:1;			//	включить CEC
	uint32_t TXSOM		:1;			//	начало сообщения
	uint32_t TXEOM		:1;			//	конец сообщения
	uint32_t reserv		:29;		//	неиспользуется
} StructCEC_CR;

/**********************************************************************************************************/

/*******************************CEC configuration register (CEC_CFGR)**************************************/

typedef struct _StructCEC_CFGR		//	регистр конфигурации (CEC_CFGR)
{
	uint32_t SFT		:3;			//	свободное время сигнала
	uint32_t RXTOL		:1;			//	запас допуска
	uint32_t BRESTP		:1;			//	Rx-Stop при ошибке нарастающего фронта
	uint32_t BREGEN		:1;			//	бит ошибки при ошибке нарастающего фронта
	uint32_t LBPEGEN	:1;			//	бит ошибки при удленённом периоде
	uint32_t BRDNOGEN	:1;			//	отменить бит ошибки при широком вещании
	uint32_t SFTOP		:1;			//	опциональный бит
	uint32_t reserv		:7;			//	неиспользуется
	uint32_t OAR		:1;			//	собственный адрес конфигурации
	uint32_t LSTN		:1;			//	режим прослушивания
} StructCEC_CFGR;

/**********************************************************************************************************/

/*******************************CEC Tx data register (CEC_TXDR)********************************************/

typedef struct _StructCEC_TXDR		//	регистр данных передачи (CEC_TXDR)
{
	uint32_t TXD		:1;			//	данные передачи
	uint32_t reserv		:24;		//	неиспользуется
} StructCEC_TXDR;

/**********************************************************************************************************/

/*******************************CEC Rx Data Register (CEC_RXDR)********************************************/

typedef struct _StructCEC_RXDR		//	регистр данных приёма (CEC_RXDR)
{
	uint32_t RXD		:1;			//	данные приёма
	uint32_t reserv		:24;		//	неиспользуется
} StructCEC_RXDR;

/**********************************************************************************************************/

/*******************************CEC Interrupt and Status Register (CEC_ISR)********************************/

typedef struct _StructCEC_ISR		//	регистр прерываний и статуса (CEC_ISR)
{
	uint32_t RXBR		:1;			//	получен Rx-Byte
	uint32_t RXEND		:1;			//	конец приёма
	uint32_t RXOVR		:1;			//	переполнение при приёме
	uint32_t BRE		:1;			//	ошибка Rx-Bit
	uint32_t SBPE		:1;			//	ошибка короткого периода
	uint32_t LBPE		:1;			//	ошибка длинного периода
	uint32_t RXACKE		:1;			//	нет подтверждения на линии
	uint32_t ARBLST		:1;			//	арбитраж не пройден
	uint32_t TXBR		:1;			//	запрос отправления
	uint32_t TXEND		:1;			//	конец передачи
	uint32_t TXUDR		:1;			//	не загружен TXDR до передача следующего байта
	uint32_t TXERR		:1;			//	ошибка передачи
	uint32_t TXACKE		:1;			//	нет подтверждения
	uint32_t reserv		:19;		//	неиспользуется
} StructCEC_ISR;

/**********************************************************************************************************/

/*******************************CEC interrupt enable register (CEC_IER)************************************/

typedef struct _StructCEC_IER		//	регистр включения прерываний (CEC_IER)
{
	uint32_t RXBRIE		:1;			//
	uint32_t RXENDIE	:1;			//
	uint32_t RXOVRIE	:1;			//
	uint32_t BREIE		:1;			//
	uint32_t SBPEIE		:1;			//
	uint32_t LBPEIE		:1;			//
	uint32_t RXACKIE	:1;			//
	uint32_t ARBLSTIE	:1;			//
	uint32_t TXBRIE		:1;			//
	uint32_t TXENDIE	:1;			//
	uint32_t TXUDRIE	:1;			//
	uint32_t TXERRIE	:1;			//
	uint32_t TXACKIE	:1;			//
	uint32_t reserv1	:19;		//	неиспользуется
} StructCEC_IER;

/**********************************************************************************************************/

/**********************************************************************************************************/

typedef struct _StructHDMI_CEC
{
	volatile StructCEC_CR		CR;			//	регистр управления (CEC_CR)
	volatile StructCEC_CFGR		CFGR;		//	регистр конфигурации (CEC_CFGR)
	volatile StructCEC_TXDR		TXDR;		//	регистр данных (CEC_TXDR)
	volatile StructCEC_RXDR		RXDR;		//	регистр данных приёма (CEC_RXDR)
	volatile StructCEC_ISR		ISR;		//	регистр прерываний и статуса (CEC_ISR)
	volatile StructCEC_IER		IER;		//	регистр включения прерываний (CEC_IER)
}StructHDMI_CEC;

#define	_HDMI_CEC	((StructHDMI_CEC *) 0x40007800)

/**********************************************************************************************************/

#endif /* BSH_HDMI_CEC_H_ */























