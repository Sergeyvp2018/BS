/*
 * CAN.h
 *
 *  Created on: 15 окт. 2020 г.
 *      Author: sergeyvp@gmail.com
 */

#ifndef BSH_CAN_H_
#define BSH_CAN_H_

#include "BS.h"

/********************************************************************************************************
Basic Extended CAN, сокращённо bxCAN, обеспечивает интерфейс сети CAN.
Поддерживаются протоколы CAN версии 2.0A и B. Позволяет обрабатывать максимальное количество входящих
сообщений с минимальной загрузкой CPU. Реализован приоритет передаваемых сообщений.
Для приложений критичных к безопасности, контроллер CAN обеспечивает все аппаратные функции для
поддержки опций CAN Time Triggered Communication.

Основные возможности bxCAN:
• поддержка протоколов CAN версии 2.0 A, B Active
• скорость передачи до 1 Mbit/s
• поддержка опций Time Triggered Communication Transmission
• три почовых ящика для передачи сообщений
• конфигурируемый приоритет передачи сообщений
• отметка времени при приеме передачи SOF
• два трёхступенчатых FIFOs принимающих сообщения
• расширяемый банк фильтров:
  – 14 банков фильтров
• возможны списки идентификаторов
• конфигурируемое переполнение FIFO
• отметка времени приёма в SOF
Опции Time Triggered Communication:
• отключить режим автоматической повторной отправки
• 16-битный таймер
• отметка времени отправления в последних двух байтах
Управление:
• маскируемые прерывания
• программно-эффективное отображение почтовых ящиков в уникальном адресном пространстве
********************************************************************************************************/

void _CAN_ini( void);
void _CAN_rx( void);
void _CAN_tx( void);

/******************************CAN master control register (CAN_MCR)************************************/

typedef struct _StructCAN_MCR	// CAN master control register (CAN_MCR)
{
	uint32_t INRQ	:1;		// флаг запроса инициализации
	uint32_t SLEEP	:1;		// спящий режим
	uint32_t TXFP	:1;		// приоритет передачи хронологический
	uint32_t RFLM	:1;		// блокировка FIFO при заполнении
	uint32_t NART	:1;		// отключить автоматическую повторную пересылку
	uint32_t AWUM	:1;		// автоматическое пробуждение при поступлении сообщения
	uint32_t ABOM	:1;		// автоматическое управление режимом bus-off
	uint32_t TTCM	:1;		// Связь по времени
	uint32_t reserv1:7;		// неиспользуется
	uint32_t RESET	:1;		// сброс
	uint32_t DBF	:1;		// работа при отладке
	uint32_t reserv2:15;	// неиспользуется
} StructCAN_MCR;

/*******************************************************************************************************/

/******************************CAN master status register (CAN_MSR)*************************************/

typedef struct _StructCAN_MSR	// CAN master status register (CAN_MSR)
{
	uint32_t INAK	:1;		//	флаг режима инициализации
	uint32_t SLAK	:1;		//	флаг спящего режима
	uint32_t ERRI	:1;		//	флаг прерывания при ошибке
	uint32_t WKUI	:1;		//	флаг выхода из спящего режима
	uint32_t SLAKI	:1;		//	флаг спящего режима
	uint32_t reserv1:3;		//	неиспользуется
	uint32_t TXM	:1;		//	режим передачи
	uint32_t RXM	:1;		//	режим приёма
	uint32_t SAMP	:1;		//	текущее значение полученного бита
	uint32_t RX		:1;		//	текущий сигнал RX на пине
	uint32_t reserv2:20;	//	неиспользуется
} StructCAN_MSR;

/*******************************************************************************************************/

/*****************************CAN transmit status register (CAN_TSR)************************************/

typedef struct _StructCAN_TSR	// CAN transmit status register (CAN_TSR)
{
	uint32_t RQCP0	:1;		//	устанавливается аппаратно когда последний запрос выполнен (передача или прекращение)
	uint32_t TXOK0	:1;		//	1: предыдущие отправление выполнено, 0: предыдущее отправление невыполнено
	uint32_t ALST0	:1;		//	предыдущее отправление не прошло арбитраж
	uint32_t TERR0	:1;		//	ошибка передачи почтовый ящик 0
	uint32_t reserv1:3;		//	неиспользуется
	uint32_t ABRQ0	:1;		//	запрос отменён для почтового ящика 0
	uint32_t RQCP1	:1;		//	запрос выполнен в почтовом ящике 1
	uint32_t TXOK1	:1;		//	передача выполнена в почтовом ящике 1
	uint32_t ALST1	:1;		//	арбитраж не пройден в почтовом ящике 1
	uint32_t TERR1	:1;		//	ошибка передачи почтовый ящик 1
	uint32_t reserv2:3;		//	неиспользуется
	uint32_t ABRQ1	:1;		//	запрос отменён в почтовом ящике 1
	uint32_t RQCP2	:1;		//	запрос выполнен в почтовом ящике 2
	uint32_t TXOK2	:1;		//	передача выполнена в почтовом ящике 2
	uint32_t ALST2	:1;		//	арбитраж не пройден в почтовом ящике 2
	uint32_t TERR2	:1;		//	ошибка передачи почтовый ящик 2
	uint32_t reserv3:3;		//	неиспользуется
	uint32_t ABRQ2	:1;		//	запрос отменён в почтовом ящике 2
	uint32_t CODE	:2;		//	двухбитный код почтового ящика
	uint32_t TME0	:1;		//	0 почтовый ящик пуст
	uint32_t TME1	:1;		//	1 почтовый ящик пуст
	uint32_t TME2	:1;		//	2 почтовый ящик пуст
	uint32_t LOW0	:1;		//	самый низкий приоритет для почтового ящика 0
	uint32_t LOW1	:1;		//	самый низкий приоритет для почтового ящика 1
	uint32_t LOW2	:1;		//	самый низкий приоритет для почтового ящика 2
} StructCAN_TSR;

/*******************************************************************************************************/

/****************************CAN receive FIFO 0 register (CAN_RF0R)*************************************/

typedef struct _StructCAN_RF0R	// CAN receive FIFO 0 register (CAN_RF0R)
{
	uint32_t FMP0	:2;		//	[1:0] : счетчик ожидающих сообщений FIFO 0
	uint32_t reserv1:1;		//	неиспользуется
	uint32_t FULL0	:1;		//	флаг заполнения FIFO 0 ful
	uint32_t FOVR0	:1;		//	флаг переполнения FIFO 0 overrun
	uint32_t RFOM0	:1;		//	флаг для освобождения почтового ящика Release FIFO 0 output mailbox
	uint32_t reserv2:26;	//	неиспользуется
} StructCAN_RF0R;

/*******************************************************************************************************/

/****************************CAN receive FIFO 1 register (CAN_RF1R)*************************************/

typedef struct _StructCAN_RF1R	// CAN receive FIFO 1 register (CAN_RF1R)
{
	uint32_t FMP1	:2;		//	[1:0] : счетчик ожидающих сообщений FIFO 1
	uint32_t reserv1:1;		//	неиспользуется
	uint32_t FULL1	:1;		//	флаг заполнения FIFO 1
	uint32_t FOVR1	:1;		//	флаг переполнения FIFO 1
	uint32_t RFOM1	:1;		//	флаг для освобождения почтового ящика Release FIFO 1 output mailbox
	uint32_t reserv2:26;	//	неиспользуется
} StructCAN_RF1R;

/*******************************************************************************************************/

/****************************CAN interrupt enable register (CAN_IER)************************************/

typedef struct _StructCAN_IER	// CAN interrupt enable register (CAN_IER)
{
	uint32_t TMEIE	:1;		// прерывание при опустошении почтового ящика, когда установлен RQCPx бит
	uint32_t FMPIE0	:1;		// прерывание генерируется когда состояние FMP[1:0] бит не 00b.
	uint32_t FFIE0	:1;		// прерывание при заполнении FIFO 0, происходит при установке FULL
	uint32_t FOVIE0	:1;		// прерывание при переполнении FIFO 0, происходит при установке FOVR
	uint32_t FMPIE1	:1;		// прерывание генерируется когда состояние FMP[1:0] бит не 00b.
	uint32_t FFIE1	:1;		// прерывание при заполнении FIFO 1, происходит при установке FULL
	uint32_t FOVIE1	:1;		// прерывание при переполнении FIFO 1, происходит при установке FOVR
	uint32_t reserv1:1;		// неиспользуется
	uint32_t EWGIE	:1;		// прерывание при сообщении об ошибке
	uint32_t EPVIE	:1;		// пассивное прерывание при ошибке
	uint32_t BOFIE	:1;		// прерывание при отключении шины
	uint32_t LECIE	:1;		// прерывание при установки кода ошибки
	uint32_t reserv2:3;		// неиспользуется
	uint32_t ERRIE	:1;		// прерывание при ошибке
	uint32_t WKUIE	:1;		// прерывание при выходе из спящего режима
	uint32_t SLKIE	:1;		// прерывание при переходе в спящий режим
	uint32_t reserv3:14;	// неиспользуется
} StructCAN_IER;

/*******************************************************************************************************/

/*******************************CAN error status register (CAN_ESR)*************************************/

#define	LEC_NO_ERR		(0b000)	//	нет ошибок No Error
#define	LEC_STUFF_ERR	(0b001)	//	ошибка заполнения Stuff Error
#define	LEC_FORM_ERR	(0b010)	//	ошибка формы Form Error
#define	LEC_ACK_ERR	(0b011)	//	ошибка подтверждения Acknowledgment Error
#define	LEC_BRX_ERR	(0b100) //	битовая рецессивная ошибка Bit recessive Error
#define	LEC_BDMNT_ERR	(0b101) //	битовая доминантная ошибка Bit dominant Error
#define	LEC_CRC_ERR	(0b110) //	ошибка CRC Error
#define	LEC_SOFT_ERR	(0b111) //	ошибка установлена программно Set by software

typedef struct _StructCAN_ESR	// CAN error status register (CAN_ESR)
{
	uint32_t EWGF		:1;		//	флаг предупреждения об ошибке Error warning flag
	uint32_t EPVF		:1;		//	пассивный флаг ошибки Error passive flag
	uint32_t BOFF		:1;		//	флаг выключенной шины Bus-off flag
	uint32_t reserv1	:1;		//	неиспользуется
	uint32_t LEC		:3;		//	код последней ошибки Last error code
	uint32_t reserv2	:9;		//	неиспользуется
	uint32_t TEC		:8;		//	младший байт 9-ти битного счётчика ошибок передачи Least significant byte of the 9-bit transmit error counter
	uint32_t REC		:8;		//	счётчик ошибок приёма Receive error counter
} StructCAN_ESR;

/*******************************************************************************************************/

/**********************************CAN bit timing register (CAN_BTR)************************************/

typedef struct _StructCAN_BTR	// CAN bit timing register (CAN_BTR)
{
	uint32_t BRP	:10;	//	предделитель скорости передачи
	uint32_t reserv1:6;		//	неиспользуется
	uint32_t TS1	:4;		//	1 сегмент времени
	uint32_t TS2	:3;		//	2 сегмент времени
	uint32_t reserv2:1;		//	неиспользуется
	uint32_t SJW	:2;		//	ширина шага пересинхронизации
	uint32_t reserv3:4;		//	неиспользуется
	uint32_t LBKM	:1;		//	режим замкнутой петли
	uint32_t SILM	:1;		//	тихий режим, данные в шину не передаются
} StructCAN_BTR;

/*******************************************************************************************************/

/***********************CAN TX mailbox identifier register (CAN_TIxR) (x = 0..2)************************/

#define	IDE_EXT_ID	1
#define	IDE_STD_ID	0

typedef struct _StructCAN_TIR	// CAN TX mailbox identifier register (CAN_TIxR)
{
	uint32_t TXRQ	:1;		//	запрос отправления из почтового ящика
	uint32_t RTR	:1;		//	запрос удалённой передачи
	uint32_t IDE	:1;		//	тип идентификатора
	uint32_t EXID	:18;	//	расширенный идентификатор
	uint32_t STID	:11;	//	стандартный или расширенный идентификатор
} StructCAN_TIR;

typedef struct _StructCAN_TIR_EX	// CAN TX mailbox identifier register (CAN_TIxR)
{
	uint32_t TXRQ	:1;		//	запрос отправления из почтового ящика
	uint32_t RTR	:1;		//	запрос удалённой передачи
	uint32_t IDE	:1;		//	тип идентификатора
	uint32_t EXID	:29;	//	расширенный идентификатор
} StructCAN_TIR_EX;

typedef union _CAN_TIR			// CAN TX mailbox identifier register (CAN_TIxR)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile StructCAN_TIR STID;		//	структура бит
	volatile StructCAN_TIR_EX EXID;	//	структура бит расширенного идентификатора
} UnionCAN_TIR;

/*******************************************************************************************************/

/***CAN mailbox data length control and time stamp register (CAN_TDTxR) (x = 0..2)***/

typedef struct _StructCAN_TDTR	// CAN регистр управления длиной данных и шаблоном времени
{
	uint32_t DLC		:4;		//	длина данных кода
	uint32_t reserv1	:4;		//	неиспользуется
	uint32_t TGT		:1;		//	отправить глобальное время
	uint32_t reserv2	:7;		//	неиспользуется
	uint32_t TIME		:16;	//	отметка времени сообщения
} StructCAN_TDTR;

/*******************************************************************************************************/

/************************CAN mailbox data low register (CAN_TDLxR) (x = 0..2)***************************/

typedef struct _StructCAN_TDLR	// CAN mailbox data low register (CAN_TDLxR)
{
	uint32_t DATA0		:8;		//	байт данных 0
	uint32_t DATA1		:8;		//	байт данных 1
	uint32_t DATA2		:8;		//	байт данных 2
	uint32_t DATA3		:8;		//	байт данных 3
} StructCAN_TDLR;

/*******************************************************************************************************/

/************************CAN mailbox data high register (CAN_TDHxR) (x = 0..2)**************************/

typedef struct _StructCAN_TDHR	// CAN mailbox data low register (CAN_TDHxR)
{
	uint32_t DATA4		:8;		//	байт данных 4
	uint32_t DATA5		:8;		//	байт данных 5
	uint32_t DATA6		:8;		//	байт данных 6
	uint32_t DATA7		:8;		//	байт данных 7
} StructCAN_TDHR;

/*******************************************************************************************************/

/*******************CAN receive FIFO mailbox identifier register (CAN_RIxR) (x = 0..1)******************/

typedef struct _StructCAN_RIR	// CAN receive FIFO mailbox identifier register (CAN_RIxR)
{
	uint32_t reserv	:1;		//	неиспользуется
	uint32_t RTR	:1;		//	запрос удалённой передачи
	uint32_t IDE	:1;		//	тип идентификатора
	uint32_t EXID	:18;	//	расширенный идентификатор
	uint32_t STID	:11;	//	стандартный идентификатор или часть расширенного
} StructCAN_RIR;

typedef struct _StructCAN_RIR_EX	// CAN receive FIFO mailbox identifier register (CAN_RIxR)
{
	uint32_t reserv	:1;		//	неиспользуется
	uint32_t RTR	:1;		//	запрос удалённой передачи
	uint32_t IDE	:1;		//	тип идентификатора
	uint32_t EXID	:29;	//	расширенный идентификатор
} StructCAN_RIR_EX;

typedef union _CAN_RIR			// CAN receive FIFO mailbox identifier register (CAN_RIxR)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile StructCAN_RIR STID;		//	структура бит
	volatile StructCAN_RIR_EX EXID;	//	структура бит Extended identifier
} UnionCAN_RIR;

/*******************************************************************************************************/

/*************CAN receive FIFO mailbox data length control and time stamp register (CAN_RDTxR)**********/

typedef struct _StructCAN_RDTR	//	CAN receive FIFO mailbox data length control and time stamp register
{
	uint32_t DLC		:4;		//	размер данных в байтах
	uint32_t reserv1	:4;		//	неиспользуется
	uint32_t FMI		:8;		//	идекс фильтра который соответствует сообщению
	uint32_t TIME		:16;	//	отметка времени сообщения
} StructCAN_RDTR;

/*******************************************************************************************************/

/******************CAN receive FIFO mailbox data low register (CAN_RDLxR) (x = 0..1)********************/

typedef struct _StructCAN_RDLR	// CAN receive FIFO mailbox data low register (CAN_RDLxR) (x = 0..1)
{
	uint32_t DATA0		:8;		//	байт данных 0
	uint32_t DATA1		:8;		//	байт данных 1
	uint32_t DATA2		:8;		//	байт данных 2
	uint32_t DATA3		:8;		//	байт данных 3
} StructCAN_RDLR;

/*******************************************************************************************************/

/******************CAN receive FIFO mailbox data high register (CAN_RDHxR) (x = 0..1)*******************/

typedef struct _StructCAN_RDHR	// CAN receive FIFO mailbox data low register (CAN_RDHxR) (x = 0..1)
{
	uint32_t DATA4		:8;		//	байт данных 4
	uint32_t DATA5		:8;		//	байт данных 5
	uint32_t DATA6		:8;		//	байт данных 6
	uint32_t DATA7		:8;		//	байт данных 7
} StructCAN_RDHR;

/*******************************************************************************************************/

/**********************************CAN filter master register (CAN_FMR)*********************************/

typedef struct _StructCAN_FMR	// CAN filter master register (CAN_FMR)
{
	uint32_t FINIT	:1;			// режим инициализации фильтра
	uint32_t reserv1:31;		// неиспользуется
} StructCAN_FMR;

/*******************************************************************************************************/

/**********************************CAN filter mode register (CAN_FM1R)**********************************/

typedef struct _StructCAN_FM1R	// CAN filter mode register (CAN_FM1R)
{
	uint32_t FBM0	:1;			//  ID без масок
	uint32_t FBM1	:1;			//  ID без масок
	uint32_t FBM2	:1;			//  ID без масок
	uint32_t FBM3	:1;			//  ID без масок
	uint32_t FBM4	:1;			//  ID без масок
	uint32_t FBM5	:1;			//  ID без масок
	uint32_t FBM6	:1;			//  ID без масок
	uint32_t FBM7	:1;			//  ID без масок
	uint32_t FBM8	:1;			//  ID без масок
	uint32_t FBM9	:1;			//  ID без масок
	uint32_t FBM10	:1;			//  ID без масок
	uint32_t FBM11	:1;			//  ID без масок
	uint32_t FBM12	:1;			//  ID без масок
	uint32_t FBM13	:1;			//  ID без масок
	uint32_t reserv1:18;		//	неиспользуется
} StructCAN_FM1R;

/*******************************************************************************************************/

/**********************************CAN filter scale register (CAN_FS1R)*********************************/

typedef struct _StructCAN_FS1R	//	CAN filter scale register (CAN_FS1R)
{
	uint32_t FSC0	:1;			//  32 или 2х16 бит
	uint32_t FSC1	:1;			//  32 или 2х16 бит
	uint32_t FSC2	:1;			//  32 или 2х16 бит
	uint32_t FSC3	:1;			//  32 или 2х16 бит
	uint32_t FSC4	:1;			//  32 или 2х16 бит
	uint32_t FSC5	:1;			//  32 или 2х16 бит
	uint32_t FSC6	:1;			//  32 или 2х16 бит
	uint32_t FSC7	:1;			//  32 или 2х16 бит
	uint32_t FSC8	:1;			//  32 или 2х16 бит
	uint32_t FSC9	:1;			//  32 или 2х16 бит
	uint32_t FSC10	:1;			//  32 или 2х16 бит
	uint32_t FSC11	:1;			//  32 или 2х16 бит
	uint32_t FSC12	:1;			//  32 или 2х16 бит
	uint32_t FSC13	:1;			//  32 или 2х16 бит
	uint32_t reserv1:18;		//	неиспользуется
} StructCAN_FS1R;

/*******************************************************************************************************/

/**********************************CAN filter FIFO assignment register (CAN_FFA1R)**********************/

typedef struct _StructCAN_FFA1R	// CAN filter FIFO assignment register (CAN_FFA1R)
{
	uint32_t FFA0	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA1	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA2	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA3	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA4	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA5	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA6	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA7	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA8	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA9	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA10	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA11	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA12	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t FFA13	:1;			//	1 - FIFO 1, 0 - FIFO 0
	uint32_t reserv1:18;		//	неиспользуется
} StructCAN_FFA1R;

/*******************************************************************************************************/

/**********************************CAN filter activation register (CAN_FA1R)****************************/

typedef struct _StructCAN_FA1R	// CAN filter activation register (CAN_FA1R)
{
	uint32_t FACT0	:1;			//	активация фильтра
	uint32_t FACT1	:1;			//	активация фильтра
	uint32_t FACT2	:1;			//	активация фильтра
	uint32_t FACT3	:1;			//	активация фильтра
	uint32_t FACT4	:1;			//	активация фильтра
	uint32_t FACT5	:1;			//	активация фильтра
	uint32_t FACT6	:1;			//	активация фильтра
	uint32_t FACT7	:1;			//	активация фильтра
	uint32_t FACT8	:1;			//	активация фильтра
	uint32_t FACT9	:1;			//	активация фильтра
	uint32_t FACT10	:1;			//	активация фильтра
	uint32_t FACT11	:1;			//	активация фильтра
	uint32_t FACT12	:1;			//	активация фильтра
	uint32_t FACT13	:1;			//	активация фильтра
	uint32_t reserv1:18;		//	неиспользуется
} StructCAN_FA1R;

/*******************************************************************************************************/

/***********************Filter bank i register x (CAN_FiRx) (i = 0..13, x = 1, 2)***********************/

typedef struct _StructCAN_EXID	//	структура расширенного идентификатора (CAN_FiRx)
{
	uint32_t reserv1	:3;		//	неиспользуется
	uint32_t EXID		:29;	//  расширенный идентификатор
} StructCAN_EXID;

typedef struct _StructCAN_STDID	//	структура идентификатор + идентификатор (CAN_FiRx)
{
	uint32_t reserv1	:5;		//	неиспользуется
	uint32_t ID1		:11;	//  1 идентификатор
	uint32_t reserv2	:5;		//	неиспользуется
	uint32_t ID2		:11;	//  2 идентификатор
} StructCAN_STDID;

typedef struct _StructCAN_IDM	//	структура идентификатор + маска (CAN_FiRx)
{
	uint32_t reserv1	:5;		//	неиспользуется
	uint32_t ID			:11;	//  идентификатор
	uint32_t reserv2	:5;		//	неиспользуется
	uint32_t MASK		:11;	//  маска
} StructCAN_IDM;

typedef union _CAN_FiR					//	регистр банка фильтров x (CAN_FiRx)
{
	volatile uint32_t R;				//	ссылка на регистр
	volatile StructCAN_EXID EXID;		//	расширенный идентификатор
	volatile StructCAN_STDID STID;		//	стандартный идентификатор + стандартный идентификатор
	volatile StructCAN_IDM IDMASK;		//	идентификатор + маска
} UnionCAN_FiR;

/*******************************************************************************************************/

/*******************************************************************************************************/

typedef struct _StructCAN
{
	volatile StructCAN_MCR		MCR;	//	главный контрольный регистр CAN
	volatile StructCAN_MSR		MSR;	//	главный регистр статуса CAN
	volatile StructCAN_TSR		TSR;	//	регистр статуса передачи
	volatile StructCAN_RF0R		RF0R;	//	регистр приема FIFO 0
	volatile StructCAN_RF1R		RF1R;	//	регистр приема FIFO 1
	volatile StructCAN_IER		IER;	//	режим регистра фильтра, ID с маской или без
	volatile StructCAN_ESR		ESR;	//	регистр статуса ошибки
	volatile StructCAN_BTR		BTR;	//	регистр битовой синхронизации
	volatile const uint32_t		RESERV0[88];	//	зарезервировано
	volatile UnionCAN_TIR		TI0R;	//	регистр идентификатора почтового ящика
	volatile StructCAN_TDTR		TDT0R;	//	регистр управления длиной данных и меткой времени
	volatile StructCAN_TDLR		TDL0R;	//	нижний регистр данных
	volatile StructCAN_TDHR		TDH0R;	//	верхний регистр данных
	volatile UnionCAN_TIR		TI1R;	//	регистр идентификатора почтового ящика
	volatile StructCAN_TDTR		TDT1R;	//	регистр управления длиной данных и меткой времени
	volatile StructCAN_TDLR		TDL1R;	//	нижний регистр данных
	volatile StructCAN_TDHR		TDH1R;	//	верхний регистр данных
	volatile UnionCAN_TIR		TI2R;	//	регистр идентификатора почтового ящика
	volatile StructCAN_TDTR		TDT2R;	//	регистр управления длиной данных и меткой времени
	volatile StructCAN_TDLR		TDL2R;	//	нижний регистр данных
	volatile StructCAN_TDHR		TDH2R;	//	верхний регистр данных
	volatile UnionCAN_RIR		RI0R;	//	регистр идентификатора почтового ящика FIFO
	volatile StructCAN_RDTR		RDT0R;	//	регистр управления длиной данных и меткой времени
	volatile StructCAN_RDLR		RDL0R;	//	нижний регистр данных
	volatile StructCAN_RDHR		RDH0R;	//	верхний регистр данных
	volatile UnionCAN_RIR		RI1R;	//	регистр идентификатора почтового ящика FIFO
	volatile StructCAN_RDTR		RDT1R;	//	регистр управления длиной данных и меткой времени
	volatile StructCAN_RDLR		RDL1R;	//	нижний регистр данных
	volatile StructCAN_RDHR		RDH1R;	//	верхний регистр данных
	volatile const uint32_t		RESERV1[12];	//	зарезервировано
	volatile StructCAN_FMR		FMR;	//	главный регистр фильтра CAN
	volatile StructCAN_FM1R		FM1R;	//	режим регистра фильтра, ID с маской или без
	volatile const uint32_t		RESERV2;	//	зарезервировано
	volatile StructCAN_FS1R		FS1R;	//	регистр размера фильтров 16 или 32 бита
	volatile const uint32_t		RESERV3;	//	зарезервировано
	volatile StructCAN_FFA1R	FFA1R;	//	регистр назначения фильтра (FIFO 0 или FIFO 1)
	volatile const uint32_t		RESERV4;	//	зарезервировано
	volatile StructCAN_FA1R		FA1R;	//	регистр активации фильтра
	volatile const uint32_t		RESERV5[8];	//	зарезервировано
	volatile UnionCAN_FiR		F0R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F0R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F1R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F1R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F2R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F2R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F3R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F3R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F4R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F4R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F5R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F5R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F6R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F6R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F7R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F7R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F8R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F8R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F9R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F9R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F10R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F10R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F11R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F11R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F12R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F12R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F13R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F13R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F14R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F14R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F15R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F15R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F16R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F16R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F17R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F17R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F18R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F18R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F19R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F19R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F20R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F20R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F21R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F21R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F22R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F22R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F23R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F23R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F24R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F24R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F25R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F25R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F26R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F26R2;	//	регистр фильтра
	volatile UnionCAN_FiR		F27R1;	//	регистр фильтра
	volatile UnionCAN_FiR		F27R2;	//	регистр фильтра
}StructCAN;

#define _CAN	((StructCAN *) 0x40006400)

/*******************************************************************************************************/

#endif /* BSH_CAN_H_ */












