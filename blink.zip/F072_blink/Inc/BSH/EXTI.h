/*
 * EXTI.h
 *
 *  Created on: 24 окт. 2020 г.
 *      Author: sergeyvp@gmail.com
 */

#ifndef BSH_EXTI_H_
#define BSH_EXTI_H_

#include "BS.h"

/***************************************************************************************
Контроллер EXTI управляет асинхронными внешними/внутренними прерываниями/событиями
генерируя запросы контроллеру прерываний CPU и запрос пробуждения контроллеру питания.
EXTI позволяет управлять 32 внутренними/внешними прерываниями/событиями
(23 внешних линии и 9 внутренних линий).
Активный фронт может быть выбран независимо для каждой внешней линии прерывания,
для внутренних линий прерываний фронт всегда нарастающий.
Прерывание может быть отложенным: в случае внешнего прерывания создаётся статус
в регистре и указывается источник прерывания; событие это всегда небольшой импульс
который используется для пробуждения ядра. Для внутренних прерываний статус ожидания
обеспечивается созданием IP, поэтому нет необходимости в специальных флагах.
Каждая линия ввода может быть замаскирована для прерывания и генерации событий,
дополнительно внутренние линии могут определяться в режим STOP.
Контроллер также позволяет програмно эмулировать внешние события записью в специальный
регистр, мультпликсируя с соответствующими линиями аппаратных событий.
Основные возможности EXTI:
• генерация 32 событий/прерываний
• независимая маска для каждой линии события/прерывания
• автоматическое отключение линии прерываний когда система не в режиме STOP
• независимый переключатель для линии события/прерывания
• специальный бит статуса для каждого внешнего прерывания
• эмуляция всех внешних событий
****************************************************************************************/
/***********************Interrupt mask register (EXTI_IMR)******************************/

typedef struct _StructEXTI_IMR
{
	uint32_t Line0		:1;		//
	uint32_t Line1		:1;		//
	uint32_t Line2		:1;		//
	uint32_t Line3		:1;		//
	uint32_t Line4		:1;		//
	uint32_t Line5		:1;		//
	uint32_t Line6		:1;		//
	uint32_t Line7		:1;		//
	uint32_t Line8		:1;		//
	uint32_t Line9		:1;		//
	uint32_t Line10		:1;		//
	uint32_t Line11		:1;		//
	uint32_t Line12		:1;		//
	uint32_t Line13		:1;		//
	uint32_t Line14		:1;		//
	uint32_t Line15		:1;		//
	uint32_t Line16		:1;		//
	uint32_t Line17		:1;		//
	uint32_t Line18		:1;		//
	uint32_t Line19		:1;		//
	uint32_t Line20		:1;		//
	uint32_t Line21		:1;		//
	uint32_t Line22		:1;		//
	uint32_t Line23		:1;		//
	uint32_t Line24		:1;		//
	uint32_t Line25		:1;		//
	uint32_t Line26		:1;		//
	uint32_t Line27		:1;		//
	uint32_t Line28		:1;		//
	uint32_t Line29		:1;		//
	uint32_t Line30		:1;		//
	uint32_t Line31		:1;		//
} StructEXTI_IMR;

/********************************END (EXTI_IMR)*****************************************/

/*************************Event mask register (EXTI_EMR)********************************/

typedef struct _StructEXTI_EMR
{
	uint32_t Line0		:1;		//
	uint32_t Line1		:1;		//
	uint32_t Line2		:1;		//
	uint32_t Line3		:1;		//
	uint32_t Line4		:1;		//
	uint32_t Line5		:1;		//
	uint32_t Line6		:1;		//
	uint32_t Line7		:1;		//
	uint32_t Line8		:1;		//
	uint32_t Line9		:1;		//
	uint32_t Line10		:1;		//
	uint32_t Line11		:1;		//
	uint32_t Line12		:1;		//
	uint32_t Line13		:1;		//
	uint32_t Line14		:1;		//
	uint32_t Line15		:1;		//
	uint32_t Line16		:1;		//
	uint32_t Line17		:1;		//
	uint32_t Line18		:1;		//
	uint32_t Line19		:1;		//
	uint32_t Line20		:1;		//
	uint32_t Line21		:1;		//
	uint32_t Line22		:1;		//
	uint32_t Line23		:1;		//
	uint32_t Line24		:1;		//
	uint32_t Line25		:1;		//
	uint32_t Line26		:1;		//
	uint32_t Line27		:1;		//
	uint32_t Line28		:1;		//
	uint32_t Line29		:1;		//
	uint32_t Line30		:1;		//
	uint32_t Line31		:1;		//
} StructEXTI_EMR;

/********************************END (EXTI_EMR)*****************************************/

/*****************Rising trigger selection register (EXTI_RTSR)*************************/

typedef struct _StructEXTI_RTSR
{
	uint32_t Line0		:1;		//
	uint32_t Line1		:1;		//
	uint32_t Line2		:1;		//
	uint32_t Line3		:1;		//
	uint32_t Line4		:1;		//
	uint32_t Line5		:1;		//
	uint32_t Line6		:1;		//
	uint32_t Line7		:1;		//
	uint32_t Line8		:1;		//
	uint32_t Line9		:1;		//
	uint32_t Line10		:1;		//
	uint32_t Line11		:1;		//
	uint32_t Line12		:1;		//
	uint32_t Line13		:1;		//
	uint32_t Line14		:1;		//
	uint32_t Line15		:1;		//
	uint32_t Line16		:1;		//
	uint32_t Line17		:1;		//
	uint32_t reserv1	:1;		//
	uint32_t Line19		:1;		//
	uint32_t Line20		:1;		//
	uint32_t Line21		:1;		//
	uint32_t Line22		:1;		//
	uint32_t reserv2	:8;		//
	uint32_t Line31		:1;		//
} StructEXTI_RTSR;

/********************************END (EXTI_RTSR)****************************************/

/*****************Falling trigger selection register (EXTI_FTSR)************************/

typedef struct _StructEXTI_FTSR
{
	uint32_t Line0		:1;		//
	uint32_t Line1		:1;		//
	uint32_t Line2		:1;		//
	uint32_t Line3		:1;		//
	uint32_t Line4		:1;		//
	uint32_t Line5		:1;		//
	uint32_t Line6		:1;		//
	uint32_t Line7		:1;		//
	uint32_t Line8		:1;		//
	uint32_t Line9		:1;		//
	uint32_t Line10		:1;		//
	uint32_t Line11		:1;		//
	uint32_t Line12		:1;		//
	uint32_t Line13		:1;		//
	uint32_t Line14		:1;		//
	uint32_t Line15		:1;		//
	uint32_t Line16		:1;		//
	uint32_t Line17		:1;		//
	uint32_t reserv1	:1;		//
	uint32_t Line19		:1;		//
	uint32_t Line20		:1;		//
	uint32_t Line21		:1;		//
	uint32_t Line22		:1;		//
	uint32_t reserv2	:8;		//
	uint32_t Line31		:1;		//
} StructEXTI_FTSR;

/********************************END (EXTI_FTSR)****************************************/

/*****************Software interrupt event register (EXTI_SWIER)************************/

typedef struct _StructEXTI_SWIER
{
	uint32_t Line0		:1;		//
	uint32_t Line1		:1;		//
	uint32_t Line2		:1;		//
	uint32_t Line3		:1;		//
	uint32_t Line4		:1;		//
	uint32_t Line5		:1;		//
	uint32_t Line6		:1;		//
	uint32_t Line7		:1;		//
	uint32_t Line8		:1;		//
	uint32_t Line9		:1;		//
	uint32_t Line10		:1;		//
	uint32_t Line11		:1;		//
	uint32_t Line12		:1;		//
	uint32_t Line13		:1;		//
	uint32_t Line14		:1;		//
	uint32_t Line15		:1;		//
	uint32_t Line16		:1;		//
	uint32_t Line17		:1;		//
	uint32_t reserv1	:1;		//
	uint32_t Line19		:1;		//
	uint32_t Line20		:1;		//
	uint32_t Line21		:1;		//
	uint32_t Line22		:1;		//
	uint32_t reserv2	:8;		//
	uint32_t Line31		:1;		//
} StructEXTI_SWIER;

/********************************END (EXTI_SWIER)***************************************/

/**************************Pending register (EXTI_PR)***********************************/

typedef struct _StructEXTI_PR
{
	uint32_t Line0		:1;		//
	uint32_t Line1		:1;		//
	uint32_t Line2		:1;		//
	uint32_t Line3		:1;		//
	uint32_t Line4		:1;		//
	uint32_t Line5		:1;		//
	uint32_t Line6		:1;		//
	uint32_t Line7		:1;		//
	uint32_t Line8		:1;		//
	uint32_t Line9		:1;		//
	uint32_t Line10		:1;		//
	uint32_t Line11		:1;		//
	uint32_t Line12		:1;		//
	uint32_t Line13		:1;		//
	uint32_t Line14		:1;		//
	uint32_t Line15		:1;		//
	uint32_t Line16		:1;		//
	uint32_t Line17		:1;		//
	uint32_t reserv1	:1;		//
	uint32_t Line19		:1;		//
	uint32_t Line20		:1;		//
	uint32_t Line21		:1;		//
	uint32_t Line22		:1;		//
	uint32_t reserv2	:8;		//
	uint32_t Line31		:1;		//
} StructEXTI_PR;

/********************************END  (EXTI_PR)*****************************************/

/***************************************************************************************/

typedef struct _StructEXTI
{
	volatile StructEXTI_IMR		IMR;		//	регистр маскировки прерываний
	volatile StructEXTI_EMR		EMR;		//	регистр маскировки событий
	volatile StructEXTI_RTSR	RTSR;		//	регистр выбора переключения по восходящему фронту
	volatile StructEXTI_FTSR	FTSR;		//	регистр выбора переключения по нисходящему фронту
	volatile StructEXTI_SWIER	SWIER;		//	регистр програмной установки флагов прерываний
	volatile StructEXTI_PR		PR;		//	регистр флагов ожидания прерываний
}StructEXTI;

#define	_EXTI	((StructEXTI *) 0x40010400)	//	структура регистров прерываний

/***************************************************************************************/

#endif /* BSH_EXTI_H_ */













