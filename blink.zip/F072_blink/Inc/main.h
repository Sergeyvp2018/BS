/*
 * INIT.h
 *
 *  Created on: 7 дек. 2020 г.
 *      Author: sergey
 */

#ifndef MAIN_H_
#define MAIN_H_

#include "BS.h"

//#define	TSSOP20				//	активировать код для stm32f042 в корпусе TSSOP20

#ifdef	TSSOP20
	#define	DIOD_STATE	(_GPIOA->OUTPUT.Pin4)
	#define	DIOD_OFF	(_GPIOA->SETR.Pin4 = HIGH)
	#define	DIOD_ON		(_GPIOA->RESETR.Pin4 = DROP)
#else
#define	DIOD_STATE	(_GPIOA->OUTPUTR.Pin5)
#define	DIOD_ON		(_GPIOA->SETR.Pin5 = HIGH)
#define	DIOD_OFF	(_GPIOA->RESETR.Pin5 = DROP)
#endif

#define	DRV_LEFT()	{_GPIOA->RESETR.Pin1 = DROP;_GPIOA->SETR.Pin4 = HIGH;}
#define	DRV_RIGHT()	{_GPIOA->RESETR.Pin4 = DROP;_GPIOA->SETR.Pin1 = HIGH;}
#define	DRV_STOP()	{_GPIOA->RESETR.Pin1 = DROP;_GPIOA->RESETR.Pin4 = DROP;}
#define	HALL_END	(_GPIOA->INPUTR.Pin6)
#define	HALL_START	(_GPIOA->INPUTR.Pin7)
#define	DIR_R		(0b01)
#define	DIR_L		(0b10)
#define	DIR_STOP	(0b11)

#define	MAX_CNT_VAL	(0xFFFF)

#define	PERCENT_TO_POSITION( percent)	(full_cnt_move\100*percent)

void PLL_Init( void);		//	настройка тактовой частоты
void RCC_Init( void);		//	натройка тактирования переферии
void TIM_Init( void);		//	инициализация таймера для счёта оборотов
void EXTI_Init( void);		//	инициализация прерываний
void SYSTICK_Init( void);	//	настройка системного таймера

uint32_t GPIO_Init( void);	//	инициализация портов
uint32_t CAN_Init( void);	//	инициализация шины CAN

typedef struct _StrucMOD_
{
//	uint32_t CHMOD		:1;			//	флаг изменения режима
	uint32_t TEST :1;		//	тестирование и калибровка
	uint32_t DIRECT :2;		//	направление вращения
	uint32_t reserv :28;	//	не используется
} StrucMOD;

StrucMOD MOD;

#endif /* MAIN_H_ */
